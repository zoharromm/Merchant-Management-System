﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using System.IO;
using System.Net.Mail;


namespace AmazonListingRemove
{
    class Helper
    {
        //Error Number from 101-110
        public static string ZGetSubmitFeedName
        {
            get
            {
               return  System.AppDomain.CurrentDomain.BaseDirectory + @"\Files\SubmitFeed.xml";
            }

        }
        public static string ZGetReportFeed
        {
            get
            {
                return System.AppDomain.CurrentDomain.BaseDirectory + @"\Files\";
            }

        }
        public static void LockError(string ErrorMessage)
        {
            try
            {
     
                    string SenderUserName = "developer3errorlocking@gmail.com";
                    string SenderName = "Developer 3";
                    string SenderPassword = "inform123";

                    SmtpClient client = new SmtpClient("smtp.gmail.com");
                    System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage(new MailAddress(SenderUserName, SenderName), new MailAddress("developer3errorlocking@gmail.com"));
                    msg.Subject = "Amazone App Errors";
                    msg.Body = ErrorMessage;
                    System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential(SenderUserName, SenderPassword);
                    client.UseDefaultCredentials = false;
                    client.Credentials = SMTPUserInfo;
                    client.Port = 587;
                    client.EnableSsl = true;
                    client.Send(msg);
                
            }
            catch
            {
            }
        }

        
        public static string SingleQouts(string str)
        {
            return "'" + str.Replace("'", "''") + "'";
        }



        
    }
}
