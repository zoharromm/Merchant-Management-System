﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AmazonLister;
using MarketplaceWebService.Mock;
using MarketplaceWebService.Model;
using System.Xml.Serialization;
using System.IO;
using System.Net;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using AmazonListingRemove;

namespace AmazonListingRemove
{
    public partial class Form1 : Form
    {
        DataSet Products;
        DataSet ds;

        List<AMAZONTemplate> _ListProcessTemplate = new List<AMAZONTemplate>();
        List<AmazonLister.cls.Sellers> sellers = new List<AmazonLister.cls.Sellers>();
        List<Store> _ListStores = new List<Store>();
        List<AmzFeedSubmission> _PendingFeed = new List<AmzFeedSubmission>();
        List<Procedures> _ListSubProcess = new List<Procedures>();
        BusinessLayer.DB _DB = new BusinessLayer.DB();
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        int RequestPool = 10;
        int MaxRecordInFile = 0;
        DataTable _QtyUpdate = new DataTable();
        DataTable _PriceUpdate = new DataTable();
        DataTable _ShippingUpdate = new DataTable();
        DataTable _ImageUpdate = new DataTable();
        DataTable _ClonePrd = new DataTable();
        DataTable _UPCassignment = new DataTable();
        bool TaskStatus = false;
        public Form1()
        {
            _ListSubProcess.Add(new Procedures { SizeParameter = false, ProcedureName = "AmazonWebServiceDeleteProducts", _Type = AmazonLister.OperationType.Delete });
            _ListSubProcess.Add(new Procedures { SizeParameter = false, ProcedureName = "AmazonWebServiceDeleteRestrictedProducts", _Type = AmazonLister.OperationType.Delete });
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            #region BindSellers
            BindSellers();
            #endregion BindSellers
            Timer t = new Timer();
            t.Interval = 180000;
            t.Enabled = true;
            timer1_Tick(null, null);
            t.Tick += new EventHandler(timer1_Tick);

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!TaskStatus)
            {
                TaskStatus = true;
                System.Threading.Thread triggerThread = new System.Threading.Thread(Trigger);
                triggerThread.Start();
            }
        }
        public void Trigger()
        {
            try
            {
                foreach (AmazonLister.cls.Sellers seller in sellers)
                {
                    #region FeedStatus
                    GetFeedStatus(seller);
                    #endregion FeedStatus
                    RequestPool = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RequestPool"]);
                    MaxRecordInFile = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxRecordInFile"]);
                    #region BindStore
                    BindStore(seller.SellerID);
                    #endregion BindStore
                    #region Loop Through Template

                    foreach (Store str in _ListStores)
                    {
                        foreach (Procedures _Prc in _ListSubProcess)
                        {
                            ListingProcess(str.Name, _Prc.ProcedureName, _Prc._Type, _Prc.SizeParameter, str.StoreID,seller);
                            Application.DoEvents();
                        }


                        //}
                    }

                    #endregion Loop Through Template
                    #region FeedStatus
                    GetFeedStatus(seller);
                    #endregion FeedStatus
                    
                }

                Application.DoEvents();
                System.Threading.Thread.Sleep(120000);
                TaskStatus = false;
            }
            catch { }
        }
        public void ListingProcess(string StoreName, string ProcName, AmazonLister.OperationType OperationType, bool IsSize, int storeID,AmazonLister.cls.Sellers Seller )
        {
            GetRecordsFromDB(StoreName, ProcName, IsSize, storeID);
            try
            {
                if (Products.Tables.Count > 0)
                {
                    if (Products.Tables[0].Rows.Count > 0)
                    {
                        SubmitSimpleSKU(Products, StoreName, OperationType, IsSize, ProcName, Seller);
                    }
                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in ListingProcess function for  Store : " + StoreName + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        private void SubmitSimpleSKU(DataSet DsPrd, string StoreName, AmazonLister.OperationType OperationType, bool IsSize, string ProcName,AmazonLister.cls.Sellers Seller)
        {
            try
            {
                int NoOfFeeds = 0;
                int TotalNoOfRecords = DsPrd.Tables[0].Rows.Count;
                if (TotalNoOfRecords % MaxRecordInFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {
                    try
                    {
                        #region CheckRequestPool
                        while (CheckRequestPool(Seller.SellerID) >= RequestPool)
                        {
                            Application.DoEvents();
                            System.Threading.Thread.Sleep(100000);
                        }
                        #endregion CheckRequestPoo
                        DataSet DsFeedPrds = new DataSet();
                        DsFeedPrds.Tables.Add(DsPrd.Tables[0].AsEnumerable().Skip(i * MaxRecordInFile).Take(MaxRecordInFile).CopyToDataTable());
                        CreateMessage CreateMessage = new CreateMessage(DsFeedPrds);
                        List<AmazonLister.Message> Message = (new CreateMessage(DsFeedPrds)).GetMessage(ListMessageType.SubmitSKU, OperationType, StoreName, IsSize);
                        if (Message.Count > 0)
                        {
                            FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService(Seller).UploadProductSKU(Message));
                            //Store All Data to SQL Lite When Data Get Sucessed we will update it to Live site
                            SaveFeed(FeedSubmissionInfo, DsFeedPrds, ProcName, StoreName, IsSize,Seller.SellerID);
                        }
                    }
                    catch (Exception Exp)
                    {
                        _Mail.SendMail("Issue Occured in SubmitSimpleSKU Function. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                    }

                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void SaveFeed(FeedSubmissionInfo FeedSubmissionInfo, DataSet DsFeedPrds, string ProcName, string StoreName, bool IsSize, int SellerID)
        {
            try
            {
                string lQuery1 = string.Format("Insert into AmzFeedSubmission(FeedSubmissionID,SubmissionType,SubmissionDate, SubmissionStatus,query,SellerID) Values ({0},{1},{2},{3},{4},{5})",
                                           Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId),
                                           Helper.SingleQouts(FeedSubmissionInfo.FeedType),
                                           Helper.SingleQouts(DateTime.Now.ToString()),
                                           Helper.SingleQouts(FeedSubmissionInfo.FeedProcessingStatus),
                                            Helper.SingleQouts(ProcName + "parameters: StoreName=" + StoreName + "  size:" + IsSize), SellerID);
                _DB.ExecuteCommand(lQuery1);
                if (!Directory.Exists(Application.StartupPath + "/FeedFiles/" + SellerID))
                    Directory.CreateDirectory(Application.StartupPath + "/FeedFiles/" + SellerID);
                StreamWriter _Writer = new StreamWriter(Application.StartupPath + "/FeedFiles/" + SellerID+"/" + FeedSubmissionInfo.FeedSubmissionId + ".csv");
                StringBuilder sb = new StringBuilder();
                int Counter = 0;
                foreach (var col in DsFeedPrds.Tables[0].Columns)
                {
                    if (Counter + 1 == DsFeedPrds.Tables[0].Columns.Count)
                        sb.Append(col.ToString());
                    else
                        sb.Append(col.ToString() + "\t");
                    Counter++;
                }
                _Writer.WriteLine(sb);
                sb = new StringBuilder();
                foreach (DataRow row in DsFeedPrds.Tables[0].Rows)
                {

                    for (int col = 0; col < DsFeedPrds.Tables[0].Columns.Count; col++)
                    {
                        if (col + 1 == DsFeedPrds.Tables[0].Columns.Count)
                            sb.Append(row[col].ToString());
                        else
                            sb.Append(row[col].ToString() + "\t");
                    }
                    _Writer.WriteLine(sb);
                    sb = new StringBuilder();
                }
                _Writer.Close();
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("SaveFeed Function. Issue Occured in save feed response. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public int CheckRequestPool(int SellerID)
        {
            int Records = 0;
            try
            {
                SqlDataReader _Reader = _DB.GetDR("select COUNT(*) as Count from AmzFeedSubmission where SellerID="+SellerID+" and SubmissionDate between DATEADD(minute,-20,getdate()) and GETDATE()");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {
                        Records = Convert.ToInt32(_Reader["Count"]);
                    }

                }
                try { _Reader.Close(); }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in getting No of feed Submit within 15 mins. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            return Records;
        }
        public void GetRecordsFromDB(string StoreName, string ProcName, bool IsSize, int storeID)
        {
            Products = new DataSet();
            Products.Tables.Clear();
            DataSet dummy;
            DataTable table = new DataTable();
            try
            {
                int Pages = 0;
                int TotalRecords = 0;
                dummy = new DataSet();
                dummy = _DB.GetDataset(ProcName, CommandType.StoredProcedure, "@TemplateName," + StoreName + ":@IsSize," + IsSize + ":@Storeid," + storeID + ":@categoryid,0:@pagesize,1000:@page,1");
                table = dummy.Tables[0];
                if (dummy.Tables.Count > 1)
                    TotalRecords = Convert.ToInt32(dummy.Tables[1].Rows[0][0]);
                if (TotalRecords % 1000 == 0)
                    Pages = Convert.ToInt32(TotalRecords / 1000);
                else
                    Pages = Convert.ToInt32(TotalRecords / 1000) + 1;

                for (int page = 2; page <= Pages; page++)
                {

                    dummy = new DataSet();
                    dummy = _DB.GetDataset(ProcName, CommandType.StoredProcedure, "@TemplateName," + StoreName + ":@IsSize," + IsSize + ":@Storeid," + storeID + ":@categoryid,0:@pagesize,1000:@page," + page);
                    dummy.Tables[0].AsEnumerable().ToList().ForEach(row => table.ImportRow(row));
                }
                Products.Tables.Add(table.Copy());

            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Getting Records from database for storeid : " + storeID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void BindStore(int SellerID)
        {
            try
            {
                _ListStores = new List<Store>();
                string storeName = "";
                int storeID = 0;
                SqlDataReader _Reader = _DB.GetDR("select Store.StoreID,StoreName  from Store join SellerStoreMapping on Store.storeid=SellerStoreMapping.storeid where SellerID=" + SellerID + " order by Store.storeid");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {

                        try
                        {
                            storeName = _Reader["StoreName"].ToString();
                            storeID = Convert.ToInt32(_Reader["StoreID"]);
                            Store _Str = new Store();
                            _Str.Name = storeName;
                            _Str.StoreID = storeID;
                            _ListStores.Add(_Str);
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("Issue Occured in adding Store : " + storeName + " to Task List. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                try
                {
                    _Reader.Close();
                }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in binding Stores to TaskList. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        private void GetFeedStatus(AmazonLister.cls.Sellers Seller)
        {
            bool FilesProcessed = false;
            while (!FilesProcessed)
            {
                Application.DoEvents();
                try
                {
                    DataTable ltbl = _DB.GetDataset(string.Format("Select * from AMZFeedSubmission Where SubmissionStatus!='Complete' and query like 'AmazonWebServiceDelete%' and isnull(Error,0) =0  and DATEDIFF(HH, GETDATE(), SubmissionDate)<6 and sellerid="+Seller.SellerID+"  order by feedid"), CommandType.Text, "").Tables[0];
                    if (ltbl.Rows.Count != 0)
                    {
                        UpdateStatus(ltbl,Seller);
                        FilesProcessed = false;
                    }
                    else
                        FilesProcessed = true;

                }
                catch (Exception Exp)
                {
                    _Mail.SendMail("FeedSubmissionProcess Function.Issue Occured in getting Feeds from database. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                    FilesProcessed = false;
                }
            }
        }
        private void UpdateStatus(DataTable ltbl,AmazonLister.cls.Sellers Seller)
        {
            try
            {
                foreach (DataRow dr in ltbl.Rows)
                {
                    if (File.Exists(Helper.ZGetSubmitFeedName) == true)
                    {
                        System.IO.File.Delete(Helper.ZGetSubmitFeedName);
                    }
                    ProcessingReport ProcessingReport = new ProcessingReport();
                    List<AmazonLister.Message> Messages = (new AmazonWebService(Seller).CheckFeedStatus(dr["FeedSubmissionID"].ToString(), Helper.ZGetSubmitFeedName));
                    if (Messages.Count() > 0)
                    {
                        ProcessingReport = Messages[0].ProcessingReport;
                        if (ProcessingReport.ProcessingSummary.MessagesWithError > 0 && ProcessingReport.ProcessingSummary.MessagesSuccessful == 0)
                        {
                            try
                            {
                                String Query = string.Format("Update AMZFeedSubmission SET SubmissionStatus ='Error',Error=1 Where sellerid="+Seller.SellerID+" and  FeedSubmissionID ={0}", Helper.SingleQouts(dr["FeedSubmissionID"].ToString()));
                                _DB.ExecuteCommand(Query);
                                _Mail.SendMail("UpdateStatus Function.Issue Occured in Feed Submission  for feedsubmissionID = " + dr["FeedSubmissionID"].ToString() + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);

                            }
                            catch (Exception Exp)
                            {
                                _Mail.SendMail("UpdateStatus Function.Issue Occured in update status of feed in database. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                            }
                        }
                        else
                        {


                            try
                            {
                                String Query = string.Format("Update AMZFeedSubmission SET SubmissionStatus ={0} Where sellerid="+Seller.SellerID+" and FeedSubmissionID ={1}", Helper.SingleQouts(ProcessingReport.StatusCode), Helper.SingleQouts(dr["FeedSubmissionID"].ToString()));
                                _DB.ExecuteCommand(Query);
                            }
                            catch (Exception Exp)
                            {
                                _Mail.SendMail("UpdateStatus Function.Issue Occured in update status of feed in database. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                            }

                        }
                        #region DataBaseUpdate
                        DbSync(dr["Query"].ToString(), dr["FeedSubmissionID"].ToString(), dr["SubmissionType"].ToString(), Messages,Seller.SellerID);
                        #endregion DataBaseUpdate
                    }
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(60000);
                    //*********Sleep code for 1 minute****************/
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DbSync(string ProcType, string FeedID, string FeedType, List<AmazonLister.Message> Response,int SellerID)
        {
            string StoredProcedureName = "";
            int Type = 0;
            DataTable _Table = new DataTable();
            try
            {
                if (!Directory.Exists(Application.StartupPath + "/FeedFiles/" + SellerID))
                    Directory.CreateDirectory(Application.StartupPath + "/FeedFiles/" + SellerID);
                string[] csvRows = System.IO.File.ReadAllLines(Application.StartupPath + "/FeedFiles/"+SellerID+"/" + FeedID + ".csv");
                string[] fields = null;
                for (int i = 0; i < csvRows.Count(); i++)
                {

                    try
                    {
                        fields = csvRows[i].Split(new string[] { "\t" }, StringSplitOptions.None);
                        if (i == 0)
                        {
                            for (int j = 0; j < fields.Count(); j++)
                            {
                                _Table.Columns.Add(fields[j]);
                            }
                        }
                        else
                        {
                            DataRow row = _Table.NewRow();
                            row.ItemArray = fields;
                            _Table.Rows.Add(row);
                        }

                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception Exp)
            {
                _Table.Rows.Clear();
                _Mail.SendMail("DbSync Function.Issue Occured in Read Feed File having id " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            try
            {
                if (_Table.Rows.Count > 0)
                {
                    DataTable _TableSku = new DataTable();
                    DataTable exceldt = new DataTable();
                    _TableSku.Columns.Add("SKU", System.Type.GetType("System.String"));
                    _TableSku.Columns.Add("Upc", System.Type.GetType("System.String"));
                    _TableSku.Columns.Add("asin", System.Type.GetType("System.String"));
                    _TableSku.Columns.Add("IsParent", System.Type.GetType("System.Int32"));
                    _TableSku.Columns.Add("ProductID", System.Type.GetType("System.Int32"));
                    _TableSku.Columns.Add("VariantID", System.Type.GetType("System.Int32"));

                    foreach (DataRow _Row in _Table.Rows)
                    {
                        DataRow Row = _TableSku.NewRow();
                        Row[0] = _Row["SKU"].ToString();
                        Row[1] = _Row["Upc"].ToString();
                        Row[2] = _Row["asin"].ToString();
                        Row[3] = _Row["IsParent"].ToString();
                        Row[4] = Convert.ToInt32(_Row["ProductID"]);
                        Row[5] = Convert.ToInt32(_Row["VariantID"]);
                        _TableSku.Rows.Add(Row);
                    }
                    #region ProcessFeedToDatabase
                    ProcessFeedToDatabase("MarketPlaceHub_MarkProductsAsDeletedInDatabase", Type, Response, _TableSku, FeedID);
                    #endregion ProcessFeedToDatabase
                }
            }
            catch (Exception Exp)
            {
                _Table.Rows.Clear();
                _Mail.SendMail("DbSync Function.Issue Occured in Generating datatables in order to sync to database for feed having ID is " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void ProcessFeedToDatabase(string StoredProcedure, int type, List<AmazonLister.Message> response, DataTable table, string FeedID)
        {
            try
            {
                #region ReadResponseOfFeed
                int noOfProductProcessed = 0;
                DataTable tableError = new DataTable();
                tableError.Columns.Add("SKU", typeof(string));
                tableError.Columns.Add("Error", typeof(string));
                tableError.Columns.Add("VariantID", typeof(Int32));
                tableError.Columns.Add("ProductID", typeof(Int32));
                List<string> errorSku = new List<string>();
                foreach (AmazonLister.Message Message in response)
                {
                    if (noOfProductProcessed == 0)
                        noOfProductProcessed = Message.ProcessingReport.ProcessingSummary.MessagesSuccessful;
                    foreach (Result Error in Message.ProcessingReport.Result)
                    {
                        if (Error.AdditionalInfo != null)
                        {
                            try
                            {
                                DataRow row = tableError.NewRow();
                                row[0] = Error.AdditionalInfo.SKU;
                                row[1] = Error.ResultDescription.Trim().Length > 8000 ? Error.ResultDescription.Trim().Substring(0, 7990) + "..." : Error.ResultDescription.Trim();
                                DataTable filterTable = (from _Record in table.AsEnumerable()
                                                         where _Record.Field<string>("SKU") == Error.AdditionalInfo.SKU
                                                         select _Record).CopyToDataTable();
                                row[2] = Convert.ToInt32(filterTable.Rows[0]["VariantID"]);
                                row[3] = Convert.ToInt32(filterTable.Rows[0]["ProductID"]);
                                tableError.Rows.Add(row);
                                if (!errorSku.Contains(Error.AdditionalInfo.SKU))
                                    errorSku.Add(Error.AdditionalInfo.SKU);
                                table.AcceptChanges();
                            }
                            catch { }
                        }
                    }
                }

                #region codeToDeleteRow
                foreach (string sku in errorSku)
                {
                    var results = (from _Record in table.AsEnumerable()
                                   where _Record.Field<string>("SKU") == sku
                                   select _Record).ToList();
                    results.ForEach(r => table.Rows.Remove(r));
                }
                #endregion codeToDeleteRow
                #endregion ReadResponseOfFeed

                #region InsertErrorInDatabase
                if (tableError.Rows.Count > 0)
                {
                    int noOfParts = 0;
                    int TotalNoOfRecords = tableError.Rows.Count;
                    if (TotalNoOfRecords % 2000 == 0)
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000);
                    else
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000) + 1;
                    for (int i = 0; i < noOfParts; i++)
                    {
                        _DB.GetDatasetByPassDatatable("MarkHub_ListingError", tableError.AsEnumerable().Skip(i * 2000).Take(2000).CopyToDataTable(), "@Table", CommandType.StoredProcedure, "@FeedID," + FeedID);
                    }
                }
                #endregion InsertErrorInDatabase

                #region SyncProductsToDatabase
                if (noOfProductProcessed > 0 && table.Rows.Count > 0)
                {
                    int noOfParts = 0;
                    int TotalNoOfRecords = table.Rows.Count;
                    if (TotalNoOfRecords % 2000 == 0)
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000);
                    else
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000) + 1;
                    for (int i = 0; i < noOfParts; i++)
                    {
                        _DB.GetDatasetByPassDatatable(StoredProcedure, table.AsEnumerable().Skip(i * 2000).Take(2000).CopyToDataTable(), "@Products", CommandType.StoredProcedure, "@Type," + type);
                    }
                }
                #endregion SyncProductsToDatabase
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured ProcessFeedToDatabase Function for feed having ID is " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void BindSellers()
        {
            try
            {
                _ListStores = new List<Store>();

                SqlDataReader _Reader = _DB.GetDR("select * from SellersAccountDetails order by sellerid");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {

                        try
                        {
                            AmazonLister.cls.Sellers seller = new AmazonLister.cls.Sellers();
                            seller.AccessKeyId = _Reader["AccessKeyId"].ToString();
                            seller.ApplicationName = _Reader["ApplicationName"].ToString();
                            seller.ApplicationVersion = _Reader["ApplicationVersion"].ToString();
                            seller.Currency = _Reader["Currency"].ToString();
                            seller.DocumentVersion = _Reader["DocumentVersion"].ToString();
                            seller.MarketplaceIdList = _Reader["MarketplaceIdList"].ToString();
                            seller.Merchant = _Reader["Merchant"].ToString();
                            seller.MerchantIdentifier = _Reader["MerchantIdentifier"].ToString();
                            seller.Password = _Reader["Password"].ToString();
                            seller.SecretKey = _Reader["SecretKey"].ToString();
                            seller.SellerID = Convert.ToInt32(_Reader["SellerID"]);
                            seller.ServiceURL = _Reader["ServiceURL"].ToString();
                            seller.UserName = _Reader["UserName"].ToString();
                            sellers.Add(seller);
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("Issue Occured in adding seller : " + _Reader["SellerID"].ToString() + " to Task List. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                try
                {
                    _Reader.Close();
                }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in binding Stores to TaskList. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
    }
    public class AMAZONTemplate
    {

        public string AmazontemplateName { get; set; }
        public bool Processed { get { return false; } set { value = false; } }
    }
    public class Procedures
    {
        public bool SizeParameter { get; set; }
        public string ProcedureName { get; set; }
        public AmazonLister.OperationType _Type { get; set; }
    }
    public class AmzFeedSubmission
    {
        public int FeedID { get; set; }
        public string FeedSubmissionID { get; set; }
    }
    public class Store
    {
        public int StoreID { get; set; }
        public string Name { get; set; }
    }
}
