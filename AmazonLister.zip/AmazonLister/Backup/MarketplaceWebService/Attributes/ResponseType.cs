﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarketplaceWebService.Attributes
{
    public enum ResponseType
    {
        STREAMING,
        DEFAULT,
    }
}
