﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarketplaceWebService.Attributes
{
    public enum StreamType
    {
        REQUEST_STREAM,
        RECEIVE_STREAM,
    }
}
