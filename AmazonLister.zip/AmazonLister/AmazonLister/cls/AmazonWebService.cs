﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Xml;
using MarketplaceWebService;
using MarketplaceWebService.Mock;
using MarketplaceWebService.Model;
using System.Text.RegularExpressions;

namespace AmazonLister
{
    public class AmazonWebService : IAmazonWebService
    {
        private string DocumentVersion = string.Empty;
        private string MerchantIdentifier = string.Empty;
        private string AccessKeyId = string.Empty;
        private string SecretAccessKey = string.Empty;
        private string ServiceURL = string.Empty;
        private string xsi = string.Empty;
        private string MarketplaceIdList = string.Empty;
        private string Merchant = string.Empty;
        private MarketplaceWebService.MarketplaceWebService service;
        private MarketplaceWebServiceConfig config;
        //public AmazonWebService()
        //{
        //    config = new MarketplaceWebServiceConfig();
        //    this.LoaLoadConfigdConfig();
        //    service = new MarketplaceWebServiceClient(AccessKeyId, SecretAccessKey, config);
        //}
        public AmazonWebService(AmazonLister.cls.Sellers seller)
        {
            config = new MarketplaceWebServiceConfig();
            config.ServiceURL = seller.ServiceURL;
            config.SetUserAgentHeader(
                 seller.ApplicationName,
                 seller.ApplicationVersion,
                 System.Configuration.ConfigurationManager.AppSettings["Language"].ToString(),
                 "<Parameter 1>", "<Parameter 2>");
            SecretAccessKey = seller.SecretKey;
            DocumentVersion = seller.DocumentVersion;
            MerchantIdentifier = seller.MerchantIdentifier;
            xsi = System.Configuration.ConfigurationManager.AppSettings["xsi"].ToString();
            AccessKeyId = seller.AccessKeyId;
            MarketplaceIdList = seller.MarketplaceIdList;
            Merchant = seller.Merchant;
            service = new MarketplaceWebServiceClient(AccessKeyId, SecretAccessKey, config);
        }
        private void LoadConfig()
        {
            try
            {
                config = LoadWebServiceConfig();
                SecretAccessKey = System.Configuration.ConfigurationManager.AppSettings["SecretKey"].ToString();
                DocumentVersion = System.Configuration.ConfigurationManager.AppSettings["DocumentVersion"].ToString();
                MerchantIdentifier = System.Configuration.ConfigurationManager.AppSettings["MerchantIdentifier"].ToString();
                xsi = System.Configuration.ConfigurationManager.AppSettings["xsi"].ToString();
                AccessKeyId = System.Configuration.ConfigurationManager.AppSettings["AccessKeyId"].ToString();

            }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }
        private MarketplaceWebServiceConfig LoadWebServiceConfig()
        {
            try
            {
                MarketplaceWebServiceConfig config = new MarketplaceWebServiceConfig();
                config.ServiceURL = System.Configuration.ConfigurationManager.AppSettings["ServiceURL"].ToString();
                config.SetUserAgentHeader(
                     System.Configuration.ConfigurationManager.AppSettings["applicationName"].ToString(),
                     System.Configuration.ConfigurationManager.AppSettings["applicationVersion"].ToString(),
                     System.Configuration.ConfigurationManager.AppSettings["Language"].ToString(),
                     "<Parameter 1>", "<Parameter 2>");
                return config;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }


        private void GetData()
        {

            throw new NotImplementedException();
        }
        private Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }
        private Header LoadHeader()
        {
            Header Header = new Header();
            Header.DocumentVersion = DocumentVersion;
            Header.MerchantIdentifier = MerchantIdentifier;
            return Header;
        }


        public FeedSubmissionInfo UploadProductSKU(List<Message> Messages)
        {
            try
            {
                FeedSubmissionInfo feedSubmissionInfo = new FeedSubmissionInfo();
                AmazonEnvelope AmazonEnvelope = new AmazonEnvelope();
                AmazonEnvelope.MessageType = MessageType.Product;
                AmazonEnvelope.Header = this.LoadHeader();
                AmazonEnvelope.Message = Messages;
                string XML = this.Serializer(AmazonEnvelope);
                SubmitFeedRequest request = new SubmitFeedRequest();
                request.Merchant = Merchant;
                request.MarketplaceIdList = new IdList();
                request.MarketplaceIdList.Id = new List<string>(new string[] { MarketplaceIdList });

                using (Stream Stream = GenerateStreamFromString(XML))
                {

                    request.FeedContent = Stream;
                    request.ContentMD5 = MarketplaceWebServiceClient.CalculateContentMD5(request.FeedContent);
                    request.FeedContent.Position = 0;
                    request.FeedType = FeedType._POST_PRODUCT_DATA_.ToString();
                    feedSubmissionInfo = ServiceRequest.InvokeSubmitFeed(service, request);


                }
                return feedSubmissionInfo;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public FeedSubmissionInfo UploadPrice(List<Message> Messages)
        {
            try
            {
                FeedSubmissionInfo feedSubmissionInfo = new FeedSubmissionInfo();
                AmazonEnvelope AmazonEnvelope = new AmazonEnvelope();
                AmazonEnvelope.MessageType = MessageType.Product;
                AmazonEnvelope.Header = this.LoadHeader();
                AmazonEnvelope.MessageType = MessageType.Price;
                AmazonEnvelope.Message = Messages;


                string XML = this.Serializer(AmazonEnvelope);

                SubmitFeedRequest request = new SubmitFeedRequest();
                request.Merchant = Merchant;
                request.MarketplaceIdList = new IdList();
                request.MarketplaceIdList.Id = new List<string>(new string[] { MarketplaceIdList });

                using (Stream Stream = GenerateStreamFromString(XML))
                {
                    request.FeedContent = Stream;
                    request.ContentMD5 = MarketplaceWebServiceClient.CalculateContentMD5(request.FeedContent);
                    request.FeedContent.Position = 0;
                    request.FeedType = FeedType._POST_PRODUCT_PRICING_DATA_.ToString();
                    feedSubmissionInfo = ServiceRequest.InvokeSubmitFeed(service, request);

                }
                return feedSubmissionInfo;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public FeedSubmissionInfo UploadInventory(List<Message> Messages)
        {
            try
            {
                FeedSubmissionInfo feedSubmissionInfo = new FeedSubmissionInfo();
                AmazonEnvelope AmazonEnvelope = new AmazonEnvelope();
                AmazonEnvelope.MessageType = MessageType.Product;
                AmazonEnvelope.Header = this.LoadHeader();
                AmazonEnvelope.MessageType = MessageType.Inventory;
                AmazonEnvelope.Message = Messages;


                string XML = this.Serializer(AmazonEnvelope);

                SubmitFeedRequest request = new SubmitFeedRequest();
                request.Merchant = Merchant;
                request.MarketplaceIdList = new IdList();
                request.MarketplaceIdList.Id = new List<string>(new string[] { MarketplaceIdList });

                using (Stream Stream = GenerateStreamFromString(XML))
                {
                    request.FeedContent = Stream;
                    request.ContentMD5 = MarketplaceWebServiceClient.CalculateContentMD5(request.FeedContent);
                    request.FeedContent.Position = 0;
                    request.FeedType = FeedType._POST_INVENTORY_AVAILABILITY_DATA_.ToString();
                    feedSubmissionInfo = ServiceRequest.InvokeSubmitFeed(service, request);

                }
                return feedSubmissionInfo;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public FeedSubmissionInfo UploadImages(List<Message> Messages)
        {
            try
            {
                FeedSubmissionInfo feedSubmissionInfo = new FeedSubmissionInfo();
                AmazonEnvelope AmazonEnvelope = new AmazonEnvelope();
                AmazonEnvelope.MessageType = MessageType.ProductImage;
                AmazonEnvelope.Header = this.LoadHeader();
                AmazonEnvelope.Message = Messages;


                string XML = this.Serializer(AmazonEnvelope);

                SubmitFeedRequest request = new SubmitFeedRequest();
                request.Merchant = Merchant;
                request.MarketplaceIdList = new IdList();
                request.MarketplaceIdList.Id = new List<string>(new string[] { MarketplaceIdList});

                using (Stream Stream = GenerateStreamFromString(XML))
                {
                    request.FeedContent = Stream;
                    request.ContentMD5 = MarketplaceWebServiceClient.CalculateContentMD5(request.FeedContent);
                    request.FeedContent.Position = 0;
                    request.FeedType = FeedType._POST_PRODUCT_IMAGE_DATA_.ToString();
                    feedSubmissionInfo = ServiceRequest.InvokeSubmitFeed(service, request);

                }
                return feedSubmissionInfo;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public FeedSubmissionInfo UploadShipping(List<Message> Messages)
        {
            try
            {
                FeedSubmissionInfo feedSubmissionInfo = new FeedSubmissionInfo();
                AmazonEnvelope AmazonEnvelope = new AmazonEnvelope();
                AmazonEnvelope.MessageType = MessageType.Override;
                AmazonEnvelope.Header = this.LoadHeader();
                AmazonEnvelope.MessageType = MessageType.Override;
                AmazonEnvelope.Message = Messages;


                string XML = this.Serializer(AmazonEnvelope);

                SubmitFeedRequest request = new SubmitFeedRequest();
                request.Merchant = Merchant;
                request.MarketplaceIdList = new IdList();
                request.MarketplaceIdList.Id = new List<string>(new string[] { MarketplaceIdList});

                using (Stream Stream = GenerateStreamFromString(XML))
                {
                    request.FeedContent = Stream;
                    request.ContentMD5 = MarketplaceWebServiceClient.CalculateContentMD5(request.FeedContent);
                    request.FeedContent.Position = 0;
                    request.FeedType = FeedType._POST_PRODUCT_OVERRIDES_DATA_.ToString();
                    feedSubmissionInfo = ServiceRequest.InvokeSubmitFeed(service, request);

                }
                return feedSubmissionInfo;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UploadRelation()
        {
            throw new NotImplementedException();
        }
        public void DownloadOrders()
        {
            throw new NotImplementedException();
        }

        public List<Message> CheckFeedStatus(string FeedSubmissionID, string Path)
        {
            List<Message> Messages = new List<Message>();
            try
            {
                GetFeedSubmissionResultResult GetFeedSubmissionResultResult = new GetFeedSubmissionResultResult();
                GetFeedSubmissionResultRequest request = new GetFeedSubmissionResultRequest();
                request.Merchant = Merchant;
                request.FeedSubmissionId = FeedSubmissionID;
                Stream Stream = File.Open(Path, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                request.FeedSubmissionResult = Stream;
                bool Error = false;
                try
                {
                    GetFeedSubmissionResultResult = ServiceRequest.InvokeGetFeedSubmissionResult(service, request);
                }
                catch
                { Error = true; }
                Stream.Dispose();
                if (!Error)
                {
                    int timeCounter = 0;
                    while (!FileIsInUse(Path) && timeCounter < 101)
                    {
                        System.Threading.Thread.Sleep(30000);
                        timeCounter++;
                    }

                    string XML = System.IO.File.ReadAllText(Path);
                    AmazonEnvelope AmazonEnvelope = new AmazonEnvelope();
                    XmlSerializer Serializer = new XmlSerializer(typeof(AmazonEnvelope));
                    using (TextReader reader = new StringReader(XML))
                    {
                        AmazonEnvelope = (AmazonEnvelope)(Serializer.Deserialize(reader));
                    }
                    Messages = AmazonEnvelope.Message;
                }

            }
            catch (Exception ex)
            {

            }
            return Messages;
        }

        private string Serializer(AmazonEnvelope lAmazonEnvelope)
        {
            try
            {
                XmlDocument document = new XmlDocument();
                XmlSerializerNamespaces xmlns = new XmlSerializerNamespaces();
                xmlns.Add("xsi", xsi);
                XmlSerializer serializer = new XmlSerializer(typeof(AmazonEnvelope));
                StringWriter writer = new StringWriter();
                serializer.Serialize(writer, lAmazonEnvelope, xmlns);
                document.LoadXml(writer.ToString());

                if (document.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                {
                    XmlDeclaration xmlDeclaration = (XmlDeclaration)document.FirstChild;
                    xmlDeclaration.Encoding = "iso-8859-1";
                }



                return document.InnerXml;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }
        #region ReportSection
        public RequestReportResponse GetRport(int reportType, int StartDate)
        {
            RequestReportResponse RequestReportRes = new RequestReportResponse();
            try
            {
                RequestReportRequest RequestReportReq = new RequestReportRequest();
                switch (Convert.ToInt32(reportType))
                {
                    case 0:
                        RequestReportReq.ReportType = "_GET_FLAT_FILE_OPEN_LISTINGS_DATA_";
                        break;
                    case 1:
                        RequestReportReq.ReportType = "_GET_MERCHANT_LISTINGS_DATA_";
                        break;
                    case 2:
                        RequestReportReq.ReportType = "_GET_MERCHANT_LISTINGS_DATA_BACK_COMPAT_";
                        break;
                    case 3:
                        RequestReportReq.ReportType = "_GET_MERCHANT_LISTINGS_DATA_LITE_";
                        break;
                    case 4:
                        RequestReportReq.ReportType = "_GET_MERCHANT_LISTINGS_DATA_LITER_";
                        break;
                    case 5:
                        RequestReportReq.ReportType = "_GET_MERCHANT_CANCELLED_LISTINGS_DATA_";
                        break;
                    case 6:
                        RequestReportReq.ReportType = "_GET_CONVERGED_FLAT_FILE_SOLD_LISTINGS_DATA_";
                        break;
                    case 7:
                        RequestReportReq.ReportType = "_GET_MERCHANT_LISTINGS_DEFECT_DATA_";
                        break;
                    default:
                        break;
                }
                RequestReportReq.StartDate = DateTime.Now.AddDays(StartDate);
                RequestReportReq.EndDate = DateTime.Now;
                RequestReportReq.Merchant = Merchant;
                RequestReportReq.MarketplaceIdList = new IdList();
                RequestReportReq.MarketplaceIdList.Id = new List<string>(new string[] { MarketplaceIdList });
                RequestReportRes = service.RequestReport(RequestReportReq);
                int timeCounter = 0;
                while (RequestReportRes.RequestReportResult == null && timeCounter < 2)
                {
                    System.Threading.Thread.Sleep(60000);
                    timeCounter++;
                }
            }
            catch
            {
            }
            return RequestReportRes;
        }
        public GetReportResponse ReportData(string reportID, string path, string Token)
        {
            GetReportResponse ReportRes = new GetReportResponse();
            try
            {
                GetReportListRequest ReportListReq = new GetReportListRequest();
                ReportListReq.Merchant = Merchant; ;
                ReportListReq.ReportRequestIdList = new IdList();
                ReportListReq.ReportRequestIdList.Id = new List<string>(new string[] { reportID });
                GetReportListResponse ReportListRes = service.GetReportList(ReportListReq);
                int timeCounter = 0;
                while (timeCounter < 5 && (ReportListRes.GetReportListResult.ReportInfo.Count <= 0 || !ReportListRes.GetReportListResult.ReportInfo[0].IsSetReportId()))
                {
                    System.Threading.Thread.Sleep(60000);
                    ReportListRes = service.GetReportList(ReportListReq);

                    timeCounter++;
                }
                reportID = ReportListRes.GetReportListResult.ReportInfo[0].ReportId;
                GetReportRequest ReportReq = new GetReportRequest();
                ReportReq.Merchant = Merchant;
                ReportReq.ReportId = reportID;
                if (Token != "")
                    ReportReq.WithMWSAuthToken(Token);
                else
                    ReportReq.WithReportId(reportID);
                Stream Stream = File.Open(path, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                ReportReq.Report = Stream;
                ReportRes = service.GetReport(ReportReq);
                Stream.Dispose();
                timeCounter = 0;
                while (!FileIsInUse(path) && timeCounter < 2)
                {
                    System.Threading.Thread.Sleep(60000);
                    timeCounter++;
                }
            }
            catch
            {
            }
            return ReportRes;
        }
        #endregion ReportSection

        public bool FileIsInUse(string path)
        {
            try
            {
                File.ReadAllLines(path);
                return true;
            }
            catch
            { return false; }
        }
    }

}
