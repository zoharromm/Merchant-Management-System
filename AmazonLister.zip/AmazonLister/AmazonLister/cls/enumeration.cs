﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace AmazonLister
{
    public enum ListMessageType
    {
        SubmitSKU = 0,
        SubmitPrice = 1,
        SubmitQuantuty = 2,
        SubmitImages = 3,
        SubmitShipping = 4

    }
    public enum ReportType
    {
        _GET_FLAT_FILE_OPEN_LISTINGS_DATA_ = 0,
        _GET_MERCHANT_LISTINGS_DATA_ = 1,
        _GET_MERCHANT_LISTINGS_DATA_BACK_COMPAT_ = 2,
        _GET_MERCHANT_LISTINGS_DATA_LITE_ = 3,
        _GET_MERCHANT_LISTINGS_DATA_LITER_ = 4,
        _GET_MERCHANT_CANCELLED_LISTINGS_DATA_ = 5,
        _GET_CONVERGED_FLAT_FILE_SOLD_LISTINGS_DATA_ = 6,
        _GET_MERCHANT_LISTINGS_DEFECT_DATA_ = 7
    }
    public enum MiscType
    {
        Antiques,
        Art,
        Car_Parts_and_Accessories,
        Coins,
        Collectibles,
        Crafts,
        Event_Tickets,
        Flowers,
        Gifts_and_Occasions,
        Gourmet_Food_and_Wine,
        Hobbies,
        Home_Furniture_and_Decor,
        Home_Lighting_and_Lamps,
        Home_Organizers_and_Storage,
        Jewelry_and_Gems,
        Luggage,
        Major_Home_Appliances,
        Medical_Supplies,
        Motorcycles,
        Musical_Instruments,
        Pet_Supplies,
        Pottery_and_Glass,
        Prints_and_Posters,
        Scientific_Supplies,
        Sporting_and_Outdoor_Goods,
        Sports_Memorabilia,
        Stamps,
        Teaching_and_School_Supplies,
        Watches,
        Wholesale_and_Industrial,
        Misc_Other
    }

    public enum MessageType
    {
        FulfillmentCenter,
        Inventory,
        Listings,
        OrderAcknowledgement,
        OrderAdjustment,
        Order,
        Fulfillment,
        Override,
        Price,
        ProcessingReport,
        Product,
        ProductImage,
        Relationship,
        SettlementReport
    }
    public enum Parentage
    {
        parent,
        child
    }

    public enum ProductType
    {
        SportingGoods,
        GolfClubHybrid,
        ToysAndGames,
        //video games
        VideoGames,
        VideoGamesAccessories,
        VideoGamesHardware,
        Luggage,
        BeautyMisc, ClothingAccessories, SportsMemorabilia

    }

    public enum SafetyRating
    {
        [Description("BSI 658 Type A Certified")]
        BSI_658_Type_A_Certified,
        [Description("DOT Certified")]
        DOT_Certified,
        [Description("EN 22/05 Certified")]
        EN_22__05_Certified,
        Novelty,
        Other,
        Snell_K2005_Certified,
        [Description("Snell K-98 Certified")]
        Snell_K___98_Certified,
        Snell_M2000_Certified,
        Snell_M2005_Certified,
        [Description("Snell M-95 Certified")]
        Snell_M___95_Certified,
        [Description("Snell N-94 Certified")]
        Snell_N___94_Certified,
        [Description("Snell RS-98 Certified")]
        Snell_RS___98_Certified,
        [Description("Snell S-98 Certified")]
        Snell_S___98_Certified,
        [Description("Snell SA2000 Certified")]
        Snell_SA2000_Certified,
        [Description("Snell SA2006 Certified")]
        Snell_SA2006_Certified,
        [Description("Snell SA-95 Certified")]
        Snell_SA___95_Certified,
        Snell_2010_Certified
    }
    public enum CameraType
    {
        [Description("point-and-shoot")]
        pointandshoot,
        [Description("single-use")]
        singleuse,
        [Description("large-format")]
        largeformat,
        [Description("medium-format")]
        mediumformat,
        [Description("3-dt")]
        threed,
        slr,
        instant,
        rangefinder,
        field,
        monorail,
        kids,
        micro,
        panorama,
        underwater,
        other,
    }
    public enum AnalogFormats
    {
        general,
        [Description("8mm")]
        eightmm,
        [Description("betacam-sp")]
        betacamsp,
        [Description("hi-8")]
        hi8,
        [Description("s-vhs")]
        svhs,
        [Description("s-vhs-c")]
        svhsc,
        vhs,
        [Description("vhsc")]
        vhsc,
        other,
    }


    public enum DigitalFormats
    {
        general,
        [Description("digital-betacam")]
        digitalbetacam,
        dv,
        dvcam,
        dvcpro,
        minidv,
        micromv,
        digital8,
        dvd,
        minidisc,
        other,
    }
    public enum FocusType
    {
        automatic, manual,
        [Description("manual-and-auto")]
        manualandauto,
        [Description("focus-free")]
        focusfree
    }
    public enum ClothingType
    {
        Gloves, Jacket, Pants, Shirt, Shoes, Suit, Underwear
    }
    public enum BinocularType
    {
        binoculars,
        monoculars,
        [Description("laser-rangefinders")]
        laserrangefinders,
        [Description("spotting-scopes")]
        spottingscopes,
        [Description("night-vision")]
        nightvision
    }
    public enum SurveillanceSystemType
    {
        cameras,
        [Description("complete-systems")]
        completesystems,
        monitors,
        [Description("network-systems")]
        networksystems,
        multiplexer,
    }
    public enum TelescopeType
    {
        general,
        [Description("mirror-lens")]
        mirrorlens,
        [Description("schmidt-cassegrain")]
        schmidtcassegrain,
        [Description("maksutov-cassegrain")]
        maksutovcassegrain,
        reflecting,
        [Description("newtonian-reflector")]
        newtonianreflector,
        [Description("rich-field-reflector")]
        richfieldreflector,
        [Description("dobsonian-reflector")]
        dobsonianreflector,
        refracting,
        [Description("achromatic-refractor")]
        achromaticrefractor,
        [Description("apochromatic-refractor")]
        apochromaticrefractor,
    }

    public enum ProjectionType
    {
        [Description("slide-projectors")]
        slideprojectors,
        [Description("video-projectorsr")]
        videoprojectors,
        [Description("large-format-projectors")]
        largeformatprojectors,
        [Description("medium-format-projectors")]
        mediumformatprojectors,
        [Description("multimedia-projectors")]
        multimediaprojectors,
        [Description("opaque-projectors")]
        opaqueprojectors,
        lightboxes,
        viewers,
        loupes,
    }
    public enum CameraAccessories
    {
        [Description("close-up-accessories")]
        closeupaccessories,
        viewfinders,
        [Description("motor-drives")]
        motordrives,
        [Description("eye-cups")]
        eyecups,
        winders,
        straps,
        [Description("remote-controls")]
        remotecontrols,
        [Description("cables-and-cords")]
        cablesandcords,
        [Description("other-camera-accessories")]
        othercameraaccessories,
    }
    public enum MicroscopeType
    {
        [Description("digital-and-film-systems")]
        digitalandfilmsystems,
        [Description("educational-and-hobbyr")]
        educationalandhobby,
        laboratory,
        stereo,
        other,
    }
    public enum VariationTheme
    {
        Color,
        Size,
        SizeColor,
        Flavor,
        FlavorSize,
        PatternName,
        ColorPatternName,
        PatternNameSize,
        PatternNameFlavor,
        Scent,
        Size_Color,
        StyleName_CustomerPackageType,
        SizeName_StyleName_CustomerPackageType,
        SizeStyle,
        ColorStyle,
        Style,
        ColorSize,
        StyleName_Color,
        StyleName_Size,
        BandColor
    }
    public enum OperationType
    {
        Update,
        Delete,
        PartialUpdate
    }

    public enum ImageType
    {
        Main,
        Swatch,
        BKLB,
        PT1,
        PT2,
        PT3,
        PT4,
        PT5,
        PT6,
        PT7,
        PT8,
        Search,
        PM01,
        MainOfferImage,
        OfferImage1,
        OfferImage2,
        OfferImage3,
        OfferImage4,
        OfferImage5
    }
    public enum FeedType
    {
        _POST_PRODUCT_DATA_,
        _POST_PRODUCT_PRICING_DATA_,
        _POST_INVENTORY_AVAILABILITY_DATA_,
        _POST_PRODUCT_IMAGE_DATA_,
        _POST_PRODUCT_OVERRIDES_DATA_
    }

    public enum Type
    {
        ISBN,
        UPC,
        EAN,
        ASIN,
        GTIN
    }
    public enum GtinExemptionReason
    {
        bundle,
        part
    }

    public enum currency
    {
        DEFAULT,
        USD,
        GBP,
        EUR,
        JPY,
        CAD

    }



}
