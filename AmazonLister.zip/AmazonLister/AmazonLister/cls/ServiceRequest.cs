﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MarketplaceWebService;
using MarketplaceWebService.Mock;
using MarketplaceWebService.Model;

namespace AmazonLister
{
    // Class Id from 221-220
    class ServiceRequest
    {
        //201
        public static FeedSubmissionInfo InvokeSubmitFeed(MarketplaceWebService.MarketplaceWebService service, SubmitFeedRequest request)
        {
            FeedSubmissionInfo feedSubmissionInfo = new FeedSubmissionInfo();

            try
            {
                SubmitFeedResponse response = service.SubmitFeed(request);
                SubmitFeedResult submitFeedResult = response.SubmitFeedResult;
                feedSubmissionInfo = submitFeedResult.FeedSubmissionInfo;
                return feedSubmissionInfo;

            }
            catch (MarketplaceWebServiceException ex)
            {
                throw new Exception("Error " + Environment.NewLine +
                                    "Error Code1 : 221" + Environment.NewLine +
                                    "Error Code2 : " + ex.ErrorCode + Environment.NewLine +
                                    "Error Type: " + ex.ErrorType + Environment.NewLine +
                                    "Request ID: " + ex.RequestId + Environment.NewLine +
                                    "XML: " + ex.ErrorCode);

            }


        }
        public static GetFeedSubmissionResultResult InvokeGetFeedSubmissionResult(MarketplaceWebService.MarketplaceWebService service, GetFeedSubmissionResultRequest request)
        {
            try
            {
                GetFeedSubmissionResultResult getFeedSubmissionResultResult = new GetFeedSubmissionResultResult();
                GetFeedSubmissionResultResponse response = service.GetFeedSubmissionResult(request);
                if (response.IsSetGetFeedSubmissionResultResult())
                {
                    getFeedSubmissionResultResult = response.GetFeedSubmissionResultResult;


                }
                return getFeedSubmissionResultResult;
            }
            catch (MarketplaceWebServiceException ex)
            {
                throw new Exception("Error " + Environment.NewLine +
                                   "Error Code1 : 222" + Environment.NewLine +
                                   "Error Code2 : " + ex.ErrorCode + Environment.NewLine +
                                   "Error Type: " + ex.ErrorType + Environment.NewLine +
                                   "Request ID: " + ex.RequestId + Environment.NewLine +
                                   "XML: " + ex.XML);
            }
        }
    }
}
