﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;


namespace AmazonLister
{
    public class Product
    {
        [XmlElement]
        public string SKU { get; set; }
        [XmlElement]
        public StandardProductID StandardProductID { get; set; }
        [XmlElement]
        public GtinExemptionReason GtinExemptionReason { get; set; }
        [XmlElement]
        public string RelatedProductID { get; set; }
        [XmlElement]
        public string ProductTaxCode { get; set; }
        [XmlElement]
        public Condition Condition { get; set; }
        [XmlElement]
        public string ItemPackageQuantity { get; set; }
        [XmlElement]
        public DescriptionData DescriptionData { get; set; }
        [XmlElement]
        public ProductData ProductData { get; set; }
    }
    public class StandardProductID
    {
        [XmlElement]
        public Type Type { get; set; }
        [XmlElement]
        public string Value { get; set; }
    }


    public class DescriptionData
    {

        [XmlElement]
        public string Title { get; set; }
        [XmlElement]
        public string Brand { get; set; }
        [XmlElement]
        public string Description { get; set; }
        [XmlElement]
        public List<string> BulletPoint { get; set; }
        [XmlElement]
        public ShippingWeight ShippingWeight { get; set; }
        [XmlElement]
        public MSRP MSRP { get; set; }
        [XmlElement]
        public int MaxOrderQuantity { get; set; }
        [XmlElement]
        public string Manufacturer { get; set; }
        [XmlElement]
        public string MfrPartNumber { get; set; }

        [XmlElement]
        public string ItemType { get; set; }
        [XmlElement]
        public string TargetAudience { get; set; }
        [XmlElement]
        public bool IsGiftWrapAvailable { get; set; }
        [XmlElement]
        public bool IsGiftMessageAvailable { get; set; }
        [XmlElement]
        public string RecommendedBrowseNode { get; set; }

    }
    public class Condition
    {
        [XmlElement]
        public string ConditionType { get; set; }
        public string ConditionNote{get;set;}
    }
    public class ShippingWeight
    {
        [XmlAttribute("unitOfMeasure")]
        public string unitOfMeasure { get; set; }
        [XmlText]
        public Decimal Value { get; set; }
    }
    public class MSRP
    {
        [XmlAttribute("currency")]
        public string currency { get; set; }
        [XmlText]
        public Decimal Value { get; set; }
    }

    #region ProductData
    public class ProductData
    {
        public Miscellaneous Miscellaneous { get; set; }
        public Sports Sports { get; set; }
        public PetSupplies PetSupplies { get; set; }
        public ToysBaby ToysBaby { get; set; }
        public SoftwareVideoGames SoftwareVideoGames { get; set; }
        public Baby Baby { get; set; }
        public Home Home { get; set; }
        public Luggage Luggage { get; set; }
        public CE CE { get; set; }
        public Beauty Beauty { get; set; }
        public AutoAccessory AutoAccessory { get; set; }
        public CameraPhoto CameraPhoto { get; set; }
        public Wireless Wireless { get; set; }
        public FoodAndBeverages FoodAndBeverages { get; set; }
        public Health Health { get; set; }
        public Jewelry Jewelry { get; set; }
        public LargeAppliances LargeAppliances { get; set; }
        public MusicalInstruments MusicalInstruments { get; set; }
        public HomeImprovement HomeImprovement { get; set; }
        public ClothingAccessories ClothingAccessories { get; set; }
        public Office Office { get; set; }
        public SportsMemorabilia SportsMemorabilia { get; set; }
        public Computers Computers { get; set; }
        public Video Video { get; set; }
    }
    #endregion ProductData

    #region Sports
    public class Sports
    {
        public ProductType ProductType { get; set; }
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string ColorMap { get; set; }
        [XmlElement]
        public string SizeMap { get; set; }
       


        public string PatternStyle { get; set; }
        public string RiseStyle { get; set; }
        public string SkiStyle { get; set; }
        public string SockStyle { get; set; }
        public string SnowboardStyle { get; set; }
        public string TopStyle { get; set; }
        public string BeltStyle { get; set; }
        public string BottomStyle { get; set; }
    }
    #endregion Sports

    #region ToysBaby
    public class ToysBaby
    {
        public ProductType ProductType { get; set; }
        [XmlElement]
        public AgeRecommendation AgeRecommendation { get; set; }
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }

    }
    public class AgeRecommendation
    {
        [XmlElement("MinimumManufacturerAgeRecommended")]
        public MinimumManufacturerAgeRecommended MinimumManufacturerAgeRecommended1 { get; set; }
        [XmlElement("MaximumManufacturerAgeRecommended")]
        public MaximumManufacturerAgeRecommended MaximumManufacturerAgeRecommended1 { get; set; }

    }
    public class MinimumManufacturerAgeRecommended
    {
        [XmlAttribute("unitOfMeasure")]
        public string unitOfMeasure { get; set; }
        [XmlText]
        public string Value { get; set; }
    }
    public class MaximumManufacturerAgeRecommended
    {
        [XmlAttribute("unitOfMeasure")]
        public string unitOfMeasure { get; set; }
        [XmlText]
        public string Value { get; set; }
    }
    #endregion ToysBaby

    #region videoGamesCategory
    public class SoftwareVideoGames
    {
        [XmlElement("ProductType")]
        public SoftwareVideoGamesType ProductType { get; set; }
        [XmlElement]
        public string Parentage { get; set; }
        [XmlElement]
        public string VariationTheme { get; set; }
        public string ColorName { get; set; }
        public string Size { get; set; }
        public string StyleName { get; set; }

    }
    public class SoftwareVideoGamesType
    {
        public VideoGames VideoGames { get; set; }
        public SoftwareGames SoftwareGames { get; set; }
        public Software Software { get; set; }
        public VideoGamesAccessories VideoGamesAccessories { get; set; }
        public VideoGamesHardware VideoGamesHardware { get; set; }
        [XmlElement]
        public VariationData VariationData { get; set; }
    }
    public class VideoGames
    {
        [XmlElement]
        public List<string> ConsoleVideoGamesGenre { get; set; }
        [XmlElement]
        public string ESRBRating { get; set; }
        [XmlElement]
        public string BBFCRating { get; set; }
        [XmlElement]
        public string PEGIRating { get; set; }
        [XmlElement]
        public string USKRating { get; set; }
        public string HardwarePlatform { get; set; }

    }


    public class Software
    {
        [XmlElement]
        public List<string> MediaFormat { get; set; }
        [XmlElement]
        public List<string> OperatingSystem { get; set; }
    }
    public class VideoGamesAccessories
    {
        [XmlElement]
        public string HardwarePlatform { get; set; }
    }
    public class SoftwareGames
    {
        [XmlElement]
        public List<string> SoftwareVideoGamesGenre { get; set; }
        [XmlElement]
        public string ESRBRating { get; set; }
        [XmlElement]
        public string OperatingSystem { get; set; }
    }
    public class VideoGamesHardware
    {
        [XmlElement]
        public string HardwarePlatform { get; set; }
    }
    #endregion videoGamesCategory

    #region PetSupplies
    public class PetSupplies
    {
        [XmlElement("ProductType")]
        public clsProductType ProductType { get; set; }
    }

    public class clsProductType
    {
        public PetSuppliesMisc PetSuppliesMisc { get; set; }

    }


    public class PetSuppliesMisc
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class VariationData
    {
        [XmlElement]
        public Parentage? Parentage { get; set; }
        [XmlElement]
        public VariationTheme VariationTheme { get; set; }

    }


    public class Miscellaneous
    {
        [XmlElement("ProductType")]
        public MiscType ProductType { get; set; }

    }
    #endregion PetSupplies

    #region Baby

    public class Baby
    {
        [XmlElement("ProductType")]
        public BabyType ProductType { get; set; }
    }

    public class BabyType
    {
        public BabyProducts BabyProducts { get; set; }
    }
    public class BabyProducts
    {
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }

        public MinimumManufacturerAgeRecommended MinimumManufacturerAgeRecommended { get; set; }
    }

    #endregion Baby

    #region HomeKitchen
    public class Home
    {
        [XmlElement("ProductType")]
        public HomeType ProductType { get; set; }
    }

    public class HomeType
    {

        public HomeClass Home { get; set; }
        public Kitchen Kitchen { get; set; }
        public FurnitureAndDecor FurnitureAndDecor { get; set; }
        public BedAndBath BedAndBath { get; set; }
        public SeedsAndPlants SeedsAndPlants { get; set; }
        public Art Art { get; set; }
    }
    public class HomeClass
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }
    }
    public class Kitchen
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }
    }
    public class FurnitureAndDecor
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }
    }
    public class BedAndBath
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }
    }
    public class SeedsAndPlants
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }
    }
    public class Art
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string StyleName { get; set; }
    }
    #endregion HomeKitchen

    #region Luggage
    public class Luggage
    {
        public ProductType ProductType { get; set; }
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }

    }
    #endregion Luggage

    #region Electronics
    public class CE
    {
        [XmlElement("ProductType")]
        public CEType ProductType { get; set; }

    }
    public class CEType
    {
        public CameraBagsAndCases CameraBagsAndCases { get; set; }
        public CEBattery CEBattery { get; set; }
        public CameraLenses CameraLenses { get; set; }
        public CEDigitalCamera CEDigitalCamera { get; set; }
        public Headphones Headphones { get; set; }
        public PC PC { get; set; }
        public Phone Phone { get; set; }
        public PhoneAccessory PhoneAccessory { get; set; }
        public ConsumerElectronics ConsumerElectronics { get; set; }

    }
    public class ConsumerElectronics
    {

    }
    public class PhoneAccessory
    {
        [XmlElement]
        public string BatteryCellType { get; set; }
        [XmlElement]
        public string BatteryChargeCycles { get; set; }
        [XmlElement]
        public string BatteryPower { get; set; }
    }
    public class Phone
    {
        [XmlElement]
        public string Efficiency { get; set; }
        [XmlElement]
        public string ProcessorBrand { get; set; }
        [XmlElement]
        public string ProcessorSpeed { get; set; }
        [XmlElement]
        public string RAMSize { get; set; }
    }
    public class PC
    {
        [XmlElement]
        public List<string> HardDriveSize { get; set; }//required
        [XmlElement]
        public List<string> HardDriveInterface { get; set; }//required
        [XmlElement]
        public string RAMSize { get; set; }//required
        [XmlElement]
        public string ProcessorBrand { get; set; }//required
        [XmlElement]
        public string ProcessorSpeed { get; set; }//required
        [XmlElement]
        public string ProcessorType { get; set; }//required
        [XmlElement]
        public int ProcessorCount { get; set; }//required
    }
    public class Headphones
    {
        [XmlElement]
        public string BatteryCellType { get; set; }
        [XmlElement]
        public string Efficiency { get; set; }
    }
    public class CameraBagsAndCases
    {
        [XmlElement]
        public string BoxContents { get; set; }
        [XmlElement]
        public string MaxWeightCapacity { get; set; }
        [XmlElement]
        public string PowerPlugType { get; set; }
        [XmlElement]
        public string Efficiency { get; set; }
    }
    public class CEBattery
    {
        [XmlElement]
        public int BatteryChargeCycles { get; set; }
        [XmlElement]
        public string BatteryCellType { get; set; }
        [XmlElement]
        public string PowerPlugType { get; set; }
        [XmlElement]
        public string Wattage { get; set; }
        [XmlElement]
        public string Efficiency { get; set; }
    }
    public class CameraLenses
    {
        [XmlElement]
        public string BatteryCellType { get; set; }
        [XmlElement]
        public int BatteryChargeCycles { get; set; }
        [XmlElement]
        public string BatteryPower { get; set; }
        [XmlElement]
        public string DigitalZoom { get; set; }
        [XmlElement]
        public string Lens { get; set; }
    }
    public class CEDigitalCamera
    {
        public List<string> AnalogRGBInput { get; set; }
        public string BatteryCellType { get; set; }
        public string BatteryPower { get; set; }
    }
    #endregion Electronics

    #region Beauty
    public class Beauty
    {
        [XmlElement("ProductType")]
        public BeautyType ProductType { get; set; }


    }
    public class BeautyType
    {
        public BeautyMisc BeautyMisc { get; set; }
    }
    public class BeautyMisc
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    #endregion Beauty

    #region AutoAccessory
    public class AutoAccessory
    {
        [XmlElement("ProductType")]
        public AutoAccessoryType ProductType { get; set; }

    }
    public class AutoAccessoryType
    {
        public AutoAccessoryMisc AutoAccessoryMisc { get; set; }
        public AutoPart AutoPart { get; set; }
        public PowersportsPart PowersportsPart { get; set; }
        public PowersportsVehicle PowersportsVehicle { get; set; }
        public ProtectiveGear ProtectiveGear { get; set; }
        public Helmet Helmet { get; set; }
        public RidingApparel RidingApparel { get; set; }
        public Tire Tire { get; set; }
        public Rims Rims { get; set; }
        public TireAndWheel TireAndWheel { get; set; }
        public Vehicle Vehicle { get; set; }
        public Motorcyclepart Motorcyclepart { get; set; }
        public Motorcycleaccessory Motorcycleaccessory { get; set; }
        public Ridinggloves Ridinggloves { get; set; }
        public Ridingboots Ridingboots { get; set; }
        public Autooil Autooil { get; set; }
        public Autobattery Autobattery { get; set; }
        public Autochemical Autochemical { get; set; }


    }
    public class AutoAccessoryMisc
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class AutoPart
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class PowersportsPart
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class PowersportsVehicle
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ProtectiveGear
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        [XmlElement]
        public List<string> Department { get; set; }
        [XmlElement]
        public List<string> StyleKeywords { get; set; }
        [XmlElement]
        public string ModelName { get; set; }
    }
    public class Helmet
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        [XmlElement]
        public List<string> Department { get; set; }
        [XmlElement]
        public List<string> StyleKeywords { get; set; }
        [XmlElement]
        public string ModelName { get; set; }
        public List<SafetyRating> SafetyRating { get; set; }
    }
    public class RidingApparel
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        [XmlElement]
        public List<string> Department { get; set; }
        [XmlElement]
        public List<string> StyleKeywords { get; set; }
        [XmlElement]
        public string ModelName { get; set; }
        public ClothingType ClothingType { get; set; }

    }
    public class Tire
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Rims
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }

    public class TireAndWheel
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Vehicle
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Motorcyclepart
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Motorcycleaccessory
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Ridinggloves
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Ridingboots
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Autooil
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Autobattery
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Autochemical
    {

    }

    #endregion Electronics

    #region CameraPhoto
    public class CameraPhoto
    {
        [XmlElement("ProductType")]
        public CameraPhotoType ProductType { get; set; }
    }
    public class CameraPhotoType
    {
        public FilmCamera FilmCamera { get; set; }
        public Camcorder Camcorder { get; set; }
        public DigitalCamera DigitalCamera { get; set; }
        public Binocular Binocular { get; set; }
        public SurveillanceSystem SurveillanceSystem { get; set; }
        public Telescope Telescope { get; set; }
        public Microscope Microscope { get; set; }
        //public Darkroom Darkroom { get; set; }
        public Lens Lens { get; set; }
        //public LensAccessory LensAccessory { get; set; }
        //public Filter Filter { get; set; }
        //public Film Film { get; set; }
        //public BagCase BagCase { get; set; }
        //public BlankMedia BlankMedia { get; set; }
        //public PhotoPaper PhotoPaper { get; set; }
        //public Cleaner Cleaner { get; set; }
        //public Flash Flash { get; set; }
        //public TripodStand TripodStand { get; set; }
        public Projection Projection { get; set; }
        //public PhotoStudio PhotoStudio { get; set; }
        //public LightMeter LightMeter { get; set; }
        //public PowerSupply PowerSupply { get; set; }
        public OtherAccessory OtherAccessory { get; set; }
    }

    public class FilmCamera
    {
        [XmlElement]
        public CameraType CameraType { get; set; }
    }
    public class Camcorder
    {
        [XmlElement]
        public AnalogFormats AnalogFormats { get; set; }
        [XmlElement]
        public DigitalFormats DigitalFormats { get; set; }
    }
    public class DigitalCamera
    {
        [XmlElement]
        public CameraType CameraType { get; set; }
        [XmlElement]
        public FocusType FocusType { get; set; }
    }
    public class Binocular
    {
        [XmlElement]
        public BinocularType BinocularType { get; set; }
    }
    public class SurveillanceSystem
    {
        [XmlElement]
        public SurveillanceSystemType SurveillanceSystemType { get; set; }
    }
    public class Telescope
    {
        [XmlElement]
        public TelescopeType TelescopeType { get; set; }
    }
    public class Microscope
    {
        [XmlElement]
        public MicroscopeType MicroscopeType { get; set; }
    }

    public class Lens
    {
        [XmlElement]
        public CameraType CameraType { get; set; }
    }
    public class Projection
    {
        [XmlElement]
        public ProjectionType ProjectionType { get; set; }
    }

    public class OtherAccessory
    {
        [XmlElement]
        public CameraAccessories CameraAccessories { get; set; }
    }
    #endregion CameraPhoto

    #region cell phones
    public class Wireless
    {
        [XmlElement("ProductType")]
        public WirelessType ProductType { get; set; }
    }
    public class WirelessType
    {
        public WirelessAccessories WirelessAccessories { get; set; }
    }
    public class WirelessAccessories
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }

    #endregion cell phones

    #region FoodAndBeverages
    public class FoodAndBeverages
    {
        [XmlElement("ProductType")]
        public FoodAndBeveragesType ProductType { get; set; }
    }

    public class FoodAndBeveragesType
    {
        public Food Food { get; set; }
        public Beverages Beverages { get; set; }
    }
    public class Beverages
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Flavor { get; set; }
    }
    public class Food
    {

        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Flavor { get; set; }
    }
    #endregion FoodAndBeverages

    #region Health
    public class Health
    {
        [XmlElement("ProductType")]
        public HealthType ProductType { get; set; }
    }
    public class HealthType
    {
        [XmlElement]
        public HealthMisc HealthMisc { get; set; }
        [XmlElement]
        public PersonalCareAppliances PersonalCareAppliances { get; set; }
    }
    public class HealthMisc
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class PersonalCareAppliances
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    #endregion Health

    #region Jewelry
    public class Jewelry
    {
        [XmlElement("ProductType")]
        public JewelryType ProductType { get; set; }
    }
    public class JewelryType
    {
        public Watch Watch { get; set; }
        public FashionNecklaceBraceletAnklet FashionNecklaceBraceletAnklet { get; set; }
        public FashionRing FashionRing { get; set; }
        public FashionEarring FashionEarring { get; set; }
        public FashionOther FashionOther { get; set; }
        public FineNecklaceBraceletAnklet FineNecklaceBraceletAnklet { get; set; }
        public FineRing FineRing { get; set; }
        public FineEarring FineEarring { get; set; }
        public FineOther FineOther { get; set; }
    }
    public class Watch
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class FashionNecklaceBraceletAnklet
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FashionRing
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FashionEarring
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FashionOther
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FineNecklaceBraceletAnklet
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FineRing
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FineEarring
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class FineOther
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }

    #endregion Jewelry

    #region LargeAppliances
    public class LargeAppliances
    {
        [XmlElement("ProductType")]
        public LargeAppliancesType ProductType { get; set; }
    }
    public class LargeAppliancesType
    {
        public AirConditioner AirConditioner { get; set; }
        public ApplianceAccessory ApplianceAccessory { get; set; }
        public CookingOven CookingOven { get; set; }
        public Cooktop Cooktop { get; set; }
        public Dishwasher Dishwasher { get; set; }
        public LaundryAppliance LaundryAppliance { get; set; }
        public MicrowaveOven MicrowaveOven { get; set; }
        public Range Range { get; set; }
        public RefrigerationAppliance RefrigerationAppliance { get; set; }
        public TrashCompactor TrashCompactor { get; set; }
        public VentHood VentHood { get; set; }
    }

    public class AirConditioner
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class ApplianceAccessory
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class CookingOven
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class Cooktop
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class Dishwasher
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class LaundryAppliance
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class MicrowaveOven
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class Range
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class RefrigerationAppliance
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class TrashCompactor
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class VentHood
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    #endregion LargeAppliances

    #region MusicalInstruments
    public class MusicalInstruments
    {
        [XmlElement("ProductType")]
        public MusicalInstrumentsType ProductType { get; set; }
    }
    public class MusicalInstrumentsType
    {
        public BrassAndWoodwindInstruments BrassAndWoodwindInstruments { get; set; }
        public Guitars Guitars { get; set; }
        public InstrumentPartsAndAccessories InstrumentPartsAndAccessories { get; set; }
        public KeyboardInstruments KeyboardInstruments { get; set; }
        public MiscWorldInstruments MiscWorldInstruments { get; set; }
        public PercussionInstruments PercussionInstruments { get; set; }
        public SoundAndRecordingEquipment SoundAndRecordingEquipment { get; set; }
        public StringedInstruments StringedInstruments { get; set; }
    }
    public class BrassAndWoodwindInstruments
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class Guitars
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class InstrumentPartsAndAccessories
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class KeyboardInstruments
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class MiscWorldInstruments
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class PercussionInstruments
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class SoundAndRecordingEquipment
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    public class StringedInstruments
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        public string ModelName { get; set; }
        public string ModelNumber { get; set; }
    }
    #endregion MusicalInstruments

    #region HomeImprovement
    public class HomeImprovement
    {
        [XmlElement("ProductType")]
        public HomeImprovementType ProductType { get; set; }
    }
    public class HomeImprovementType
    {
        public BuildingMaterials BuildingMaterials { get; set; }
        public Hardware Hardware { get; set; }
        public Electrical Electrical { get; set; }
        public PlumbingFixtures PlumbingFixtures { get; set; }
        public Tools Tools { get; set; }
        public OrganizersAndStorage OrganizersAndStorage { get; set; }
        public MajorHomeAppliances MajorHomeAppliances { get; set; }
        public SecurityElectronics SecurityElectronics { get; set; }
    }
    public class BuildingMaterials
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        [XmlElement]
        public string Material { get; set; }
    }
    public class Hardware
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class Electrical
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class PlumbingFixtures
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class Tools
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
        [XmlElement]
        public string Material { get; set; }
    }
    public class OrganizersAndStorage
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class MajorHomeAppliances
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    public class SecurityElectronics
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string BandColor { get; set; }
    }
    #endregion HomeImprovement

    #region ClothingAccessories
    public class ClothingAccessories
    {
        //public ProductType ProductType { get; set; }
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string PatternStyle { get; set; }
        public string RiseStyle { get; set; }
        public string SkiStyle { get; set; }
        public string SockStyle { get; set; }
        public string SnowboardStyle { get; set; }
        public string TopStyle { get; set; }
        public string BeltStyle { get; set; }
        public string BottomStyle { get; set; }
        public ClassificationData ClassificationData { get; set; }
    }
    public class ClassificationData
    {
        public string Department { get; set; }
    }
    #endregion ClothingAccessories

    #region OfficeProducts
    public class Office
    {
        [XmlElement("ProductType")]
        public OfficeType ProductType { get; set; }
    }
    public class OfficeType
    {
        public Calculator Calculator { get; set; }
        public InkToner InkToner { get; set; }
        public OfficePhone OfficePhone { get; set; }
        public OfficePrinter OfficePrinter { get; set; }
        public OfficeScanner OfficeScanner { get; set; }
        public WritingInstruments WritingInstruments { get; set; }
        public PaperProducts PaperProducts { get; set; }
        public OfficeProducts OfficeProducts { get; set; }
    }
    public class Calculator
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class InkToner
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class OfficePhone
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class OfficePrinter
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class OfficeScanner
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class WritingInstruments
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class PaperProducts
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class OfficeProducts
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    #endregion OfficeProducts

    #region Computer
    public class Computers
    {
        [XmlElement("ProductType")]
        public ComputersType ProductType { get; set; }
    }
    public class ComputersType
    {
        public CarryingCaseOrBag CarryingCaseOrBag { get; set; }
        public ComputerAddOn ComputerAddOn { get; set; }
        public ComputerComponent ComputerComponent { get; set; }
        public ComputerDriveOrStorage ComputerDriveOrStorage { get; set; }
        public ComputerInputDevice ComputerInputDevice { get; set; }
        public ComputerProcessor ComputerProcessor { get; set; }
        public ComputerSpeaker ComputerSpeaker { get; set; }
        public Computer Computer { get; set; }
        public Keyboards Keyboards { get; set; }
        public Monitor Monitor { get; set; }
        public Motherboard Motherboard { get; set; }
        public PersonalComputer PersonalComputer { get; set; }
        public Printer Printer { get; set; }
        public RamMemory RamMemory { get; set; }
        public Scanner Scanner { get; set; }
    }
    public class CarryingCaseOrBag
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ComputerAddOn
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ComputerComponent
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ComputerDriveOrStorage
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ComputerInputDevice
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ComputerProcessor
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class ComputerSpeaker
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Computer
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Keyboards
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Monitor
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Motherboard
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class RamMemory
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class PersonalComputer
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Printer
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }
    public class Scanner
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
    }

    #endregion Computer

    #region Sports Memorabilia
    public class SportsMemorabilia
    {
        public ProductType ProductType { get; set; }
        [XmlElement]
        public string AuthenticatedBy { get; set; }
        [XmlElement]
        public string ConditionProvidedBy { get; set; }
        [XmlElement]
        public string ConditionRating { get; set; }
        [XmlElement]
        public VariationData VariationData { get; set; }
        [XmlElement]
        public string Size { get; set; }
        [XmlElement]
        public string Color { get; set; }
        public string PatternStyle { get; set; }
        public string RiseStyle { get; set; }
        public string SkiStyle { get; set; }
        public string SockStyle { get; set; }
        public string SnowboardStyle { get; set; }
        public string TopStyle { get; set; }
        public string BeltStyle { get; set; }
        public string BottomStyle { get; set; }
    }
    #endregion Sports Memorabilia

    #region videos
    public class Video
    {
        [XmlElement("ProductType")]
        public VideoType ProductType { get; set; }
    }
    public class VideoType
    {
        public VideoDVD VideoDVD { get; set; }
        public VideoVHS VideoVHS { get; set; }
    }
    public class VideoDVD
    { }
    public class VideoVHS
    { }
    #endregion videos

    #region shipping
    public class Override
    {
        public string SKU { get; set; }
        [XmlElement]
        public ShippingOverride ShippingOverride { get; set; }
    }
    public class ShippingOverride
    {
        [XmlElement]
        public string ShipOption { get; set; }
        [XmlElement]
        public string FulfillmentServiceLevel { get; set; }
        [XmlElement]
        public string Locale { get; set; }
        [XmlElement]
        public string Type { get; set; }
        [XmlElement]
        public ShipAmount ShipAmount { get; set; }
    }
    public class ShipAmount
    {
        [XmlAttribute("currency")]
        public currency currency { get; set; }
        [XmlText]
        public Decimal Value { get; set; }
    }
    #endregion shipping

}
