﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace AmazonLister
{


    [XmlRoot]
    public class ProductImage
    {
        [XmlElement]
        public string SKU { get; set; }
        [XmlElement]
        public ImageType? ImageType { get; set; }
        [XmlElement]
        public string ImageLocation { get; set; }
    }
}
