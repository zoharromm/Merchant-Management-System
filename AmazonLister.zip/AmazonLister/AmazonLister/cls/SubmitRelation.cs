﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace AmazonLister
{
    [XmlRoot]
    public class Relationship
    {
        [XmlElement]
        public string ParentSKU { get; set; }
        [XmlElement]
        public Relation Relation { get; set; }

    }
    [XmlRoot]
    public class Relation
    {
        [XmlElement]
        public string SKU { get; set; }
        [XmlElement]
        public string Type { get; set; }
    }
}
