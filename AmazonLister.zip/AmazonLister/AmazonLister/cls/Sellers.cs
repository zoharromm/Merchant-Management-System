﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmazonLister.cls
{
   public class Sellers
    {
        public int SellerID { get; set; }
        public string ApplicationName { get; set; }
        public string ApplicationVersion { get; set; }
        public string DocumentVersion { get; set; }
        public string ServiceURL { get; set; }
        public string AccessKeyId { get; set; }
        public string Merchant { get; set; }
        public string SecretKey { get; set; }
        public string MerchantIdentifier { get; set; }
        public string MarketplaceIdList { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Currency { get; set; }
    }
}
