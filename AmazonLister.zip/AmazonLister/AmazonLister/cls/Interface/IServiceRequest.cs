﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MarketplaceWebService.Model;

namespace AmazonLister
{
   public  interface IServiceRequest
    {

       void InvokeSubmitFeed(MarketplaceWebService.MarketplaceWebService service, SubmitFeedRequest request);
        
    }
}
