﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using MarketplaceWebService.Model;

namespace AmazonLister
{
    public interface IAmazonWebService
    {

        //This method is responsible to download all data from client website 
        FeedSubmissionInfo UploadProductSKU(List<Message> Messages);
        // This method is reponsible to Update Prices
        FeedSubmissionInfo UploadPrice(List<Message> Messages);
        // This method is reponsible to update Inventory
        FeedSubmissionInfo UploadInventory(List<Message> Messages);
        // This method is responsible to Upload Images
        FeedSubmissionInfo UploadImages(List<Message> Messages);
        // This method is responsible to Upload Replation
        void UploadRelation();
        // This method is responsible to download Orders
        void DownloadOrders();
        // Get Serilize Object To XML
        List<Message> CheckFeedStatus(string FeedID, string Path);


    }
}
