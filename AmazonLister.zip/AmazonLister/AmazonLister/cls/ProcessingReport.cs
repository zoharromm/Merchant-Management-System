﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace AmazonLister
{

    [XmlRoot]
    public class ProcessingReport
    {
        [XmlElement]
        public string DocumentTransactionID { get; set; }
        [XmlElement]
        public string StatusCode { get; set; }
        [XmlElement]
        public ProcessingSummary ProcessingSummary { get; set; }
        [XmlElement]
        public List<Result> Result { get; set; }
    }
    public class ProcessingSummary
    {
        [XmlElement]
        public Int32 MessagesProcessed { get; set; }
        [XmlElement]
        public Int32 MessagesSuccessful { get; set; }
        [XmlElement]
        public Int32 MessagesWithError { get; set; }
        [XmlElement]
        public Int32 MessagesWithWarning { get; set; }
      
    }
    public class Result
    {
        [XmlElement]
        public Int32 MessageID { get; set; }
        [XmlElement]
        public string ResultCode { get; set; }
        [XmlElement]
        public string ResultMessageCode { get; set; }
        [XmlElement]
        public string ResultDescription { get; set; }
        public AdditionalInfo AdditionalInfo { get; set; }
    }
    public class AdditionalInfo
    {
        [XmlElement]
        public string SKU { get; set; } 
    }

}
