﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Xml.Schema;

namespace AmazonLister
{

    
    [XmlRoot]
    public class AmazonEnvelope
    {
        [XmlAttribute("noNamespaceSchemaLocation", Namespace = XmlSchema.InstanceNamespace)]
        public string xsinoNamespaceSchemaLocation = "amzn-envelope.xsd";
        [XmlElement]
        public Header Header { get; set; }
        [XmlElement]
        public MessageType MessageType { get; set; }
        [XmlElement]
        public bool PurgeAndReplace { get; set; }
        [XmlElement]
        public List<Message> Message { get; set; }
    }
    [XmlRoot]
    public class Header
    {
        [XmlElement]
        public string DocumentVersion;
        [XmlElement]
        public string MerchantIdentifier;      
    }
    [XmlRoot]
    public class Message
    {
        [XmlElement]
        public Int32 MessageID { get; set; }
        [XmlElement]
        public OperationType OperationType { get; set; }
        [XmlElement]
        public Product Product { get; set; }
        [XmlElement]
        public Price Price { get; set; }
        [XmlElement]
        public Inventory Inventory { get; set; }
        [XmlElement]
        public Relationship Relationship { get; set; }
        [XmlElement]
        public ProductImage ProductImage { get; set; }
        [XmlElement]
        public ProcessingReport ProcessingReport { get; set; }
        [XmlElement]
        public Override Override { get; set; }
        
        
    }
}
