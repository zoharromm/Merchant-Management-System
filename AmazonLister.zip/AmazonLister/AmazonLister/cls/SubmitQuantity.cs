﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace AmazonLister
{
    [XmlRoot]
    public  class Inventory
    {
        [XmlElement]
        public string SKU { get; set; }
        [XmlElement]
        public Int32 Quantity { get; set; }
        [XmlElement]
        public Int32 FulfillmentLatency { get; set; }
       
    }
}
