﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace AmazonLister
{

    [XmlRoot]
    public class Keywords
    {
        [XmlElement]
        public List<string> BulletPoint { get; set; }
    }
    [XmlRoot]
    public class Images
    {

        [XmlElement]
        public List<Image> Image { get; set; }

    }

    [XmlRoot]
    public class Image
    {
        [XmlElement]
        public string ImageType { get; set; }

        [XmlElement]
        public string ImageURL { get; set; }
    }

    //Class Identifire 201
    public class CreateMessage
    {
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        BusinessLayer.DB _db = new BusinessLayer.DB();
        DataSet ds = new DataSet();
        public CreateMessage(DataSet lds)
        {
            ds = lds;
        }


        private List<string> GetBulletPoint(string Doc)
        {
            Keywords myKeywords = new Keywords();
            XmlSerializer Serializer = new XmlSerializer(typeof(Keywords));
            using (TextReader reader = new StringReader(Doc))
            {
                myKeywords = (Keywords)(Serializer.Deserialize(reader));
            }
            return myKeywords.BulletPoint;
        }
        private Images GetImages(string Doc)
        {
            Images Images = new Images();
            XmlSerializer Serializer = new XmlSerializer(typeof(Images));
            using (TextReader reader = new StringReader(Doc))
            {
                Images = (Images)(Serializer.Deserialize(reader));
            }
            return Images;
        }
        public string isAlphaNumeric(string strToCheck, int type = 0)
        {
            string Content = Regex.Replace(strToCheck, @"[^A-Za-z0-9 _\.\,\-\(\)]", "");
            if (type == 0)
            {
                if (Content.Length > 500)
                    Content = Content.Substring(0, 497);
            }
            else
            {
                if (Content.Length > 2000)
                    Content = Content.Substring(0, 1997);
            }
            return Content;
        }
        public List<Message> GetMessage(ListMessageType MessageType, OperationType _Type, string StoreName, bool _IsSized)
        {
            List<Message> Message = new List<Message>();
            switch (Convert.ToInt32(MessageType))
            {
                case 0:
                    Message = GetSubmitSKU(_Type, StoreName, _IsSized);
                    break;
                case 1:
                    Message = GetSubmitPrice(_Type, StoreName, _IsSized);
                    break;
                case 2:
                    Message = GetSubmitQuantity(_Type, StoreName, _IsSized);
                    break;
                case 3:
                    Message = GetSubmitImages(_Type, StoreName, _IsSized);
                    break;
                case 4:
                    Message = GetSubmitShipping(_Type, StoreName, _IsSized);
                    break;
                default:
                    break;
            }

            return Message;
        }
        private List<Message> GetSubmitSKU(OperationType _Type, string StoreName, bool _IsSized)
        {
            int MaxOrderQuantity = 1;
            int Gtin = 0;
            try
            {
                try
                {
                    SqlDataReader dr = _db.GetDR("select isnull(MaxOrderQuantity,1) as MaxOrderQuantity,isnull(ConditionNote,'') as ConditionNote from store where storename='" + StoreName + "'");
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            MaxOrderQuantity = Convert.ToInt32(dr["MaxOrderQuantity"]);
                        }
                    }
                }
                catch
                { }
                string TemplateName = "";
                List<Message> Messages = new List<Message>();
                Message Message;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    try
                    {


                        Message = new Message();
                        Message.MessageID = Messages.Count + 1;
                        Message.OperationType = _Type;
                        Product Prd = new Product();
                        Prd.SKU = dr["SKU"].ToString();

                        #region UPC
                        try
                        {
                            Gtin = Convert.ToInt32(dr["Gtin"].ToString());
                        }
                        catch
                        { Gtin = 0; }
                        StandardProductID _Strd = new StandardProductID();
                        if (Gtin == 0)
                        {
                            if (!dr["UPC"].ToString().All(c => "0123456789".Contains(c)))
                                _Strd.Type = Type.ASIN;
                            else
                                _Strd.Type = Type.UPC;
                        }
                        else
                            _Strd.Type = Type.GTIN;
                        _Strd.Value = dr["UPC"].ToString();
                        Prd.StandardProductID = _Strd;
                        #endregion UPC

                        if (_Type != OperationType.Delete)
                        {
                            TemplateName = dr["AmazontemplateName"].ToString();
                            #region Condition
                            Condition _Condition = new Condition();
                            _Condition.ConditionType = string.IsNullOrEmpty(dr["AmazonCondition"].ToString()) ? "New" : dr["AmazonCondition"].ToString();
                            _Condition.ConditionNote = dr["ConditionNote"].ToString();
                            Prd.Condition = _Condition;
                            #endregion Condition

                            //   Prd.GtinExemptionReason = GtinExemptionReason.part;

                            #region DescriptionData
                            List<string> _Bullepoint = new List<string>();
                            DescriptionData DescriptionData = new DescriptionData();
                            DescriptionData.Title = dr["ProductName"].ToString();
                            if (dr["Brand"].ToString().Trim().Length != 0)
                                DescriptionData.Brand = dr["Brand"].ToString();
                            if (dr["Description"].ToString().Trim().Length != 0)
                                DescriptionData.Description = isAlphaNumeric(dr["Description"].ToString(), 1);
                            if (dr["BulletPoint1"].ToString().Trim().Length != 0)
                                _Bullepoint.Add(isAlphaNumeric(dr["BulletPoint1"].ToString()));
                            if (dr["BulletPoint2"].ToString().Trim().Length != 0)
                                _Bullepoint.Add(isAlphaNumeric(dr["BulletPoint2"].ToString()));
                            if (dr["BulletPoint3"].ToString().Trim().Length != 0)
                                _Bullepoint.Add(isAlphaNumeric(dr["BulletPoint3"].ToString()));
                            if (dr["BulletPoint4"].ToString().Trim().Length != 0)
                                _Bullepoint.Add(isAlphaNumeric(dr["BulletPoint4"].ToString()));
                            if (dr["BulletPoint5"].ToString().Trim().Length != 0)
                                _Bullepoint.Add(isAlphaNumeric(dr["BulletPoint5"].ToString()));
                            if (Convert.ToDecimal(dr["Weight"]) > 0)
                            {
                                ShippingWeight _Weight = new ShippingWeight();
                                _Weight.Value = Convert.ToDecimal(dr["Weight"]);
                                _Weight.unitOfMeasure = "LB";
                                DescriptionData.ShippingWeight = _Weight;
                            }
                            if (dr["Manufacturer"].ToString().Trim().Length != 0)
                                DescriptionData.Manufacturer = dr["Manufacturer"].ToString();

                            DescriptionData.MaxOrderQuantity = MaxOrderQuantity;
                            DescriptionData.BulletPoint = _Bullepoint;
                            if (dr["AmazonNodeID"].ToString().Trim().Length > 0)
                            {
                                if (dr["AmazonNodeID"].ToString().Trim() != "0")
                                    DescriptionData.RecommendedBrowseNode = dr["AmazonNodeID"].ToString().Trim();
                            }
                            DescriptionData.IsGiftMessageAvailable = false;
                            DescriptionData.IsGiftWrapAvailable = false;
                            try
                            {
                                if (string.IsNullOrEmpty(dr["ManPartNO"].ToString()))
                                    DescriptionData.MfrPartNumber = dr["SKU"].ToString();
                                else
                                    DescriptionData.MfrPartNumber = dr["ManPartNO"].ToString();
                            }
                            catch
                            { DescriptionData.MfrPartNumber = dr["SKU"].ToString(); }
                            #region MSRP
                            MSRP _msrp = new MSRP();
                            _msrp.Value = Convert.ToDecimal(dr["Price"]) + 10;
                            _msrp.currency = "CAD";
                            #endregion MSRP

                            #region ItemType
                            string Department = "";
                            string ItemType = "";
                            string Category = "";
                            if (dr["AmazonCategoryName"].ToString().Trim().Length != 0)
                            {
                                //department_name:boys AND item_type_keyword:athletic-water-shoes
                                Category = dr["AmazonCategoryName"].ToString();
                                if (Category.ToLower().Contains("department_name"))
                                {
                                    string[] CategoryNames = Category.Split(new string[] { " AND " }, StringSplitOptions.None);
                                    foreach (string Name in CategoryNames)
                                    {
                                        if (Name.Contains("item_type_keyword"))
                                        {
                                            ItemType = Name.Replace("item_type_keyword:", "").Trim();
                                        }
                                        else
                                        {
                                            List<string> TargetAudience = new List<string>();
                                            TargetAudience.Add(Name.Replace("department_name:", "").Trim());
                                            // DescriptionData.TargetAudience =TargetAudience;
                                        }
                                    }
                                }
                                else
                                    ItemType = Category.Replace("item_type_keyword:", "").Trim();
                            }
                            if (ItemType != "")
                            {
                                // string[] Item_Type = ItemType.Split(new string[] { " AND " }, StringSplitOptions.None);

                                //   DescriptionData.ItemType = ItemType.Trim();
                            }


                            #region ProductData
                            ProductData ProductData = new ProductData();

                            #region sports

                            if (TemplateName.ToLower() == "sports & outdoors")
                            {
                                Sports _sport = new Sports();
                                _sport.ProductType = ProductType.SportingGoods;
                                if (dr["Color"].ToString().Trim() != "")
                                    _sport.ColorMap = dr["Color"].ToString().Trim();
                                if (dr["Size"].ToString().Trim() != "")
                                    _sport.SizeMap = dr["Size"].ToString().Trim();
                                if (!string.IsNullOrEmpty(_sport.SizeMap) || !string.IsNullOrEmpty(_sport.ColorMap))
                                {
                                    VariationData VariationData = new VariationData();
                                    if (!string.IsNullOrEmpty(_sport.SizeMap) && !string.IsNullOrEmpty(_sport.ColorMap))
                                    {
                                        VariationData.VariationTheme = VariationTheme.ColorSize;
                                    }
                                    else if (!string.IsNullOrEmpty(_sport.SizeMap))
                                    {
                                        VariationData.VariationTheme = VariationTheme.Size;
                                    }
                                    else
                                    {
                                        VariationData.VariationTheme = VariationTheme.Color;
                                    }
                                    VariationData.Parentage = Parentage.child;
                                    //  _sport.VariationData = VariationData;
                                }

                                ProductData.Sports = _sport;
                            }
                            #endregion sports

                            #region toys
                            else if (TemplateName.ToLower() == "toys & games")
                            {
                                DescriptionData.TargetAudience = "unisex-children";
                                ToysBaby _Toys = new ToysBaby();
                                _Toys.ProductType = ProductType.ToysAndGames;
                                #region age
                                AgeRecommendation AgeRecommendation = new AmazonLister.AgeRecommendation();
                                MaximumManufacturerAgeRecommended MaximumManufacturerAgeRecommended = new AmazonLister.MaximumManufacturerAgeRecommended();
                                MinimumManufacturerAgeRecommended MinimumManufacturerAgeRecommended = new AmazonLister.MinimumManufacturerAgeRecommended();

                                if (dr["AgeUnitOfMeasure"].ToString().Trim().Length != 0)
                                {
                                    string ageMeasure = dr["AgeUnitOfMeasure"].ToString().ToLower();
                                    if (ageMeasure == "year")
                                        ageMeasure = "years";
                                    else if (ageMeasure == "month")
                                        ageMeasure = "months";
                                    else
                                        ageMeasure = "years";
                                    MaximumManufacturerAgeRecommended.unitOfMeasure = ageMeasure;
                                    MinimumManufacturerAgeRecommended.unitOfMeasure = ageMeasure;

                                }
                                else
                                {
                                    MaximumManufacturerAgeRecommended.unitOfMeasure = "years";
                                    MinimumManufacturerAgeRecommended.unitOfMeasure = "years";
                                }
                                if (dr["MinimumAgeRecommend"].ToString().Trim().Length != 0)
                                {
                                    int Age = 0;
                                    int.TryParse(dr["MinimumAgeRecommend"].ToString(), out Age);
                                    Age = Age == 0 ? 1 : Age;
                                    MinimumManufacturerAgeRecommended.Value = Age.ToString();
                                    MaximumManufacturerAgeRecommended.Value = "15";
                                }
                                else
                                {
                                    MinimumManufacturerAgeRecommended.Value = "1";
                                    MaximumManufacturerAgeRecommended.Value = "15";
                                }
                                AgeRecommendation.MaximumManufacturerAgeRecommended1 = MaximumManufacturerAgeRecommended;
                                AgeRecommendation.MinimumManufacturerAgeRecommended1 = MinimumManufacturerAgeRecommended;
                                _Toys.AgeRecommendation = AgeRecommendation;


                                #endregion age
                                if (_IsSized)
                                {
                                    //For Size
                                }
                                ProductData.ToysBaby = _Toys;
                            }
                            #endregion toys

                            #region video games
                            else if (TemplateName.ToLower() == "software & video games")
                            {
                                SoftwareVideoGames sofVideoGames = new SoftwareVideoGames();
                                SoftwareVideoGamesType videotype = new SoftwareVideoGamesType();
                                //VideoGames videoGames = new VideoGames();
                                //string ESRBRating = "10+";
                                //videoGames.ESRBRating = ESRBRating;
                                //List<string> ConsoleVideoGamesGenre = new List<string>();
                                //ConsoleVideoGamesGenre.Add("Action games");
                                //videoGames.ConsoleVideoGamesGenre = ConsoleVideoGamesGenre;
                                //videoGames.HardwarePlatform = "PlayStation 4";
                                //videotype.VideoGames = videoGames;
                                //sofVideoGames.ProductType = videotype;
                                VideoGamesAccessories videoGameAccessories = new VideoGamesAccessories();
                                //Binding necessary in order to map product with this category
                                videoGameAccessories.HardwarePlatform = "PlayStation 4";
                                videotype.VideoGamesAccessories = videoGameAccessories;
                                sofVideoGames.ProductType = videotype;
                                if (_IsSized)
                                {
                                    //For Size
                                }
                                ProductData.SoftwareVideoGames = sofVideoGames;
                            }
                            #endregion video games

                            #region baby
                            else if (TemplateName.ToLower() == "baby")
                            {
                                Baby baby = new Baby();
                                BabyType type = new BabyType();
                                BabyProducts babyProduct = new BabyProducts();
                                MinimumManufacturerAgeRecommended MinimumManufacturerAgeRecommended = new MinimumManufacturerAgeRecommended();
                                MinimumManufacturerAgeRecommended.unitOfMeasure = "years";
                                MinimumManufacturerAgeRecommended.Value = "1";
                                #region sizecolor
                                #endregion sizecolor
                                babyProduct.MinimumManufacturerAgeRecommended = MinimumManufacturerAgeRecommended;
                                type.BabyProducts = babyProduct;
                                baby.ProductType = type;
                                ProductData.Baby = baby;

                            }
                            #endregion baby

                            #region luggage

                            else if (TemplateName.ToLower() == "luggage & bags")
                            {
                                Luggage luggage = new Luggage();
                                luggage.ProductType = ProductType.Luggage;
                                if (_IsSized)
                                {
                                    //For Size
                                }
                                ProductData.Luggage = luggage;

                            }

                            #endregion luggage

                            #region Home Kitchen

                            else if (TemplateName.ToLower() == "home & garden")
                            {
                                ///
                                if (_IsSized)
                                {

                                }

                                Home home = new Home();
                                HomeType type = new HomeType();
                                if (Category.ToLower().Contains("art"))
                                {
                                    Art ART = new Art();
                                    type.Art = ART;

                                }
                                else if (Category.ToLower().Contains("bath"))
                                {
                                    BedAndBath bedAndBath = new BedAndBath();
                                    type.BedAndBath = bedAndBath;

                                }
                                else if (Category.ToLower().Contains("kitchen"))
                                {
                                    Kitchen kitchen = new Kitchen();
                                    type.Kitchen = kitchen;
                                }
                                else if (Category.ToLower().Contains("furniture"))
                                {
                                    FurnitureAndDecor furniture = new FurnitureAndDecor();
                                    type.FurnitureAndDecor = furniture;
                                }
                                else if (Category.ToLower().Contains("flowers"))
                                {
                                    SeedsAndPlants seedAndPlants = new SeedsAndPlants();
                                    type.SeedsAndPlants = seedAndPlants;
                                }
                                else
                                {
                                    HomeClass homeClass = new HomeClass();
                                    type.Home = homeClass;
                                }
                                home.ProductType = type;
                                ProductData.Home = home;
                            }

                            #endregion Home Kitchen

                            #region PetSupplies

                            else if (TemplateName.ToLower() == "pet supplies")
                            {
                                PetSupplies PetSupplies = new PetSupplies();
                                clsProductType type = new clsProductType();
                                PetSuppliesMisc petSuppliesMisc = new PetSuppliesMisc();
                                if (_IsSized)
                                {

                                }
                                type.PetSuppliesMisc = petSuppliesMisc;
                                PetSupplies.ProductType = type;
                                ProductData.PetSupplies = PetSupplies;

                            }
                            #endregion PetSupplies

                            #region electronics
                            else if (TemplateName.ToLower() == "consumer electronics")
                            {
                                CE ce = new CE();
                                CEType type = new CEType();
                                if (Category.ToLower().Contains("bags & cases"))
                                {
                                    CameraBagsAndCases bagsCases = new CameraBagsAndCases();
                                    type.CameraBagsAndCases = bagsCases;
                                }
                                else if (Category.ToLower().Contains("camera"))
                                {
                                    CEDigitalCamera camera = new CEDigitalCamera();
                                    type.CEDigitalCamera = camera;

                                }
                                else if (Category.ToLower().Contains("battery"))
                                {
                                    CEBattery ceBattery = new CEBattery();
                                    type.CEBattery = ceBattery;
                                }
                                else if (Category.ToLower().Contains("lenses"))
                                {
                                    CameraLenses cameraLenses = new CameraLenses();
                                    type.CameraLenses = cameraLenses;
                                }
                                else if (Category.ToLower().Contains("headphone"))
                                {
                                    Headphones headPhones = new Headphones();
                                    type.Headphones = headPhones;
                                }
                                else
                                {
                                    ConsumerElectronics ConsumerElectronics = new ConsumerElectronics();
                                    type.ConsumerElectronics = ConsumerElectronics;
                                }

                                ce.ProductType = type;
                                ProductData.CE = ce;

                            }

                            #endregion electronics

                            #region Beauty
                            else if (TemplateName.ToLower() == "beauty")
                            {
                                Beauty Beauty = new Beauty();
                                BeautyType type = new BeautyType();
                                BeautyMisc BeautyMisc = new BeautyMisc();
                                if (_IsSized)
                                {
                                    //For Size
                                }
                                type.BeautyMisc = BeautyMisc;
                                Beauty.ProductType = type;
                                ProductData.Beauty = Beauty;

                            }
                            #endregion Beauty

                            #region Automotive
                            else if (TemplateName.ToLower() == "automotive")
                            {
                                AutoAccessory AutoAccessory = new AutoAccessory();
                                AutoAccessoryType type = new AutoAccessoryType();
                                if (Category.ToLower().Contains("motorcycle") && Category.ToLower().Contains("accessories"))
                                {
                                    Motorcycleaccessory Motorcycleaccessory = new Motorcycleaccessory();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Motorcycleaccessory = Motorcycleaccessory;
                                }
                                else if (Category.ToLower().Contains("motorcycle"))
                                {
                                    Motorcyclepart Motorcyclepart = new Motorcyclepart();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Motorcyclepart = Motorcyclepart;
                                }
                                else if (Category.ToLower().Contains("parts"))
                                {
                                    AutoPart AutoPart = new AutoPart();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.AutoPart = AutoPart;
                                }
                                else if (Category.ToLower().Contains("powersports"))
                                {
                                    PowersportsPart PowersportsPart = new PowersportsPart();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.PowersportsPart = PowersportsPart;
                                }
                                else if (Category.ToLower().Contains("tires & wheels"))
                                {
                                    TireAndWheel TireAndWheel = new TireAndWheel();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.TireAndWheel = TireAndWheel;
                                }
                                else if (Category.ToLower().Contains("rims"))
                                {
                                    Rims Rims = new Rims();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Rims = Rims;
                                }
                                else if (Category.ToLower().Contains("tires"))
                                {
                                    Tire Tire = new Tire();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Tire = Tire;
                                }
                                else if (Category.ToLower().Contains("vehicle"))
                                {
                                    Vehicle Vehicle = new Vehicle();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Vehicle = Vehicle;
                                }

                                else if (Category.ToLower().Contains("glove"))
                                {
                                    Ridinggloves Ridinggloves = new Ridinggloves();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Ridinggloves = Ridinggloves;
                                }
                                else if (Category.ToLower().Contains("boots"))
                                {
                                    Ridingboots Ridingboots = new Ridingboots();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Ridingboots = Ridingboots;
                                }
                                else if (Category.ToLower().Contains("battery"))
                                {
                                    Autobattery Autobattery = new Autobattery();

                                    #region sizecolor
                                    #endregion sizecolor
                                    type.Autobattery = Autobattery;
                                }
                                else if (Category.ToLower().Contains("chemical"))
                                {
                                    Autochemical Autochemical = new Autochemical();
                                    type.Autochemical = Autochemical;
                                }
                                else
                                {
                                    AutoAccessoryMisc AutoAccessoryMisc = new AutoAccessoryMisc();
                                    #region sizecolor
                                    #endregion sizecolor
                                    type.AutoAccessoryMisc = AutoAccessoryMisc;
                                }
                                AutoAccessory.ProductType = type;
                                ProductData.AutoAccessory = AutoAccessory;
                            }
                            #endregion Automotive

                            #region Camera&Photo
                            else if (TemplateName.ToLower() == "camera & photo")
                            {
                                CameraPhoto CameraPhoto = new CameraPhoto();
                                CameraPhotoType CameraPhotoType = new CameraPhotoType();
                                if (Category.ToLower().Contains("film"))
                                {
                                    FilmCamera FilmCamera = new FilmCamera();
                                    FilmCamera.CameraType = CameraType.other;
                                    CameraPhotoType.FilmCamera = FilmCamera;
                                }
                                else if (Category.ToLower().Contains("camcorder"))
                                {
                                    Camcorder Camcorder = new Camcorder();
                                    Camcorder.AnalogFormats = AnalogFormats.other;
                                    Camcorder.DigitalFormats = DigitalFormats.other;
                                    CameraPhotoType.Camcorder = Camcorder;
                                }
                                else if (Category.ToLower().Contains("digital camera"))
                                {
                                    DigitalCamera DigitalCamera = new DigitalCamera();
                                    DigitalCamera.CameraType = CameraType.other;
                                    DigitalCamera.FocusType = FocusType.manual;
                                    CameraPhotoType.DigitalCamera = DigitalCamera;
                                }
                                else if (Category.ToLower().Contains("binocular"))
                                {
                                    Binocular Binocular = new Binocular();
                                    Binocular.BinocularType = BinocularType.binoculars;
                                    CameraPhotoType.Binocular = Binocular;
                                }
                                else if (Category.ToLower().Contains("telescope accessories"))
                                {
                                    Telescope Telescope = new Telescope();
                                    Telescope.TelescopeType = TelescopeType.general;
                                    CameraPhotoType.Telescope = Telescope;
                                }
                                else if (Category.ToLower().Contains("microscope accessories"))
                                {
                                    Microscope Microscope = new Microscope();
                                    Microscope.MicroscopeType = MicroscopeType.other;
                                    CameraPhotoType.Microscope = Microscope;
                                }
                                else if (Category.ToLower().Contains("lens"))
                                {
                                    Lens Lens = new Lens();
                                    Lens.CameraType = CameraType.other;
                                    CameraPhotoType.Lens = Lens;
                                }
                                else if (Category.ToLower().Contains("surveillance"))
                                {
                                    SurveillanceSystem SurveillanceSystem = new SurveillanceSystem();
                                    SurveillanceSystem.SurveillanceSystemType = SurveillanceSystemType.cameras;
                                    CameraPhotoType.SurveillanceSystem = SurveillanceSystem;
                                }
                                else if (Category.ToLower().Contains("projection"))
                                {
                                    Projection Projection = new Projection();
                                    Projection.ProjectionType = ProjectionType.viewers;
                                    CameraPhotoType.Projection = Projection;
                                }
                                else
                                {
                                    OtherAccessory OtherAccessory = new OtherAccessory();
                                    OtherAccessory.CameraAccessories = CameraAccessories.straps;
                                    CameraPhotoType.OtherAccessory = OtherAccessory;
                                }
                                CameraPhoto.ProductType = CameraPhotoType;
                                ProductData.CameraPhoto = CameraPhoto;

                            }

                            #endregion Camera&Photo

                            #region cell phones
                            else if (TemplateName.ToLower() == "cell phones")
                            {
                                Wireless Wireless = new Wireless();
                                WirelessType type = new WirelessType();
                                WirelessAccessories WirelessAccessories = new AmazonLister.WirelessAccessories();
                                #region variation
                                #endregion variation
                                type.WirelessAccessories = WirelessAccessories;
                                Wireless.ProductType = type;
                                ProductData.Wireless = Wireless;
                            }
                            #endregion cell phones

                            #region Grocery & Gourmet Food
                            else if (TemplateName.ToLower() == "grocery & gourmet food")
                            {
                                Prd.ItemPackageQuantity = "1";
                                FoodAndBeverages FoodAndBeverages = new FoodAndBeverages();
                                FoodAndBeveragesType type = new FoodAndBeveragesType();
                                if (Category.ToLower().Contains("beverages"))
                                {
                                    Beverages Beverages = new Beverages();
                                    #region variation
                                    #endregion variation
                                    type.Beverages = Beverages;
                                }
                                else
                                {
                                    Food Food = new Food();
                                    #region variation
                                    #endregion variation
                                    type.Food = Food;
                                }
                                FoodAndBeverages.ProductType = type;
                                ProductData.FoodAndBeverages = FoodAndBeverages;
                            }
                            #endregion Grocery & Gourmet Food

                            #region Health & Personal Care
                            else if (TemplateName.ToLower() == "health & personal care")
                            {
                                Health health = new Health();
                                HealthType type = new HealthType();
                                if (Category.ToLower().Contains("/personal care/"))
                                {
                                    PersonalCareAppliances PersonalCareAppliances = new PersonalCareAppliances();
                                    #region variation
                                    #endregion variation
                                    type.PersonalCareAppliances = PersonalCareAppliances;
                                }
                                else
                                {
                                    HealthMisc HealthMisc = new HealthMisc();
                                    #region variation
                                    #endregion variation
                                    type.HealthMisc = HealthMisc;
                                }
                                health.ProductType = type;
                                ProductData.Health = health;

                            }
                            #endregion Health & Personal Care

                            #region Jewelry
                            else if (TemplateName.ToLower() == "jewelry")
                            {
                                Jewelry Jewelry = new Jewelry();
                                JewelryType type = new JewelryType();
                                if ((Category.ToLower().Contains("necklace") || Category.ToLower().Contains("bracelet") || Category.ToLower().Contains("anklet")) && Category.ToLower().Contains("/fashion"))
                                {
                                    FashionNecklaceBraceletAnklet FashionNecklaceBraceletAnklet = new FashionNecklaceBraceletAnklet();
                                    #region variation
                                    #endregion variation
                                    type.FashionNecklaceBraceletAnklet = FashionNecklaceBraceletAnklet;
                                }
                                else if (Category.ToLower().Contains("/rings") && Category.ToLower().Contains("/fashion"))
                                {
                                    FashionRing FashionRing = new FashionRing();
                                    #region variation
                                    #endregion variation
                                    type.FashionRing = FashionRing;
                                }
                                else if (Category.ToLower().Contains("/earrings") && Category.ToLower().Contains("/fashion"))
                                {
                                    FashionEarring FashionEarring = new FashionEarring();
                                    #region variation
                                    #endregion variation
                                    type.FashionEarring = FashionEarring;
                                }
                                else if (Category.ToLower().Contains("/fashion"))
                                {
                                    FashionOther FashionOther = new FashionOther();
                                    #region variation
                                    #endregion variation
                                    type.FashionOther = FashionOther;
                                }
                                else if ((Category.ToLower().Contains("necklace") || Category.ToLower().Contains("bracelet") || Category.ToLower().Contains("anklet")) && Category.ToLower().Contains("/fine"))
                                {
                                    FineNecklaceBraceletAnklet FineNecklaceBraceletAnklet = new FineNecklaceBraceletAnklet();
                                    #region variation
                                    #endregion variation
                                    type.FineNecklaceBraceletAnklet = FineNecklaceBraceletAnklet;
                                }
                                else if (Category.ToLower().Contains("/rings") && Category.ToLower().Contains("/fine"))
                                {
                                    FineRing FineRing = new FineRing();
                                    #region variation
                                    #endregion variation
                                    type.FineRing = FineRing;
                                }
                                else if (Category.ToLower().Contains("/earrings") && Category.ToLower().Contains("/fine"))
                                {
                                    FineEarring FineEarring = new FineEarring();
                                    #region variation
                                    #endregion variation
                                    type.FineEarring = FineEarring;
                                }
                                else if (Category.ToLower().Contains("watches"))
                                {
                                    Watch Watch = new Watch();
                                    #region variation
                                    #endregion variation
                                    type.Watch = Watch;
                                }
                                else
                                {
                                    FineOther FineOther = new FineOther();
                                    #region variation
                                    #endregion variation
                                    type.FineOther = FineOther;
                                }
                                Jewelry.ProductType = type;
                                ProductData.Jewelry = Jewelry;
                            }

                            #endregion Jewelry

                            #region LargeAppliances
                            else if (TemplateName.ToLower() == "large appliances")
                            {
                                LargeAppliances LargeAppliances = new LargeAppliances();
                                LargeAppliancesType type = new LargeAppliancesType();
                                if (Category.ToLower().Contains("microwave ovens"))
                                {
                                    MicrowaveOven MicrowaveOven = new MicrowaveOven();
                                    #region variation
                                    #endregion variation
                                    type.MicrowaveOven = MicrowaveOven;
                                }
                                else if (Category.ToLower().Contains("oven"))
                                {
                                    CookingOven CookingOven = new CookingOven();
                                    #region variation
                                    #endregion variation
                                    type.CookingOven = CookingOven;
                                }
                                else if (Category.ToLower().Contains("cooktops"))
                                {
                                    Cooktop Cooktop = new Cooktop();
                                    #region variation
                                    #endregion variation
                                    type.Cooktop = Cooktop;
                                }
                                else if (Category.ToLower().Contains("dishwasher"))
                                {
                                    Dishwasher Dishwasher = new Dishwasher();
                                    #region variation
                                    #endregion variation
                                    type.Dishwasher = Dishwasher;
                                }
                                else if (Category.ToLower().Contains("range"))
                                {
                                    Range Range = new Range();
                                    #region variation
                                    #endregion variation
                                    type.Range = Range;
                                }
                                else if (Category.ToLower().Contains("refrigerators"))
                                {
                                    RefrigerationAppliance RefrigerationAppliance = new RefrigerationAppliance();
                                    #region variation
                                    #endregion variation
                                    type.RefrigerationAppliance = RefrigerationAppliance;
                                }
                                else if (Category.ToLower().Contains("trash compactor"))
                                {
                                    TrashCompactor TrashCompactor = new TrashCompactor();
                                    #region variation
                                    #endregion variation
                                    type.TrashCompactor = TrashCompactor;
                                }
                                else if (Category.ToLower().Contains("trash compactor"))
                                {
                                    TrashCompactor TrashCompactor = new TrashCompactor();
                                    #region variation
                                    #endregion variation
                                    type.TrashCompactor = TrashCompactor;
                                }
                                else
                                {
                                    ApplianceAccessory ApplianceAccessory = new ApplianceAccessory();
                                    #region variation
                                    #endregion variation
                                    type.ApplianceAccessory = ApplianceAccessory;
                                }
                                LargeAppliances.ProductType = type;
                                ProductData.LargeAppliances = LargeAppliances;
                            }
                            #endregion LargeAppliances

                            #region MusicalInstruments
                            else if (TemplateName.ToLower() == "musical instruments, stage & studio")
                            {
                                // DescriptionData.ModelNumber = dr["SKU"].ToString();
                                //   DescriptionData.ModelName = dr["SKU"].ToString();
                                MusicalInstruments MusicalInstruments = new MusicalInstruments();
                                MusicalInstrumentsType type = new MusicalInstrumentsType();
                                if (Category.ToLower().Contains("wood"))
                                {
                                    BrassAndWoodwindInstruments BrassAndWoodwindInstruments = new BrassAndWoodwindInstruments();
                                    #region variation
                                    #endregion variation
                                    BrassAndWoodwindInstruments.ModelName = dr["SKU"].ToString();
                                    BrassAndWoodwindInstruments.ModelNumber = dr["SKU"].ToString();
                                    type.BrassAndWoodwindInstruments = BrassAndWoodwindInstruments;
                                }
                                else if (Category.ToLower().Contains("guitars"))
                                {
                                    Guitars Guitars = new Guitars();
                                    #region variation
                                    #endregion variation
                                    Guitars.ModelName = dr["SKU"].ToString();
                                    Guitars.ModelNumber = dr["SKU"].ToString();
                                    type.Guitars = Guitars;
                                }
                                else if (Category.ToLower().Contains("accessories"))
                                {
                                    InstrumentPartsAndAccessories InstrumentPartsAndAccessories = new InstrumentPartsAndAccessories();
                                    #region variation
                                    #endregion variation
                                    InstrumentPartsAndAccessories.ModelName = dr["SKU"].ToString();
                                    InstrumentPartsAndAccessories.ModelNumber = dr["SKU"].ToString();
                                    type.InstrumentPartsAndAccessories = InstrumentPartsAndAccessories;
                                }
                                else if (Category.ToLower().Contains("keyboard"))
                                {
                                    KeyboardInstruments KeyboardInstruments = new KeyboardInstruments();
                                    #region variation
                                    #endregion variation
                                    KeyboardInstruments.ModelName = dr["SKU"].ToString();
                                    KeyboardInstruments.ModelNumber = dr["SKU"].ToString();
                                    type.KeyboardInstruments = KeyboardInstruments;
                                }
                                else if (Category.ToLower().Contains("percussion"))
                                {
                                    PercussionInstruments PercussionInstruments = new PercussionInstruments();
                                    #region variation
                                    #endregion variation
                                    PercussionInstruments.ModelName = dr["SKU"].ToString();
                                    PercussionInstruments.ModelNumber = dr["SKU"].ToString();
                                    type.PercussionInstruments = PercussionInstruments;
                                }
                                else if (Category.ToLower().Contains("recording"))
                                {
                                    SoundAndRecordingEquipment SoundAndRecordingEquipment = new SoundAndRecordingEquipment();
                                    #region variation
                                    #endregion variation
                                    SoundAndRecordingEquipment.ModelName = dr["SKU"].ToString();
                                    SoundAndRecordingEquipment.ModelNumber = dr["SKU"].ToString();
                                    type.SoundAndRecordingEquipment = SoundAndRecordingEquipment;
                                }
                                else
                                {
                                    MiscWorldInstruments MiscWorldInstruments = new MiscWorldInstruments();
                                    #region variation
                                    #endregion variation
                                    MiscWorldInstruments.ModelName = dr["SKU"].ToString();
                                    MiscWorldInstruments.ModelNumber = dr["SKU"].ToString();
                                    type.MiscWorldInstruments = MiscWorldInstruments;
                                }

                                MusicalInstruments.ProductType = type;
                                ProductData.MusicalInstruments = MusicalInstruments;
                            }
                            #endregion MusicalInstruments

                            #region HomeImprovement
                            else if (TemplateName.ToLower() == "tools & building supplies")
                            {
                                HomeImprovement HomeImprovement = new HomeImprovement();
                                HomeImprovementType type = new HomeImprovementType();
                                if (Category.ToLower().Contains("building"))
                                {
                                    BuildingMaterials BuildingMaterials = new BuildingMaterials();
                                    string Material = dr["ProductName"].ToString();
                                    if (Material.Length > 45)
                                        Material = Material.Substring(0, 45);
                                    BuildingMaterials.Material = Material;
                                    #region variation
                                    #endregion variation
                                    type.BuildingMaterials = BuildingMaterials;
                                }
                                else if (Category.ToLower().Contains("hardware"))
                                {
                                    Hardware Hardware = new Hardware();
                                    #region variation
                                    #endregion variation
                                    type.Hardware = Hardware;
                                }
                                else if (Category.ToLower().Contains("electrical"))
                                {
                                    Electrical Electrical = new Electrical();
                                    #region variation
                                    #endregion variation
                                    type.Electrical = Electrical;
                                }
                                else if (Category.ToLower().Contains("plumbing"))
                                {
                                    PlumbingFixtures PlumbingFixtures = new PlumbingFixtures();
                                    #region variation
                                    #endregion variation
                                    type.PlumbingFixtures = PlumbingFixtures;
                                }
                                else if (Category.ToLower().Contains("organizers"))
                                {
                                    OrganizersAndStorage OrganizersAndStorage = new OrganizersAndStorage();
                                    #region variation
                                    #endregion variation
                                    type.OrganizersAndStorage = OrganizersAndStorage;
                                }
                                else if (Category.ToLower().Contains("security"))
                                {
                                    SecurityElectronics SecurityElectronics = new SecurityElectronics();
                                    #region variation
                                    #endregion variation
                                    type.SecurityElectronics = SecurityElectronics;
                                }
                                else
                                {
                                    Tools Tools = new Tools();
                                    string Material = dr["ProductName"].ToString();
                                    if (Material.Length > 45)
                                        Material = Material.Substring(0, 45);
                                    Tools.Material = Material;
                                    #region variation
                                    #endregion variation
                                    type.Tools = Tools;
                                }
                                HomeImprovement.ProductType = type;
                                ProductData.HomeImprovement = HomeImprovement;
                            }
                            #endregion HomeImprovement

                            #region Clothing & Accessories

                            else if (TemplateName.ToLower() == "clothing & accessories")
                            {
                                ClothingAccessories ClothingAccessories = new ClothingAccessories();
                                //  ClothingAccessories.ProductType = ProductType.ClothingAccessories;
                                if (_IsSized)
                                {
                                    //For Size
                                }
                                ClassificationData data = new ClassificationData();
                                if (DescriptionData.Title.ToLower().Contains("women"))
                                    data.Department = "Women";
                                else
                                    data.Department = "Men";
                                ClothingAccessories.ClassificationData = data;
                                ProductData.ClothingAccessories = ClothingAccessories;
                            }
                            #endregion Clothing & Accessories

                            #region OfficeProducts
                            else if (TemplateName.ToLower() == "office products")
                            {
                                Office Office = new Office();
                                OfficeType type = new OfficeType();
                                if (Category.ToLower().Contains("calculators"))
                                {
                                    Calculator Calculator = new Calculator();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Calculator = Calculator;
                                }
                                else if (Category.ToLower().Contains("ink & toner"))
                                {
                                    InkToner InkToner = new InkToner();
                                    #region variationdata
                                    #endregion variationdata
                                    type.InkToner = InkToner;
                                }
                                else if (Category.ToLower().Contains("telephones"))
                                {
                                    OfficePhone OfficePhone = new OfficePhone();
                                    #region variationdata
                                    #endregion variationdata
                                    type.OfficePhone = OfficePhone;
                                }
                                else if (Category.ToLower().Contains("printer"))
                                {
                                    OfficePrinter OfficePrinter = new OfficePrinter();
                                    #region variationdata
                                    #endregion variationdata
                                    type.OfficePrinter = OfficePrinter;
                                }
                                else if (Category.ToLower().Contains("scanner"))
                                {
                                    OfficeScanner OfficeScanner = new OfficeScanner();
                                    #region variationdata
                                    #endregion variationdata
                                    type.OfficeScanner = OfficeScanner;
                                }
                                else
                                {
                                    OfficeProducts OfficeProducts = new OfficeProducts();
                                    #region variationdata
                                    #endregion variationdata
                                    type.OfficeProducts = OfficeProducts;
                                }
                                Office.ProductType = type;
                                ProductData.Office = Office;
                            }
                            #endregion OfficeProducts

                            #region PersonalComputers
                            else if (TemplateName.ToLower() == "personal computers")
                            {
                                Computers Computers = new Computers();
                                ComputersType type = new ComputersType();
                                if (Category.ToLower().Contains("bags"))
                                {
                                    CarryingCaseOrBag CarryingCaseOrBag = new CarryingCaseOrBag();
                                    #region variationdata
                                    #endregion variationdata
                                    type.CarryingCaseOrBag = CarryingCaseOrBag;
                                }
                                else if (Category.ToLower().Contains("add-ons"))
                                {
                                    ComputerAddOn ComputerAddOn = new ComputerAddOn();
                                    #region variationdata
                                    #endregion variationdata
                                    type.ComputerAddOn = ComputerAddOn;
                                }
                                else if (Category.ToLower().Contains("processors"))
                                {
                                    ComputerProcessor ComputerProcessor = new ComputerProcessor();
                                    #region variationdata
                                    #endregion variationdata
                                    type.ComputerProcessor = ComputerProcessor;
                                }
                                else if (Category.ToLower().Contains("drives"))
                                {
                                    ComputerDriveOrStorage ComputerDriveOrStorage = new ComputerDriveOrStorage();
                                    #region variationdata
                                    #endregion variationdata
                                    type.ComputerDriveOrStorage = ComputerDriveOrStorage;
                                }
                                else if (Category.ToLower().Contains("input devices"))
                                {
                                    ComputerInputDevice ComputerInputDevice = new ComputerInputDevice();
                                    #region variationdata
                                    #endregion variationdata
                                    type.ComputerInputDevice = ComputerInputDevice;
                                }
                                else if (Category.ToLower().Contains("speakers"))
                                {
                                    ComputerSpeaker ComputerSpeaker = new ComputerSpeaker();
                                    #region variationdata
                                    #endregion variationdata
                                    type.ComputerSpeaker = ComputerSpeaker;
                                }

                                else if (Category.ToLower().Contains("keyboards"))
                                {
                                    Keyboards Keyboards = new Keyboards();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Keyboards = Keyboards;
                                }
                                else if (Category.ToLower().Contains("monitors"))
                                {
                                    Monitor Monitor = new Monitor();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Monitor = Monitor;
                                }
                                else if (Category.ToLower().Contains("motherboard"))
                                {
                                    Motherboard Motherboard = new Motherboard();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Motherboard = Motherboard;
                                }
                                else if (Category.ToLower().Contains("printer"))
                                {
                                    Printer Printer = new Printer();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Printer = Printer;
                                }
                                else if (Category.ToLower().Contains("ram"))
                                {
                                    RamMemory RamMemory = new RamMemory();
                                    #region variationdata
                                    #endregion variationdata
                                    type.RamMemory = RamMemory;
                                }
                                else if (Category.ToLower().Contains("scanner"))
                                {
                                    Scanner Scanner = new Scanner();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Scanner = Scanner;
                                }
                                else if (Category.ToLower().Contains("computer components"))
                                {
                                    ComputerComponent ComputerComponent = new ComputerComponent();
                                    #region variationdata
                                    #endregion variationdata
                                    type.ComputerComponent = ComputerComponent;
                                }
                                else
                                {
                                    Computer Computer = new Computer();
                                    #region variationdata
                                    #endregion variationdata
                                    type.Computer = Computer;
                                }
                                Computers.ProductType = type;
                                ProductData.Computers = Computers;
                            }
                            #endregion PersonalComputers

                            #region Sports Memorabilia
                            else if (TemplateName.ToLower() == "sports memorabilia")
                            {
                                SportsMemorabilia SportsMemorabilia = new SportsMemorabilia();
                                SportsMemorabilia.ProductType = ProductType.SportsMemorabilia;
                                SportsMemorabilia.AuthenticatedBy = "";
                                SportsMemorabilia.ConditionProvidedBy = "";
                                SportsMemorabilia.ConditionRating = "";
                                ProductData.SportsMemorabilia = SportsMemorabilia;
                            }
                            #endregion Sports Memorabilia

                            #region videos
                            else if (TemplateName.ToLower() == "videos")
                            {
                                Video Video = new Video();
                                VideoType type = new VideoType();
                                VideoDVD VideoDVD = new VideoDVD();
                                type.VideoDVD = VideoDVD;
                                Video.ProductType = type;
                                ProductData.Video = Video;

                            }
                            #endregion videos

                            #endregion ProductData
                            #endregion ItemType
                            Prd.DescriptionData = DescriptionData;
                            #endregion DescriptionData
                            Prd.ProductData = ProductData;
                        }
                        Message.Product = Prd;
                        Messages.Add(Message);
                    }
                    catch
                    { }
                }

                return Messages;
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in creating message(Feed) for Product Data of Feed Type " + _Type.ToString() + " for store: " + StoreName + " " + (_IsSized == true ? "For size Products" : "For without size products") + " . Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                return null;
            }
        }
        private List<Message> GetSubmitPrice(OperationType _Type, string StoreName, bool _IsSized)
        {
            try
            {
                List<Message> Messages = new List<Message>();
                Message Message;
                StandardPrice StandardPrice;
                Price Price;
                Sale Sale;
                SalePrice SalePrice;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Message = new Message();
                    Price = new Price();
                    StandardPrice = new StandardPrice();
                    SalePrice = new SalePrice();
                    Sale = new Sale();
                    Message.MessageID = Messages.Count + 1;
                    Message.OperationType = OperationType.Update;

                    if (dr["SKU"].ToString().Length > 0)
                    {
                        Price.SKU = dr["SKU"].ToString();
                        if (Convert.ToDecimal(dr["Price"].ToString()) > 0M)
                        {
                            StandardPrice.currency = currency.CAD;
                            StandardPrice.Value = Convert.ToDecimal(dr["Price"].ToString());
                            Price.StandardPrice = StandardPrice;
                        }
                        if (Convert.ToDecimal(dr["SalePrice"].ToString()) > 0M)
                        {
                            SalePrice.currency = currency.CAD;
                            SalePrice.Value = Convert.ToDecimal(dr["SalePrice"].ToString());
                            Sale.SalePrice = SalePrice;
                        }
                        Message.Price = Price;
                        Messages.Add(Message);
                    }
                }

                return Messages;
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in creating message(Feed) for Price of Feed Type " + _Type.ToString() + " for store: " + StoreName + " " + (_IsSized == true ? "For size Products" : "For without size products") + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                return null;
            }

        }
        private List<Message> GetSubmitQuantity(OperationType _Type, string StoreName, bool _IsSized)
        {
            try
            {

                int handlingdays = 5;
                try
                {
                    SqlDataReader dr = _db.GetDR("select isnull(handlingdays,5) as handlingdays from store where storename='" + StoreName + "'");
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            handlingdays = Convert.ToInt32(dr["handlingdays"]);
                        }
                    }
                }
                catch
                { handlingdays = 5; }
                List<Message> Messages = new List<Message>();
                Message Message;
                Inventory Inventory;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Message = new Message();
                    Inventory = new Inventory();
                    Message.MessageID = Messages.Count + 1;
                    Message.OperationType = OperationType.Update;
                    if (dr["SKU"].ToString().Length > 0)
                    {
                        Inventory.SKU = dr["SKU"].ToString();
                        Inventory.Quantity = Convert.ToInt32(dr["Inventory"].ToString());
                        Inventory.FulfillmentLatency = handlingdays;// Convert.ToInt32(dr["FulfillmentLatency"].ToString());
                        Message.Inventory = Inventory;
                        Messages.Add(Message);
                    }
                }

                return Messages;
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in creating message(Feed) for Quantity of Feed Type " + _Type.ToString() + " for Store: " + StoreName + " " + (_IsSized == true ? "For size Products" : "For without size products") + " . Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                return null;
            }
        }
        private List<Message> GetSubmitImages(OperationType _Type, string StoreName, bool _IsSized)
        {
            try
            {
                List<Message> Messages = new List<Message>();
                Message Message;
                ProductImage ProductImage;
                Int32 Index = 0;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    try
                    {
                        Index = 0;

                        Images Images = this.GetImages(dr["Images"].ToString());
                        foreach (Image Img in Images.Image)
                        {

                            Message = new Message();
                            ProductImage = new ProductImage();
                            Message.MessageID = Messages.Count + 1;
                            Message.OperationType = OperationType.Update;
                            if (dr["SKU"].ToString().Length > 0)
                            {
                                ProductImage.SKU = dr["SKU"].ToString();
                                if (Img.ImageType == "Main")
                                {
                                    ProductImage.ImageType = ImageType.Main;
                                    ProductImage.ImageLocation = (Img.ImageURL.ToLower().Contains("http://") || Img.ImageURL.ToLower().Contains("https://")) ? Img.ImageURL : "http://" + Img.ImageURL;
                                }
                                else
                                {
                                    Index = Index + 1;
                                    ProductImage.ImageType = (ImageType)Enum.Parse(typeof(ImageType), "PT" + Index.ToString());
                                    ProductImage.ImageLocation = (Img.ImageURL.ToLower().Contains("http://") || Img.ImageURL.ToLower().Contains("https://")) ? Img.ImageURL : "http://" + Img.ImageURL;

                                }


                                Message.ProductImage = ProductImage;
                                Messages.Add(Message);
                            }
                            if (Index == 8)
                            {
                                break;
                            }

                        }
                    }
                    catch
                    { }


                }

                return Messages;
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in creating message(Feed) for Images of Feed Type " + _Type.ToString() + " for Store: " + StoreName + " " + (_IsSized == true ? "For size Products" : "For without size products") + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                return null;
            }
        }
        private List<Message> GetSubmitShipping(OperationType _Type, string StoreName, bool _IsSized)
        {
            try
            {
                List<Message> Messages = new List<Message>();
                Message Message;
                Override Shipping;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Message = new Message();
                    Shipping = new Override();
                    Message.MessageID = Messages.Count + 1;
                    Message.OperationType = OperationType.Update;
                    if (dr["SKU"].ToString().Length > 0)
                    {
                        Shipping.SKU = dr["SKU"].ToString();
                        ShippingOverride _ShipOverride = new ShippingOverride();
                        _ShipOverride.ShipOption = "Std CA Dom";
                        // _ShipOverride.FulfillmentServiceLevel = "Standard";
                        _ShipOverride.Type = "Exclusive";
                        ShipAmount _Amt = new ShipAmount();
                        _Amt.currency = currency.CAD;
                        _Amt.Value = Math.Round(Convert.ToDecimal(dr["Shipping"].ToString()), 2);
                        _ShipOverride.ShipAmount = _Amt;
                        // _ShipOverride.Locale = "InternationalCanada";
                        Shipping.ShippingOverride = _ShipOverride;

                        Message.Override = Shipping;
                        Messages.Add(Message);
                    }
                }
                return Messages;
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in creating message(Feed) for Shipping of Feed Type " + _Type.ToString() + " for Store: " + StoreName + " " + (_IsSized == true ? "For size Products" : "For without size products") + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                return null;

            }

        }
    }
}
