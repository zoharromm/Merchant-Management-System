﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
namespace AmazonLister.SubmitFBA
{

    [XmlRoot]
    class AmazonEnvelope
    {
        [XmlElement]
        Header Header { get; set; }
        [XmlElement]
        string MessageType { get; set; }

    }
    [XmlRoot]
    class Header
    {
        [XmlElement]
        string DocumentVersion { get; set; }
        [XmlElement]
        string MerchantIdentifier { get; set; }
    }
    [XmlRoot]
    class Message
    {
        [XmlElement]
        string MessageID { get; set; }
        string OperationType { get; set; }
        [XmlElement]
        Inventory Inventory { get; set; }
    }

    [XmlRoot]
    class Inventory
    {
        [XmlElement]
        string SKU { get; set; }
        [XmlElement]
        string FulfillmentCenterID { get; set; }
        [XmlElement]
        string Lookup { get; set; }
        [XmlElement]
        string SwitchFulfillmentTo { get; set; }
    }
}
