﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace AmazonLister
{
    [XmlRoot]
    public class Price
    {
        [XmlElement]
        public string SKU { get; set; }
        [XmlElement]
        public StandardPrice StandardPrice { get; set; }
        [XmlElement]
        public Sale Sale { get; set; }
    }
    [XmlRoot]
    public class StandardPrice
    {
        [XmlAttribute("currency")]
        public currency currency { get; set; }
        [XmlText]
        public Decimal Value { get; set; }
    }
    [XmlRoot]
    public class Sale
    {
        [XmlElement]
        public DateTime StartDate { get; set; }
        [XmlElement]
        public DateTime EndDate { get; set; }
        [XmlElement]
        public SalePrice SalePrice { get; set; }
    }
    public class SalePrice
    {
        [XmlAttribute("currency")]
        public currency currency { get; set; }
        [XmlText]
        public Decimal Value { get; set; }
    }
}
