﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;
using System.Xml.Serialization;

namespace AmazonLister
{
    class AmazonEnvelope
    {
        [XmlElement]
        public Header Header { get; set; }
        [XmlElement]
        public string MessageType { get; set; }
        [XmlElement]
        public string PurgeAndReplace { get; set; }
    }

    [XmlRoot]
    class Header
    {
        [XmlElement]
        public string DocumentVersion { get; set; }
        [XmlElement]
        public string MerchantIdentifier { get; set; }
    }

    [XmlRoot]
    class Message
    {
        [XmlElement]
        public string MessageID { get; set; }
        [XmlElement]
        public string OperationType { get; set; }
        [XmlElement]
        public string DocumentVersion { get; set; }

    }
    [XmlRoot]
    class Product
    {
        [XmlElement]
        public string SKU { get; set; }
        [XmlElement]
        public string ProductTaxCode { get; set; }
        [XmlElement]
        public string LaunchDate { get; set; }
    }
    [XmlRoot]
    class DescriptionData
    {
        [XmlElement]
        public string Title { get; set; }
        [XmlElement]
        public string Brand { get; set; }
        [XmlElement]
        public string Description { get; set; }
        [XmlElement]
        public string BulletPoint { get; set; }
        [XmlElement]
        public string Manufacturer { get; set; }
        [XmlElement]
        public string SearchTerms { get; set; }
        [XmlElement]
        public string ItemType { get; set; }
        [XmlElement]
        public string IsGiftWrapAvailable { get; set; }
        [XmlElement]
        public string RecommendedBrowseNode { get; set; }

    }
    class ProductData
    {
        [XmlElement]
        public Home Home { get; set; }
    }
    class Home
    {
        [XmlElement]
        public VariationData VariationData { get; set; }
    }
    class VariationData
    {
        [XmlElement]
        public string VariationTheme { get; set; }
        [XmlElement]
        public string Material { get; set; }
        [XmlElement]
        public string ThreadCount { get; set; }

    }



}
