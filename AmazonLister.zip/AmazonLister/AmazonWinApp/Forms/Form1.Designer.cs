﻿namespace AmazonWinApp
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnStartUploading = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnImages = new System.Windows.Forms.Button();
            this.btnPrice = new System.Windows.Forms.Button();
            this.btnQuantity = new System.Windows.Forms.Button();
            this.btnListSKU = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(730, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Amazon Lister";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgv);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(100, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(630, 527);
            this.panel2.TabIndex = 2;
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 30;
            this.dgv.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dgv.Size = new System.Drawing.Size(628, 487);
            this.dgv.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnStartUploading);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 487);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(628, 38);
            this.panel3.TabIndex = 0;
            // 
            // btnStartUploading
            // 
            this.btnStartUploading.Location = new System.Drawing.Point(458, 4);
            this.btnStartUploading.Name = "btnStartUploading";
            this.btnStartUploading.Size = new System.Drawing.Size(154, 28);
            this.btnStartUploading.TabIndex = 0;
            this.btnStartUploading.Text = "Start Uploading";
            this.btnStartUploading.UseVisualStyleBackColor = true;
            this.btnStartUploading.Click += new System.EventHandler(this.btnStartUploading_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnImages);
            this.panel1.Controls.Add(this.btnPrice);
            this.panel1.Controls.Add(this.btnQuantity);
            this.panel1.Controls.Add(this.btnListSKU);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 527);
            this.panel1.TabIndex = 1;
            // 
            // btnImages
            // 
            this.btnImages.Location = new System.Drawing.Point(1, 100);
            this.btnImages.Name = "btnImages";
            this.btnImages.Size = new System.Drawing.Size(96, 25);
            this.btnImages.TabIndex = 0;
            this.btnImages.Text = "Submit  Img";
            this.btnImages.UseVisualStyleBackColor = true;
            // 
            // btnPrice
            // 
            this.btnPrice.Location = new System.Drawing.Point(1, 71);
            this.btnPrice.Name = "btnPrice";
            this.btnPrice.Size = new System.Drawing.Size(94, 23);
            this.btnPrice.TabIndex = 0;
            this.btnPrice.Text = "Submit Price";
            this.btnPrice.UseVisualStyleBackColor = true;
            // 
            // btnQuantity
            // 
            this.btnQuantity.Location = new System.Drawing.Point(1, 42);
            this.btnQuantity.Name = "btnQuantity";
            this.btnQuantity.Size = new System.Drawing.Size(94, 23);
            this.btnQuantity.TabIndex = 0;
            this.btnQuantity.Text = "Submit Qty";
            this.btnQuantity.UseVisualStyleBackColor = true;
            // 
            // btnListSKU
            // 
            this.btnListSKU.Location = new System.Drawing.Point(1, 13);
            this.btnListSKU.Name = "btnListSKU";
            this.btnListSKU.Size = new System.Drawing.Size(94, 23);
            this.btnListSKU.TabIndex = 0;
            this.btnListSKU.Text = "Submit SKU";
            this.btnListSKU.UseVisualStyleBackColor = true;
            this.btnListSKU.Click += new System.EventHandler(this.btnListSKU_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 555);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.Text = "Amazon App";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Shown += new System.EventHandler(this.frmMain_Shown);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnStartUploading;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnImages;
        private System.Windows.Forms.Button btnPrice;
        private System.Windows.Forms.Button btnQuantity;
        private System.Windows.Forms.Button btnListSKU;
    }
}

