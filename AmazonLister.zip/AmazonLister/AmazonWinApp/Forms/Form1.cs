﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AmazonLister;
using MarketplaceWebService.Mock;
using MarketplaceWebService.Model;
using System.Xml.Serialization;
using System.IO;
using System.Net;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.JScript.Vsa;
using Microsoft.JScript.Vsa;
using System.Text.RegularExpressions;


namespace AmazonWinApp
{
    //Error Code Start From 1-10
    public partial class frmMain : Form
    {
        DataSet Products;
        DataSet ds;
        SQLLiteHelper SQL;
        List<AMAZONTemplate> _ListProcessTemplate = new List<AMAZONTemplate>();
        List<Store> _ListStores = new List<Store>();
        List<Category> _ListCategory = new List<Category>();
        List<AmzFeedSubmission> _PendingFeed = new List<AmzFeedSubmission>();
        List<Procedures> _ListSubProcess = new List<Procedures>();
        BusinessLayer.DB _DB = new BusinessLayer.DB();
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        int RequestPool = 10;
        string FeedFormula = "";
        int MaxRecordInFile = 0;
        int MaxNewRecordInFile = 0;
        int ReportGenerateFrequency = -3;
        DataTable _QtyUpdate = new DataTable();
        DataTable _PriceUpdate = new DataTable();
        DataTable _ShippingUpdate = new DataTable();
        DataTable _ImageUpdate = new DataTable();
        DataTable _ClonePrd = new DataTable();
        DataTable _UPCassignment = new DataTable();
        List<AmazonLister.cls.Sellers> sellers = new List<AmazonLister.cls.Sellers>();
        bool TaskStatus = false;
        public frmMain()
        {

            #region Datatable
            DataColumn __UPCassignmentSKUColumn = new DataColumn();
            __UPCassignmentSKUColumn.ColumnName = "UPC";
            __UPCassignmentSKUColumn.DataType = System.Type.GetType("System.String");
            _UPCassignment.Columns.Add(__UPCassignmentSKUColumn);
            DataColumn __UPCassignmentVariantidColumn = new DataColumn();
            __UPCassignmentVariantidColumn.ColumnName = "VariantID";
            __UPCassignmentVariantidColumn.DataType = System.Type.GetType("System.Int32");
            _UPCassignment.Columns.Add(__UPCassignmentVariantidColumn);
            DataColumn __UPCassignmentProductidColumn = new DataColumn();
            __UPCassignmentProductidColumn.ColumnName = "ProductID";
            __UPCassignmentProductidColumn.DataType = System.Type.GetType("System.Int32");
            _UPCassignment.Columns.Add(__UPCassignmentProductidColumn);
            DataColumn __UPCassignmentParentColumn = new DataColumn();
            __UPCassignmentParentColumn.ColumnName = "IsParent";
            __UPCassignmentParentColumn.DataType = System.Type.GetType("System.Int32");
            _UPCassignment.Columns.Add(__UPCassignmentParentColumn);

            DataColumn _QtyInvColumn = new DataColumn();
            _QtyInvColumn.ColumnName = "Inventory";
            _QtyInvColumn.DataType = System.Type.GetType("System.Int32");
            _QtyUpdate.Columns.Add(_QtyInvColumn);
            DataColumn _QtyPriceColumn = new DataColumn();
            _QtyPriceColumn.ColumnName = "Price";
            _QtyPriceColumn.DataType = System.Type.GetType("System.Decimal");
            _QtyUpdate.Columns.Add(_QtyPriceColumn);
            DataColumn _QtySalePriceColumn = new DataColumn();
            _QtySalePriceColumn.ColumnName = "SalePrice";
            _QtySalePriceColumn.DataType = System.Type.GetType("System.Decimal");
            _QtyUpdate.Columns.Add(_QtySalePriceColumn);
            DataColumn _QtySKUColumn = new DataColumn();
            _QtySKUColumn.ColumnName = "SKU";
            _QtySKUColumn.DataType = System.Type.GetType("System.String");
            _QtyUpdate.Columns.Add(_QtySKUColumn);
            DataColumn FulfillmentLatency = new DataColumn();
            FulfillmentLatency.ColumnName = "FulfillmentLatency";
            FulfillmentLatency.DataType = System.Type.GetType("System.Int32");
            _QtyUpdate.Columns.Add(FulfillmentLatency);
            DataColumn _QtyVariantIDColumn = new DataColumn();
            _QtyVariantIDColumn.ColumnName = "VariantID";
            _QtyVariantIDColumn.DataType = System.Type.GetType("System.Int32");
            _QtyUpdate.Columns.Add(_QtyVariantIDColumn);
            DataColumn _QtyProductIDColumn = new DataColumn();
            _QtyProductIDColumn.ColumnName = "ProductID";
            _QtyProductIDColumn.DataType = System.Type.GetType("System.Int32");
            _QtyUpdate.Columns.Add(_QtyProductIDColumn);

            DataColumn _PriceColumn = new DataColumn();
            _PriceColumn.ColumnName = "Price";
            _PriceColumn.DataType = System.Type.GetType("System.Decimal");
            _PriceUpdate.Columns.Add(_PriceColumn);
            DataColumn _SalePriceColumn = new DataColumn();
            _SalePriceColumn.ColumnName = "SalePrice";
            _SalePriceColumn.DataType = System.Type.GetType("System.Decimal");
            _PriceUpdate.Columns.Add(_SalePriceColumn);
            DataColumn _SKUColumn = new DataColumn();
            _SKUColumn.ColumnName = "SKU";
            _SKUColumn.DataType = System.Type.GetType("System.String");
            _PriceUpdate.Columns.Add(_SKUColumn);
            DataColumn _PriceVariantIDColumn = new DataColumn();
            _PriceVariantIDColumn.ColumnName = "VariantID";
            _PriceVariantIDColumn.DataType = System.Type.GetType("System.Int32");
            _PriceUpdate.Columns.Add(_PriceVariantIDColumn);
            DataColumn _PriceProductIDColumn = new DataColumn();
            _PriceProductIDColumn.ColumnName = "ProductID";
            _PriceProductIDColumn.DataType = System.Type.GetType("System.Int32");
            _PriceUpdate.Columns.Add(_PriceProductIDColumn);

            DataColumn _Image = new DataColumn();
            _Image.ColumnName = "Images";
            _Image.DataType = System.Type.GetType("System.String");
            _ImageUpdate.Columns.Add(_Image);
            DataColumn _ImageSKUColumn = new DataColumn();
            _ImageSKUColumn.ColumnName = "SKU";
            _ImageSKUColumn.DataType = System.Type.GetType("System.String");
            _ImageUpdate.Columns.Add(_ImageSKUColumn);
            DataColumn _ImageVariantIDColumn = new DataColumn();
            _ImageVariantIDColumn.ColumnName = "VariantID";
            _ImageVariantIDColumn.DataType = System.Type.GetType("System.Int32");
            _ImageUpdate.Columns.Add(_ImageVariantIDColumn);
            DataColumn _ImageProductIDColumn = new DataColumn();
            _ImageProductIDColumn.ColumnName = "ProductID";
            _ImageProductIDColumn.DataType = System.Type.GetType("System.Int32");
            _ImageUpdate.Columns.Add(_ImageProductIDColumn);
            DataColumn _dbImage = new DataColumn();
            _dbImage.ColumnName = "Image url";
            _dbImage.DataType = System.Type.GetType("System.String");
            _ImageUpdate.Columns.Add(_dbImage);

            DataColumn _ShipSKUColumn = new DataColumn();
            _ShipSKUColumn.ColumnName = "SKU";
            _ShipSKUColumn.DataType = System.Type.GetType("System.String");
            _ShippingUpdate.Columns.Add(_ShipSKUColumn);
            DataColumn _ShipAMOUNT = new DataColumn();
            _ShipAMOUNT.ColumnName = "Shipping";
            _ShipAMOUNT.DataType = System.Type.GetType("System.Decimal");
            _ShippingUpdate.Columns.Add(_ShipAMOUNT);
            DataColumn _ShippingUVariantIDColumn = new DataColumn();
            _ShippingUVariantIDColumn.ColumnName = "VariantID";
            _ShippingUVariantIDColumn.DataType = System.Type.GetType("System.Int32");
            _ShippingUpdate.Columns.Add(_ShippingUVariantIDColumn);
            DataColumn _ShippingUProductIDColumn = new DataColumn();
            _ShippingUProductIDColumn.ColumnName = "ProductID";
            _ShippingUProductIDColumn.DataType = System.Type.GetType("System.Int32");
            _ShippingUpdate.Columns.Add(_ShippingUProductIDColumn);

            #endregion Datatable
            _ListSubProcess.Add(new Procedures { SizeParameter = false, ProcedureName = "AmazonWebServiceUpdateProducts", _Type = AmazonLister.OperationType.Update });
            // _ListSubProcess.Add(new Procedures { SizeParameter = false, ProcedureName = "AmazonWebServiceDeleteProducts", _Type = AmazonLister.OperationType.Delete });
            _ListSubProcess.Add(new Procedures { SizeParameter = false, ProcedureName = "AmazonWebServiceNewProducts", _Type = AmazonLister.OperationType.Update });
            InitializeComponent();
        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            #region BindSellers
            BindSellers();
            #endregion BindSellers
            Timer t = new Timer();
            t.Interval = 18000;
            t.Enabled = true;
            timer1_Tick(null, null);
            t.Tick += new EventHandler(timer1_Tick);

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!TaskStatus)
            {
                TaskStatus = true;
                System.Threading.Thread triggerThread = new System.Threading.Thread(Trigger);
                triggerThread.Start();
            }
        }
        private void frmMain_Shown(object sender, EventArgs e)
        {
            this.Show();

        }
        public void Trigger()
        {
            try
            {
                foreach (AmazonLister.cls.Sellers seller in sellers)
                {

                    #region FeedStatus
                    GetFeedStatus(seller);
                    #endregion FeedStatus

                    RequestPool = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RequestPool"]);
                    MaxRecordInFile = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxRecordInFile"]);
                    MaxNewRecordInFile = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxNewRecordInFile"]);
                    FeedFormula = System.Configuration.ConfigurationManager.AppSettings["FeedFormula"].ToString();
                    ReportGenerateFrequency = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["ReportGenerateFrequency"]);
                    #region BindStore
                    BindStore(seller.SellerID);
                    #endregion BindStore
                    #region Loop Through Template

                    foreach (Store str in _ListStores)
                    {
                        foreach (Procedures _Prc in _ListSubProcess)
                        {
                            ListingProcess(str.Name, _Prc.ProcedureName, _Prc._Type, _Prc.SizeParameter, str.StoreID, seller);
                            Application.DoEvents();
                        }
                    }

                    #endregion Loop Through Template
                    #region FeedStatus
                    GetFeedStatus(seller);
                    #endregion FeedStatus

                    #region Report
                    if (CheckStatusOfReportGenerate(seller.SellerID))
                    {
                        int[] reportID = new int[] { 3, 6 };
                        foreach (int id in reportID)
                        {
                            RequestReportResponse response = new AmazonWebService(seller).GetRport(id, -1);
                            if (response.RequestReportResult != null)
                            {
                                try
                                {
                                    string lQuery1 = string.Format("Insert into AmzReportSubmission(ReportSubmissionID,SubmissionType,SubmissionDate, SubmissionStatus,SellerID) Values ({0},{1},{2},{3},{4})",
                                                                  Helper.SingleQouts(response.RequestReportResult.ReportRequestInfo.ReportRequestId),
                                                                  Helper.SingleQouts(response.RequestReportResult.ReportRequestInfo.ReportType),
                                                                  Helper.SingleQouts(DateTime.Now.ToString()),
                                                                  Helper.SingleQouts(response.RequestReportResult.ReportRequestInfo.ReportProcessingStatus), seller.SellerID);
                                    _DB.ExecuteCommand(lQuery1);
                                }
                                catch (Exception Exp)
                                {
                                    _Mail.SendMail("Issue Occured in inserting report ids in database. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                                }
                                Application.DoEvents();
                                System.Threading.Thread.Sleep(30000);
                            }
                            else
                            {
                                _Mail.SendMail("Issue Occured in generating report request at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                            }
                        }
                    }
                    CheckReportSatus(seller);
                    #endregion Report
                    #region CleanDatabase
                    _DB.GetDataset("Markhub_CleanDatabase", CommandType.StoredProcedure, "");
                    CleanDrive(seller.SellerID);
                    #endregion CleanDatabase
                }
                System.Threading.Thread.Sleep(300000);
                TaskStatus = false;
                Application.DoEvents();
            }
            catch { }
        }
        public void CleanDrive(int SellerID)
        {
            try
            {
                string[] files = Directory.GetFiles(Application.StartupPath + "/FeedFiles/" + SellerID);
                foreach (string file in files)
                {
                    FileInfo fi = new FileInfo(file);
                    if (fi.CreationTime < DateTime.Now.AddDays(-5))
                        fi.Delete();
                }
            }
            catch { }

        }
        #region reportSection
        public bool CheckStatusOfReportGenerate(int SellerID)
        {
            int records = 0;
            SqlDataReader reader = null;
            try
            {
                reader = _DB.GetDR("select COUNT(*)  as count from AmzReportSubmission where DATEPART(dd,SubmissionDate)=DATEPART(dd,GETDATE()) and SellerID=" + SellerID);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        records = Convert.ToInt32(reader[0]);
                    }
                }
                reader.Close();
            }
            catch (Exception exp)
            {
                reader.Close();
                _Mail.SendMail("Issue Occured in CheckStatusOfReportGenerate function at date " + DateTime.Now.ToString() + " Exception:" + exp.Message, "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            return records > 0 ? false : true;

        }
        public void CheckReportSatus(AmazonLister.cls.Sellers seller)
        {
            try
            {
                DataTable ltbl = _DB.GetDataset(string.Format("Select * from AmzReportSubmission Where SubmissionStatus!='Completed' and isnull(Error,0) =0  and DATEDIFF(HH, GETDATE(), SubmissionDate)<24  and SellerID=" + seller.SellerID + "   order by reportid"), CommandType.Text, "").Tables[0];
                if (ltbl.Rows.Count != 0)
                {
                    ProcessReport(ltbl, seller);
                }
            }
            catch (Exception exp)
            {
                _Mail.SendMail("Issue Occured in CheckReportSatus function at date " + DateTime.Now.ToString() + " Exception:" + exp.Message, "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void ProcessReport(DataTable ltbl, AmazonLister.cls.Sellers seller)
        {
            int unprocessedReports = (from record in ltbl.AsEnumerable()
                                      where record.Field<string>("SubmissionStatus") == "_SUBMITTED_"
                                      select record).Count();
            int TimeCounter = 0;
            while (unprocessedReports > 0 && TimeCounter < 51)
            {
                foreach (DataRow _Row in ltbl.Rows)
                {
                    if (_Row["SubmissionStatus"].ToString() == "_SUBMITTED_")
                    {

                        if (!Directory.Exists(Helper.ZGetReportFeed + seller.SellerID))
                            Directory.CreateDirectory(Helper.ZGetReportFeed + seller.SellerID);
                        GetReportResponse reportResponse = GetResponseOfReport(_Row["ReportSubmissionID"].ToString(), "", seller);
                        _Row["SubmissionStatus"] = "Completed";
                        #region process response
                        ReadReportFile(_Row["ReportSubmissionID"].ToString(), seller.SellerID);
                        #endregion process response
                        _DB.ExecuteCommand("Update AmzReportSubmission set SubmissionStatus='Completed' where SellerID=" + seller.SellerID + " and ReportSubmissionID='" + _Row["ReportSubmissionID"].ToString() + "'");

                        Application.DoEvents();
                        System.Threading.Thread.Sleep(30000);


                    }
                }

                unprocessedReports = (from record in ltbl.AsEnumerable()
                                      where record.Field<string>("SubmissionStatus") == "_SUBMITTED_"
                                      select record).Count();
                Application.DoEvents();
                TimeCounter++;
            }

        }
        public void ReadReportFile(string ReportID, int SellerID)
        {
            DataTable Table = new DataTable();
            try
            {
                if (!Directory.Exists(Helper.ZGetReportFeed + SellerID))
                    Directory.CreateDirectory(Helper.ZGetReportFeed + SellerID);
                string[] csvRows = System.IO.File.ReadAllLines(Helper.ZGetReportFeed + SellerID + "/" + ReportID + ".txt");
                string[] fields = null;
                for (int i = 0; i < csvRows.Count(); i++)
                {
                    fields = csvRows[i].Split(new string[] { "\t" }, StringSplitOptions.None);
                    if (i == 0)
                    {
                        for (int j = 0; j < fields.Count(); j++)
                            Table.Columns.Add(fields[j]);
                    }
                    else
                    {
                        DataRow row = Table.NewRow();
                        row.ItemArray = fields;
                        Table.Rows.Add(row);
                    }
                }
            }
            catch (Exception Exp)
            {
                Table.Rows.Clear();
                _Mail.SendMail("ReadReportFile Function.Issue Occured in Read Feed File having id " + ReportID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }

            if (Table.Rows.Count > 0)
            {
                if (Table.Columns.Count == 4)
                {
                    int noOfParts = 0;
                    int TotalNoOfRecords = Table.Rows.Count;
                    if (TotalNoOfRecords % 2000 == 0)
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000);
                    else
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000) + 1;
                    for (int i = 0; i < noOfParts; i++)
                    {
                        try
                        {
                            _DB.GetDatasetByPassDatatable("MarkHub_SyncAmazonProductData", Table.AsEnumerable().Skip(i * 2000).Take(2000).CopyToDataTable(), "@Table", CommandType.StoredProcedure, "@type,1");
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("ReadReportFile Function.Issue Occured in sync asin etc information in database for  " + ReportID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                else
                {
                    DataTable soldListing = new DataTable();
                    soldListing.Columns.Add("seller-sku", typeof(string));
                    soldListing.Columns.Add("quantity", typeof(int));
                    soldListing.Columns.Add("price", typeof(decimal));
                    soldListing.Columns.Add("product-id", typeof(string));
                    try
                    {
                        foreach (DataRow Row in Table.Rows)
                        {
                            DataRow soldRow = soldListing.NewRow();
                            soldRow[0] = Row["sku"].ToString();
                            soldRow[1] = Convert.ToInt32(Row["quantity"]);
                            soldRow[2] = Convert.ToDecimal(Row["price"]);
                            soldListing.Rows.Add(soldRow);

                        }
                        if (soldListing.Rows.Count > 0)
                        {
                            int noOfParts = 0;
                            int TotalNoOfRecords = soldListing.Rows.Count;
                            if (TotalNoOfRecords % 2000 == 0)
                                noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000);
                            else
                                noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000) + 1;
                            for (int i = 0; i < noOfParts; i++)
                            {
                                try
                                {
                                    _DB.GetDatasetByPassDatatable("MarkHub_SyncAmazonProductData", soldListing.AsEnumerable().Skip(i * 2000).Take(2000).CopyToDataTable(), "@Table", CommandType.StoredProcedure, "@type,2");
                                }
                                catch (Exception Exp)
                                {
                                    _Mail.SendMail("ReadReportFile Function.Issue Occured in sync asin etc information in database for  " + ReportID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                                }
                            }
                        }
                    }
                    catch (Exception Exp)
                    {
                        _Mail.SendMail("ReadReportFile Function.Issue Occured binding datatable for sold listing for report having id is  " + ReportID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                    }

                }

            }
            #region DeleteFile
            try
            {
                File.Delete(Helper.ZGetReportFeed + SellerID + "/" + ReportID + ".txt");
            }
            catch
            { }
            #endregion DeleteFile
        }
        public GetReportResponse GetResponseOfReport(string reportID, string Token, AmazonLister.cls.Sellers seller)
        {
            GetReportResponse response = new AmazonWebService(seller).ReportData(reportID, Helper.ZGetReportFeed + seller.SellerID + "/" + reportID + ".txt", Token);
            return response;
        }
        #endregion reportSection
        public void BindTemplate(int storeid)
        {
            try
            {
                _ListProcessTemplate = new List<AMAZONTemplate>();
                string TemplateName = "";
                DataSet dsTemplate = _DB.GetDataset("Markhub_GetTemplateStorewise", CommandType.StoredProcedure, "@storeid," + storeid);
                if (dsTemplate.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow rowTemplate in dsTemplate.Tables[0].Rows)
                    {
                        try
                        {
                            TemplateName = rowTemplate["AmazontemplateName"].ToString();
                            AMAZONTemplate _Str = new AMAZONTemplate();
                            _Str.AmazontemplateName = TemplateName;
                            _Str.Processed = false;
                            _ListProcessTemplate.Add(_Str);
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("Issue Occured in adding Template: " + TemplateName + " to Task List. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                try
                {

                }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in binding Template to TaskList. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void BindStore(int SellerID)
        {
            try
            {
                _ListStores = new List<Store>();
                string storeName = "";
                int storeID = 0;
                SqlDataReader _Reader = _DB.GetDR("select Store.StoreID,StoreName  from Store join SellerStoreMapping on Store.storeid=SellerStoreMapping.storeid where SellerID=" + SellerID + " order by Store.storeid");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {

                        try
                        {
                            storeName = _Reader["StoreName"].ToString();
                            storeID = Convert.ToInt32(_Reader["StoreID"]);
                            Store _Str = new Store();
                            _Str.Name = storeName;
                            _Str.StoreID = storeID;
                            _ListStores.Add(_Str);
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("Issue Occured in adding Store : " + storeName + " to Task List. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                try
                {
                    _Reader.Close();
                }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in binding Stores to TaskList. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void BindSellers()
        {
            try
            {
                _ListStores = new List<Store>();

                SqlDataReader _Reader = _DB.GetDR("select * from SellersAccountDetails order by sellerid");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {

                        try
                        {
                            AmazonLister.cls.Sellers seller = new AmazonLister.cls.Sellers();
                            seller.AccessKeyId = _Reader["AccessKeyId"].ToString();
                            seller.ApplicationName = _Reader["ApplicationName"].ToString();
                            seller.ApplicationVersion = _Reader["ApplicationVersion"].ToString();
                            seller.Currency = _Reader["Currency"].ToString();
                            seller.DocumentVersion = _Reader["DocumentVersion"].ToString();
                            seller.MarketplaceIdList = _Reader["MarketplaceIdList"].ToString();
                            seller.Merchant = _Reader["Merchant"].ToString();
                            seller.MerchantIdentifier = _Reader["MerchantIdentifier"].ToString();
                            seller.Password = _Reader["Password"].ToString();
                            seller.SecretKey = _Reader["SecretKey"].ToString();
                            seller.SellerID = Convert.ToInt32(_Reader["SellerID"]);
                            seller.ServiceURL = _Reader["ServiceURL"].ToString();
                            seller.UserName = _Reader["UserName"].ToString();
                            sellers.Add(seller);
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("Issue Occured in adding seller : " + _Reader["SellerID"].ToString() + " to Task List. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                try
                {
                    _Reader.Close();
                }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in binding Stores to TaskList. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void BindCategory(int storeID)
        {
            _ListCategory = new List<Category>();
            Category category = new Category();
            category.CategoryID = 0;
            _ListCategory.Add(category);
            try
            {
                SqlDataReader _Reader = _DB.GetDR("select category.categoryid,Category.name from Category join EntityStore on EntityStore.EntityID=category.categoryid join ProductCategory pc on pc.CategoryID=category.categoryid where EntityStore.StoreID=11 and EntityStore.Name='category' group by category.categoryid,category.Name");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {
                        try
                        {
                            Category cat = new Category();
                            cat.CategoryID = Convert.ToInt32(_Reader[0]);
                            cat.Name = _Reader[1].ToString();
                            _ListCategory.Add(cat);
                        }
                        catch (Exception Exp)
                        {
                            _Mail.SendMail("Issue Occured in Binding categories to Task List. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                        }
                    }
                }
                try
                {
                    _Reader.Close();
                }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in binding Stores to TaskList. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void ListingProcess(string StoreName, string ProcName, AmazonLister.OperationType OperationType, bool IsSize, int storeID, AmazonLister.cls.Sellers Seller)
       {
            GetRecordsFromDB(StoreName, ProcName, IsSize, storeID);
            try
            {
                if (Products.Tables.Count > 0)
                {
                    if (Products.Tables[0].Rows.Count > 0)
                    {
                        CalCulation();
                        if (OperationType == OperationType.Delete)
                        {
                            if (!IsSize)
                                SubmitSimpleSKU(Products, StoreName, OperationType, IsSize, ProcName, Seller);

                        }
                        else if (OperationType == OperationType.Update && ProcName == "AmazonWebServiceUpdateProducts")
                        {
                            if (!IsSize)
                            {
                                UpdateProductLogic();
                                if (_PriceUpdate.Rows.Count > 0)
                                    SubmitPrice(_PriceUpdate, OperationType, StoreName, IsSize, ProcName, Seller);
                                if (_QtyUpdate.Rows.Count > 0)
                                    SubmitInventory(_QtyUpdate, OperationType, StoreName, IsSize, ProcName, Seller);
                                if (_ImageUpdate.Rows.Count > 0)
                                    SubmitImages(_ImageUpdate, OperationType, StoreName, IsSize, ProcName, Seller);
                                //if (_ShippingUpdate.Rows.Count > 0)
                                //    SubmitShipping(_ShippingUpdate, OperationType, StoreName, IsSize, ProcName);
                                if (_ClonePrd.Rows.Count > 0)
                                {
                                    DataSet dsProductUpdate = new DataSet();
                                    DataTable tableUpdateProduct = new DataTable();
                                    foreach (DataColumn _Column in _ClonePrd.Columns)
                                        tableUpdateProduct.Columns.Add(_Column.ColumnName, _Column.DataType);
                                    _ClonePrd.AsEnumerable().ToList().ForEach(row => tableUpdateProduct.ImportRow(row));
                                    dsProductUpdate.Tables.Add(tableUpdateProduct);
                                    SubmitSimpleSKU(dsProductUpdate, StoreName, OperationType, IsSize, ProcName, Seller);
                                }
                            }
                        }
                        else if (OperationType == OperationType.Update && ProcName == "AmazonWebServiceNewProducts")
                        {
                            if (!IsSize)
                            {
                               if (ASINUpc(IsSize))
                                {
                                    try
                                    {
                                        if (Products.Tables[0].Rows.Count > 0)
                                            SubmitSimpleSKU(Products, StoreName, OperationType, IsSize, ProcName, Seller);
                                    }
                                    catch
                                    { }

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in ListingProcess function for  Store : " + StoreName + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public bool ASINUpc(bool Parent)
        {
            bool Result = true;
            List<int> VariantIDCollection = new List<int>();
            try
            {
                _UPCassignment.Rows.Clear();
                _UPCassignment.AcceptChanges();
                #region GetUnAssignedUPC
                DataTable _TableUPC = _DB.GetDataset("GetUnassignedUPC", CommandType.StoredProcedure, "").Tables[0];
                #endregion GetUnAssignedUPC


                if (_TableUPC.Rows.Count > 0)
                {
                    DataTable _TbWithoutUPC = new DataTable();
                    if ((from _Record in Products.Tables[0].AsEnumerable()
                         where _Record.Field<string>("UPC") == ""
                         select _Record).Count() > 0)
                    {

                        _TbWithoutUPC = (from _Record in Products.Tables[0].AsEnumerable()
                                         where _Record.Field<string>("UPC") == ""
                                         select _Record).CopyToDataTable();
                        if (_TbWithoutUPC.Rows.Count > 0)
                        {
                            foreach (DataRow _Row in Products.Tables[0].Rows)
                            {
                                if (_TableUPC.Rows.Count == 0)
                                    break;

                                if (_Row["UPC"].ToString().Trim() == "")
                                {
                                    if (!VariantIDCollection.Contains(Convert.ToInt32(_Row["VariantID"])))
                                    {
                                        VariantIDCollection.Add(Convert.ToInt32(_Row["VariantID"]));
                                        _Row["UPC"] = _TableUPC.Rows[0][0].ToString();
                                        DataRow Row = _UPCassignment.NewRow();
                                        Row[0] = _TableUPC.Rows[0][0].ToString();
                                        if (!Parent)
                                        {
                                            Row[1] = Convert.ToInt32(_Row["VariantID"]);
                                            Row[2] = Convert.ToInt32(_Row["ProductID"]);
                                            Row[3] = 0;
                                        }
                                        else
                                        {
                                            Row[1] = 0;
                                            Row[2] = Convert.ToInt32(_Row["ProductID"]);
                                            Row[3] = 1;
                                        }
                                        _UPCassignment.Rows.Add(Row);
                                        _TableUPC.Rows[0].Delete();
                                        _TableUPC.AcceptChanges();
                                    }
                                }

                            }
                            #region UpdateInDatabase
                            if (_UPCassignment.Rows.Count > 0)
                            {
                                try
                                {
                                    _DB.GetDatasetByPassDatatable("MarkHub_UpdateUPCForProducts", _UPCassignment, "@Table", CommandType.StoredProcedure, "");
                                    Products.AcceptChanges();
                                }
                                catch (Exception Exp)
                                {
                                    _Mail.SendMail("Issue Occured in update UPC assignment in database to table upc,productvariant,product. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                                    Result = false;
                                }
                            }
                            #endregion UpdateInDatabase

                        }
                    }

                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in assigning UPC to Products. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                Result = false;
            }

            #region DeleteProductWithNoUpc
            foreach (DataRow _Row in Products.Tables[0].Rows)
            {
                if (_Row["UPC"].ToString().Trim() == "")
                {
                    _Row.Delete();
                }
            }
            Products.AcceptChanges();
            #endregion DeleteProductWithNoUpc
            return Result;
        }
        public void GetRecordsFromDB(string StoreName, string ProcName, bool IsSize, int storeID)
        {
            Products = new DataSet();
            Products.Tables.Clear();
            DataSet dummy;
            DataTable table = new DataTable();
            try
            {
                int Pages = 0;
                int TotalRecords = 0;
                dummy = new DataSet();
                dummy = _DB.GetDataset(ProcName, CommandType.StoredProcedure, "@TemplateName," + StoreName + ":@IsSize," + IsSize + ":@Storeid," + storeID + ":@categoryid,0:@pagesize,1000:@page,1");
                table = dummy.Tables[0];
                if (dummy.Tables.Count > 1)
                    TotalRecords = Convert.ToInt32(dummy.Tables[1].Rows[0][0]);
                if (TotalRecords % 1000 == 0)
                    Pages = Convert.ToInt32(TotalRecords / 1000);
                else
                    Pages = Convert.ToInt32(TotalRecords / 1000) + 1;

                for (int page = 2; page <= Pages; page++)
                {

                    dummy = new DataSet();
                    dummy = _DB.GetDataset(ProcName, CommandType.StoredProcedure, "@TemplateName," + StoreName + ":@IsSize," + IsSize + ":@Storeid," + storeID + ":@categoryid,0:@pagesize,1000:@page," + page);
                    dummy.Tables[0].AsEnumerable().ToList().ForEach(row => table.ImportRow(row));
                }
                Products.Tables.Add(table.Copy());

            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Getting Records from database for storeid : " + storeID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void CalCulation()
        {
            foreach (DataRow _Row in Products.Tables[0].Rows)
            {
                _Row["Shipping"] = Math.Round(CalulateShipping(Convert.ToDecimal(_Row["Shipping"]), _Row["ShippingFormula"].ToString(), Convert.ToDecimal(_Row["Price"])), 2);
                _Row["Price"] = Math.Round(CalulatePrice(Convert.ToDecimal(_Row["Price"]), _Row["RuleFormula"].ToString(), Convert.ToBoolean(_Row["SkipPriceRule"])), 2);
                if (Convert.ToDecimal(_Row["Price"]) <= 0)
                    _Row["Inventory"] = 0;
            }
            Products.AcceptChanges();
        }
        public decimal CalulatePrice(decimal PrdPrice, string RuleFormula, bool SkipPriceRule)
        {
            try
            {
                if (!SkipPriceRule)
                {
                    PrdPrice = System.Convert.ToDecimal(Math.Round(Evaluate(RuleFormula.ToLower().Replace("{price}", PrdPrice.ToString())), 2));
                }
            }
            catch
            {
                PrdPrice = System.Convert.ToDecimal(Math.Round(Evaluate(PrdPrice.ToString() + "*" + FeedFormula), 2));
            }

            return PrdPrice;
        }
        static double Evaluate(string expression)
        {
            return double.Parse(Microsoft.JScript.Eval.JScriptEvaluate(expression, _engine).ToString());
        }
        private static readonly VsaEngine _engine = VsaEngine.CreateEngine();
        public decimal CalulateShipping(decimal PrdShipping, string ShippingFormula, decimal Price)
        {
            if (PrdShipping == 0)
            {
                try
                {
                    MathEvaluator _Eval = new MathEvaluator();
                    string result = _Eval.Evaluate(ShippingFormula.ToLower().Replace("{price}", Price.ToString()));
                    decimal Shipping = 0;
                    decimal.TryParse(result, out Shipping);
                    PrdShipping = Shipping;
                }
                catch
                {
                    PrdShipping = 20;
                }
            }
            return PrdShipping;
        }
        public int CheckRequestPool(int SellerID)
        {
            int Records = 0;
            try
            {
                SqlDataReader _Reader = _DB.GetDR("select COUNT(*) as Count from AmzFeedSubmission where SellerID=" + SellerID + " and SubmissionDate between DATEADD(minute,-20,getdate()) and GETDATE()");
                if (_Reader.HasRows)
                {
                    while (_Reader.Read())
                    {
                        Records = Convert.ToInt32(_Reader["Count"]);
                    }

                }
                try { _Reader.Close(); }
                catch { }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in getting No of feed Submit within 15 mins. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            return Records;
        }
        public void UpdateProductLogic()
        {
            DataTable _AMZProducts = GetListedProduct().Tables[0];

            if (_AMZProducts.Rows.Count > 0)
            {
                try
                {
                    _ClonePrd.Columns.Clear();
                    _ClonePrd.Rows.Clear();
                    _ClonePrd.AcceptChanges();

                    foreach (DataColumn _Column in Products.Tables[0].Columns)
                        _ClonePrd.Columns.Add(_Column.ColumnName, _Column.DataType);
                    _ClonePrd.AcceptChanges();
                    _QtyUpdate.Rows.Clear();
                    _QtyUpdate.AcceptChanges();
                    _ImageUpdate.Rows.Clear();
                    _ImageUpdate.AcceptChanges();
                    _PriceUpdate.Rows.Clear();
                    _PriceUpdate.AcceptChanges();
                    _ShippingUpdate.Rows.Clear();
                    _ShippingUpdate.AcceptChanges();
                    foreach (DataRow _Row in Products.Tables[0].Rows)
                    {

                        try
                        {
                            string Sku = _Row["SKU"].ToString();
                            int ErrorStatus = 0;
                            try
                            {
                                ErrorStatus = Convert.ToInt32(_Row["ErrorStatus"]);
                            }
                            catch { }
                            DataRow _ListedRow = (from _dr in _AMZProducts.AsEnumerable()
                                                  where _dr.Field<string>("SKU") == Sku
                                                  select _dr).FirstOrDefault();
                            if (_ListedRow != null)
                            {
                                #region Qty

                                int Inventory = 0;
                                decimal Price = 0;
                                if (ErrorStatus == 0)
                                {
                                    int.TryParse(_ListedRow["Inventory"].ToString(), out Inventory);
                                    if (string.IsNullOrEmpty(_ListedRow["Inventory"].ToString()))
                                    {
                                        DataRow _QtyRow = _QtyUpdate.NewRow();
                                        _QtyRow[0] = Convert.ToInt32(_Row["Inventory"]);
                                        _QtyRow[1] = Convert.ToDecimal(_Row["Price"]);
                                        _QtyRow[2] = 0;
                                        _QtyRow[3] = _Row["SKU"].ToString();
                                        _QtyRow[5] = Convert.ToInt32(_Row["VariantID"]);
                                        _QtyRow[6] = Convert.ToInt32(_Row["ProductID"]);
                                        int AmazonHandlingDays = 2;
                                        int.TryParse(_Row["AmazonHandlingDays"].ToString(), out AmazonHandlingDays);
                                        _QtyRow[4] = AmazonHandlingDays == 0 ? 5 : AmazonHandlingDays;
                                        _QtyUpdate.Rows.Add(_QtyRow);
                                    }
                                    else
                                    {
                                        if ((Convert.ToInt32(_Row["Inventory"]) != Inventory) || _ListedRow["Inventory"].ToString() == null)
                                        {
                                            DataRow _QtyRow = _QtyUpdate.NewRow();
                                            _QtyRow[0] = Convert.ToInt32(_Row["Inventory"]);
                                            _QtyRow[1] = Convert.ToDecimal(_Row["Price"]);
                                            _QtyRow[2] = 0;
                                            _QtyRow[3] = _Row["SKU"].ToString();
                                            _QtyRow[5] = Convert.ToInt32(_Row["VariantID"]);
                                            _QtyRow[6] = Convert.ToInt32(_Row["ProductID"]);
                                            int AmazonHandlingDays = 2;
                                            int.TryParse(_Row["AmazonHandlingDays"].ToString(), out AmazonHandlingDays);
                                            _QtyRow[4] = AmazonHandlingDays == 0 ? 5 : AmazonHandlingDays;
                                            _QtyUpdate.Rows.Add(_QtyRow);
                                        }
                                    }
                                }
                                #endregion Qty

                                #region Images
                                if (ErrorStatus == 0)
                                {
                                    if ((string.IsNullOrEmpty(_Row["Images"].ToString()) ? "" : _Row["Images"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Image URL"].ToString()) ? "" : _ListedRow["Image URL"].ToString()))
                                    {
                                        if (!string.IsNullOrEmpty(_Row["Images"].ToString()))
                                        {
                                            DataRow _ImgRow = _ImageUpdate.NewRow();
                                            string ImageXML = "<Images>";
                                            string[] Images = _Row["Images"].ToString().Split(',');
                                            for (int i = 0; i < Images.Length; i++)
                                            {
                                                if (i == 0)
                                                    ImageXML = ImageXML + "<Image><ImageType>Main</ImageType>";
                                                else
                                                    ImageXML = ImageXML + "<Image><ImageType>Other</ImageType>";
                                                ImageXML = ImageXML + "<ImageURL>" + Images[i] + "</ImageURL></Image>";
                                            }
                                            ImageXML = ImageXML + "</Images>";
                                            _ImgRow[0] = ImageXML;
                                            _ImgRow[1] = _Row["SKU"].ToString();
                                            _ImgRow[2] = Convert.ToInt32(_Row["VariantID"]);
                                            _ImgRow[3] = Convert.ToInt32(_Row["ProductID"]);
                                            _ImgRow[4] = _Row["Images"].ToString();
                                            _ImageUpdate.Rows.Add(_ImgRow);

                                        }
                                    }
                                }
                                #endregion Images

                                #region Price
                                if (ErrorStatus == 0)
                                {
                                    decimal.TryParse(_ListedRow["Price"].ToString(), out Price);
                                    if (Convert.ToDecimal(_Row["Price"]) != Price)
                                    {
                                        DataRow _PriceRow = _PriceUpdate.NewRow();
                                        _PriceRow[0] = Convert.ToDecimal(_Row["Price"]);
                                        _PriceRow[1] = 0;
                                        _PriceRow[2] = _Row["SKU"].ToString();
                                        _PriceRow[3] = Convert.ToInt32(_Row["VariantID"]);
                                        _PriceRow[4] = Convert.ToInt32(_Row["ProductID"]);
                                        _PriceUpdate.Rows.Add(_PriceRow);
                                    }
                                }
                                #endregion price

                                #region Shipping

                                decimal Shipping = 0;
                                decimal.TryParse(_Row["Shipping"].ToString(), out Shipping);
                                if (ErrorStatus == 0)
                                {
                                    if (string.IsNullOrEmpty(_ListedRow["Shipping"].ToString()))
                                    {
                                        if (Shipping != 20)
                                        {
                                            DataRow _ShipRow = _ShippingUpdate.NewRow();
                                            _ShipRow[0] = _Row["SKU"].ToString();
                                            _ShipRow[1] = Math.Round(Shipping, 2);
                                            _ShipRow[2] = Convert.ToInt32(_Row["VariantID"]);
                                            _ShipRow[3] = Convert.ToInt32(_Row["ProductID"]);
                                            _ShippingUpdate.Rows.Add(_ShipRow);

                                        }
                                    }
                                    else
                                    {
                                        decimal AppliedShipping = 0;
                                        decimal.TryParse(_ListedRow["Shipping"].ToString(), out AppliedShipping);
                                        if (Shipping != AppliedShipping)
                                        {
                                            DataRow _ShipRow = _ShippingUpdate.NewRow();
                                            _ShipRow[0] = _Row["SKU"].ToString();
                                            _ShipRow[1] = Math.Round(Shipping, 2);
                                            _ShipRow[2] = Convert.ToInt32(_Row["VariantID"]);
                                            _ShipRow[3] = Convert.ToInt32(_Row["ProductID"]);
                                            _ShippingUpdate.Rows.Add(_ShipRow);
                                        }
                                    }
                                }
                                #endregion Shipping

                                #region ProductData
                                if (ErrorStatus == 0)
                                {
                                    if (_Row["TemplateId"] != null)
                                    {
                                        if (Convert.ToInt32(_Row["TemplateId"]) != Convert.ToInt32(_Row["OldTemplateID"]))
                                        {
                                            _ClonePrd.ImportRow(_Row);
                                            continue;
                                        }

                                    }
                                    #region Descriptioncheck

                                    if ((string.IsNullOrEmpty(_Row["Description"].ToString()) ? "" : _Row["Description"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Product Description"].ToString()) ? "" : _ListedRow["Product Description"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    #endregion Descriptioncheck


                                    if ((string.IsNullOrEmpty(_Row["BulletPoint1"].ToString()) ? "" : _Row["BulletPoint1"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Bulletpoints1"].ToString()) ? "" : _ListedRow["Bulletpoints1"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    if ((string.IsNullOrEmpty(_Row["BulletPoint2"].ToString()) ? "" : _Row["BulletPoint2"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Bulletpoints2"].ToString()) ? "" : _ListedRow["Bulletpoints2"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    if ((string.IsNullOrEmpty(_Row["BulletPoint3"].ToString()) ? "" : _Row["BulletPoint3"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Bulletpoints3"].ToString()) ? "" : _ListedRow["Bulletpoints3"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    if ((string.IsNullOrEmpty(_Row["BulletPoint4"].ToString()) ? "" : _Row["BulletPoint4"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Bulletpoints4"].ToString()) ? "" : _ListedRow["Bulletpoints4"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }


                                    if ((string.IsNullOrEmpty(_Row["BulletPoint5"].ToString()) ? "" : _Row["BulletPoint5"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Bulletpoints5"].ToString()) ? "" : _ListedRow["Bulletpoints5"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }
                                    if ((string.IsNullOrEmpty(_Row["Color"].ToString()) ? "" : _Row["Color"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Color"].ToString()) ? "" : _ListedRow["Color"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }
                                    if ((string.IsNullOrEmpty(_Row["Size"].ToString()) ? "" : _Row["Size"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Size"].ToString()) ? "" : _ListedRow["Size"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }
                                    if ((string.IsNullOrEmpty(_Row["Style"].ToString()) ? "" : _Row["Style"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Style"].ToString()) ? "" : _ListedRow["Style"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    if ((string.IsNullOrEmpty(_Row["ProductName"].ToString()) ? "" : _Row["ProductName"].ToString()) != (string.IsNullOrEmpty(_ListedRow["ProductName"].ToString()) ? "" : _ListedRow["ProductName"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    if ((_Row["Weight"] == null ? 0 : Convert.ToDecimal(_Row["Weight"])) != (_ListedRow["Weight"] == null ? 0 : Convert.ToDecimal(_ListedRow["Weight"])))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }
                                    if ((string.IsNullOrEmpty(_Row["Brand"].ToString()) ? "" : _Row["Brand"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Brand"].ToString()) ? "" : _ListedRow["Brand"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }

                                    if ((string.IsNullOrEmpty(_Row["Manufacturer"].ToString()) ? "" : _Row["Manufacturer"].ToString()) != (string.IsNullOrEmpty(_ListedRow["Manufacturer"].ToString()) ? "" : _ListedRow["Manufacturer"].ToString()))
                                    {
                                        _ClonePrd.ImportRow(_Row);
                                        continue;
                                    }
                                #endregion ProductData
                                }
                            }
                        }
                        catch
                        { }
                    }

                }
                catch (Exception Exp)
                {
                    _Mail.SendMail("Issue Occured in UpdateProductLogic Function. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                }
            }
        }
        public DataSet GetListedProduct()
        {
            DataSet _DsListedProduct = new DataSet();
            try
            {
                DataTable _TableSku = new DataTable();
                DataColumn _Column = new DataColumn();
                _Column.ColumnName = "SKU";
                _Column.DataType = System.Type.GetType("System.String");
                _TableSku.Columns.Add(_Column);
                foreach (DataRow _Row in Products.Tables[0].Rows)
                {
                    DataRow _Dr = _TableSku.NewRow();
                    _Dr[0] = _Row["SKU"].ToString();
                    _TableSku.Rows.Add(_Dr);
                }
                _DsListedProduct = _DB.GetDatasetByPassDatatable("MarkHub_GetListedProduct", _TableSku, "@Table", CommandType.StoredProcedure, "");
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Getting Listed Product of amazon  from database in  GetListedProduct Function. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            return _DsListedProduct;
        }

        private void SubmitSimpleSKU(DataSet DsPrd, string StoreName, AmazonLister.OperationType OperationType, bool IsSize, string ProcName, AmazonLister.cls.Sellers Seller)
        {
            try
            {
                int NoOfFeeds = 0;
                int TotalNoOfRecords = DsPrd.Tables[0].Rows.Count;
                if (TotalNoOfRecords % MaxNewRecordInFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxNewRecordInFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxNewRecordInFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {
                    try
                    {
                        #region CheckRequestPool
                        while (CheckRequestPool(Seller.SellerID) >= RequestPool)
                        {
                            Application.DoEvents();
                            System.Threading.Thread.Sleep(100000);
                        }
                        #endregion CheckRequestPoo
                        DataSet DsFeedPrds = new DataSet();
                        DsFeedPrds.Tables.Add(DsPrd.Tables[0].AsEnumerable().Skip(i * MaxNewRecordInFile).Take(MaxNewRecordInFile).CopyToDataTable());
                        CreateMessage CreateMessage = new CreateMessage(DsFeedPrds);
                        List<AmazonLister.Message> Message = (new CreateMessage(DsFeedPrds)).GetMessage(ListMessageType.SubmitSKU, OperationType, StoreName, IsSize);
                        if (Message.Count > 0)
                        {
                            FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService(Seller).UploadProductSKU(Message));
                            //Store All Data to SQL Lite When Data Get Sucessed we will update it to Live site
                            SaveFeed(FeedSubmissionInfo, DsFeedPrds, ProcName, StoreName, IsSize, Seller.SellerID);
                        }
                    }
                    catch (Exception Exp)
                    {
                        _Mail.SendMail("Issue Occured in SubmitSimpleSKU Function. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                    }

                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void SaveFeed(FeedSubmissionInfo FeedSubmissionInfo, DataSet DsFeedPrds, string ProcName, string StoreName, bool IsSize, int SellerID)
        {
            try
            {
                string lQuery1 = string.Format("Insert into AmzFeedSubmission(FeedSubmissionID,SubmissionType,SubmissionDate, SubmissionStatus,query,SellerID) Values ({0},{1},{2},{3},{4},{5})",
                                           Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId),
                                           Helper.SingleQouts(FeedSubmissionInfo.FeedType),
                                           Helper.SingleQouts(DateTime.Now.ToString()),
                                           Helper.SingleQouts(FeedSubmissionInfo.FeedProcessingStatus),
                                            Helper.SingleQouts(ProcName + "parameters: StoreName=" + StoreName + "  size:" + IsSize), SellerID);
                _DB.ExecuteCommand(lQuery1);
                StreamWriter _Writer = new StreamWriter(Application.StartupPath + "/FeedFiles/" + SellerID + "/" + FeedSubmissionInfo.FeedSubmissionId + ".csv");
                StringBuilder sb = new StringBuilder();
                int Counter = 0;
                foreach (var col in DsFeedPrds.Tables[0].Columns)
                {
                    if (Counter + 1 == DsFeedPrds.Tables[0].Columns.Count)
                        sb.Append(col.ToString());
                    else
                        sb.Append(col.ToString() + "\t");
                    Counter++;
                }
                _Writer.WriteLine(sb);
                sb = new StringBuilder();
                foreach (DataRow row in DsFeedPrds.Tables[0].Rows)
                {

                    for (int col = 0; col < DsFeedPrds.Tables[0].Columns.Count; col++)
                    {
                        if (col + 1 == DsFeedPrds.Tables[0].Columns.Count)
                            sb.Append(row[col].ToString());
                        else
                            sb.Append(row[col].ToString() + "\t");
                    }
                    _Writer.WriteLine(sb);
                    sb = new StringBuilder();
                }
                _Writer.Close();
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("SaveFeed Function. Issue Occured in save feed response. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        private void GetFeedStatus(AmazonLister.cls.Sellers Seller)
        {
            bool FilesProcessed = false;
            while (!FilesProcessed)
            {
                Application.DoEvents();
                try
                {
                    DataTable ltbl = _DB.GetDataset(string.Format("Select * from AMZFeedSubmission Where SubmissionStatus!='Complete' and isnull(Error,0) =0  and query not like 'AmazonWebServiceDelete%' and DATEDIFF(HH, GETDATE(), SubmissionDate)<6 and sellerID=" + Seller.SellerID + "   order by feedid"), CommandType.Text, "").Tables[0];
                    if (ltbl.Rows.Count != 0)
                    {
                        UpdateStatus(ltbl, Seller);
                        FilesProcessed = false;
                    }
                    else
                        FilesProcessed = true;

                }
                catch (Exception Exp)
                {
                    _Mail.SendMail("FeedSubmissionProcess Function.Issue Occured in getting Feeds from database. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
                    FilesProcessed = false;
                }
            }
        }
        private void UpdateStatus(DataTable ltbl, AmazonLister.cls.Sellers Seller)
        {
            try
            {
                foreach (DataRow dr in ltbl.Rows)
                {
                    if (File.Exists(Helper.ZGetSubmitFeedName) == true)
                    {
                        System.IO.File.Delete(Helper.ZGetSubmitFeedName);
                    }
                    ProcessingReport ProcessingReport = new ProcessingReport();
                    List<AmazonLister.Message> Messages = (new AmazonWebService(Seller).CheckFeedStatus(dr["FeedSubmissionID"].ToString(), Helper.ZGetSubmitFeedName));
                    if (Messages.Count() > 0)
                    {
                        ProcessingReport = Messages[0].ProcessingReport;
                        if (ProcessingReport.ProcessingSummary.MessagesWithError > 0 && ProcessingReport.ProcessingSummary.MessagesSuccessful == 0)
                        {
                            try
                            {
                                String Query = string.Format("Update AMZFeedSubmission SET SubmissionStatus ='Error',Error=1 Where sellerID=" + Seller.SellerID + " and FeedSubmissionID ={0}", Helper.SingleQouts(dr["FeedSubmissionID"].ToString()));
                                _DB.ExecuteCommand(Query);
                                _Mail.SendMail("UpdateStatus Function.Issue Occured in Feed Submission  for feedsubmissionID = " + dr["FeedSubmissionID"].ToString() + " at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);

                            }
                            catch (Exception Exp)
                            {
                                _Mail.SendMail("UpdateStatus Function.Issue Occured in update status of feed in database. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                            }
                        }
                        else
                        {


                            try
                            {
                                String Query = string.Format("Update AMZFeedSubmission SET  SubmissionStatus ={0} Where sellerID=" + Seller.SellerID + " and FeedSubmissionID ={1}", Helper.SingleQouts(ProcessingReport.StatusCode), Helper.SingleQouts(dr["FeedSubmissionID"].ToString()));
                                _DB.ExecuteCommand(Query);
                            }
                            catch (Exception Exp)
                            {
                                _Mail.SendMail("UpdateStatus Function.Issue Occured in update status of feed in database. Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
                            }

                        }
                        #region DataBaseUpdate
                        DbSync(dr["Query"].ToString(), dr["FeedSubmissionID"].ToString(), dr["SubmissionType"].ToString(), Messages, Seller.SellerID);
                        #endregion DataBaseUpdate
                    }
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(60000);
                    //*********Sleep code for 1 minute****************/
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DbSync(string ProcType, string FeedID, string FeedType, List<AmazonLister.Message> Response, int sellerID)
        {
            string StoredProcedureName = "";
            int Type = 0;
            DataTable _Table = new DataTable();
            try
            {
                if (!Directory.Exists(Application.StartupPath + "/FeedFiles/" + sellerID))
                    Directory.CreateDirectory(Application.StartupPath + "/FeedFiles/" + sellerID);
                string[] csvRows = System.IO.File.ReadAllLines(Application.StartupPath + "/FeedFiles/" + sellerID + "/" + FeedID + ".csv");
                string[] fields = null;
                for (int i = 0; i < csvRows.Count(); i++)
                {

                    try
                    {
                        fields = csvRows[i].Split(new string[] { "\t" }, StringSplitOptions.None);
                        if (i == 0)
                        {
                            for (int j = 0; j < fields.Count(); j++)
                            {
                                _Table.Columns.Add(fields[j]);
                            }
                        }
                        else
                        {
                            DataRow row = _Table.NewRow();
                            row.ItemArray = fields;
                            _Table.Rows.Add(row);
                        }

                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception Exp)
            {
                _Table.Rows.Clear();
                _Mail.SendMail("DbSync Function.Issue Occured in Read Feed File having id " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            try
            {
                if (_Table.Rows.Count > 0)
                {
                    DataTable _TableSku = new DataTable();
                    DataTable exceldt = new DataTable();
                    _TableSku.Columns.Add("SKU", System.Type.GetType("System.String"));
                    _TableSku.Columns.Add("Price", System.Type.GetType("System.Decimal"));
                    _TableSku.Columns.Add("Shipping", System.Type.GetType("System.Decimal"));
                    _TableSku.Columns.Add("Inventory", System.Type.GetType("System.Int32"));
                    _TableSku.Columns.Add("Images", System.Type.GetType("System.String"));
                    _TableSku.Columns.Add("VariantID", System.Type.GetType("System.Int32"));
                    _TableSku.Columns.Add("ProductID", System.Type.GetType("System.Int32"));
                    if (FeedType == "_POST_PRODUCT_PRICING_DATA_")
                    {
                        foreach (DataRow _Row in _Table.Rows)
                        {
                            DataRow Row = _TableSku.NewRow();
                            Row[0] = _Row["SKU"].ToString();
                            Row[1] = _Row["Price"].ToString();
                            Row[5] = Convert.ToInt32(_Row["VariantID"]);
                            Row[6] = Convert.ToInt32(_Row["ProductID"]);
                            _TableSku.Rows.Add(Row);
                        }
                        StoredProcedureName = "MarkHub_UpdateAmazonPriceInfo";
                        Type = 1;
                    }
                    else if (FeedType == "_POST_INVENTORY_AVAILABILITY_DATA_")
                    {
                        foreach (DataRow _Row in _Table.Rows)
                        {
                            DataRow Row = _TableSku.NewRow();
                            Row[0] = _Row["SKU"].ToString();
                            Row[3] = _Row["Inventory"].ToString();
                            Row[5] = Convert.ToInt32(_Row["VariantID"]);
                            Row[6] = Convert.ToInt32(_Row["ProductID"]);
                            _TableSku.Rows.Add(Row);
                        }
                        StoredProcedureName = "MarkHub_UpdateAmazonPriceInfo";
                        Type = 3;
                    }
                    else if (FeedType == "_POST_PRODUCT_IMAGE_DATA_")
                    {
                        foreach (DataRow _Row in _Table.Rows)
                        {
                            DataRow Row = _TableSku.NewRow();
                            Row[0] = _Row["SKU"].ToString();
                            Row[4] = _Row["Image url"].ToString();
                            Row[5] = Convert.ToInt32(_Row["VariantID"]);
                            Row[6] = Convert.ToInt32(_Row["ProductID"]);
                            _TableSku.Rows.Add(Row);
                        }
                        StoredProcedureName = "MarkHub_UpdateAmazonPriceInfo";
                        Type = 4;
                    }
                    else if (FeedType == "_POST_PRODUCT_OVERRIDES_DATA_")
                    {

                        foreach (DataRow _Row in _Table.Rows)
                        {
                            DataRow Row = _TableSku.NewRow();
                            Row[0] = _Row["SKU"].ToString();
                            Row[2] = _Row["Shipping"].ToString();
                            Row[5] = Convert.ToInt32(_Row["VariantID"]);
                            Row[6] = Convert.ToInt32(_Row["ProductID"]);
                            _TableSku.Rows.Add(Row);
                        }
                        StoredProcedureName = "MarkHub_UpdateAmazonPriceInfo";
                        Type = 2;
                    }
                    else
                    {
                        exceldt.Columns.Add("Rowid", typeof(int));
                        exceldt.Columns.Add("SKU", typeof(string));
                        exceldt.Columns.Add("Product Name", typeof(string));
                        exceldt.Columns.Add("Product Description", typeof(string));
                        exceldt.Columns.Add("Bullet Points", typeof(string));
                        exceldt.Columns.Add("Manufacturer", typeof(string));
                        exceldt.Columns.Add("Brand Name", typeof(string));
                        exceldt.Columns.Add("Price", typeof(decimal));
                        exceldt.Columns.Add("Currency", typeof(string));
                        exceldt.Columns.Add("In Stock", typeof(string));
                        exceldt.Columns.Add("Image URL", typeof(string));
                        exceldt.Columns.Add("URL", typeof(string));
                        exceldt.Columns.Add("Size", typeof(string));
                        exceldt.Columns.Add("Color", typeof(string));
                        exceldt.Columns.Add("Isdefault", typeof(bool));
                        exceldt.Columns.Add("ParentSku", typeof(string));
                        exceldt.Columns.Add("Bulletpoints1", typeof(string));
                        exceldt.Columns.Add("Bulletpoints2", typeof(string));
                        exceldt.Columns.Add("Bulletpoints3", typeof(string));
                        exceldt.Columns.Add("Bulletpoints4", typeof(string));
                        exceldt.Columns.Add("Bulletpoints5", typeof(string));
                        exceldt.Columns.Add("Category", typeof(string));
                        exceldt.Columns.Add("Weight", typeof(string));
                        exceldt.Columns.Add("Style", typeof(string));
                        exceldt.Columns.Add("Shipping", typeof(string));
                        exceldt.Columns.Add("Minimum_Manufacturer_Age_Recommended", typeof(int));
                        exceldt.Columns.Add("AGE_Unit_Of_Measure", typeof(string));
                        exceldt.Columns.Add("UPC", typeof(string));
                        exceldt.Columns.Add("ParentUPC", typeof(string));
                        exceldt.Columns.Add("ParentProductName", typeof(string));
                        exceldt.Columns.Add("ISParent", typeof(int));
                        exceldt.Columns.Add("Product Product Description", typeof(string));
                        exceldt.Columns.Add("VariantID", typeof(int));
                        exceldt.Columns.Add("ProductID", typeof(int));
                        exceldt.Columns.Add("TemplateId", typeof(int));
                        int i = 0;
                        foreach (DataRow _Tbrow in _Table.Rows)
                        {
                            DataRow _Row = exceldt.NewRow();
                            _Row[0] = i;
                            _Row[1] = _Tbrow["SKU"];
                            _Row[2] = _Tbrow["ProductName"];
                            _Row[3] = _Tbrow["Description"];
                            _Row[4] = "";
                            _Row[5] = _Tbrow["Manufacturer"];
                            _Row[6] = _Tbrow["Brand"];
                            _Row[7] = _Tbrow["Price"];
                            _Row[8] = "";
                            _Row[9] = _Tbrow["Inventory"];
                            _Row[10] = _Tbrow["Images"];
                            _Row[11] = "";
                            _Row[12] = _Tbrow["Size"];
                            _Row[13] = _Tbrow["Color"];
                            _Row[14] = 0;
                            _Row[15] = _Tbrow["ParentSku"];
                            _Row[16] = _Tbrow["BulletPoint1"];
                            _Row[17] = _Tbrow["BulletPoint2"];
                            _Row[18] = _Tbrow["BulletPoint3"];
                            _Row[19] = _Tbrow["BulletPoint4"];
                            _Row[20] = _Tbrow["BulletPoint5"];
                            _Row[21] = "";
                            _Row[22] = _Tbrow["Weight"];
                            _Row[23] = _Tbrow["Style"];
                            _Row[24] = _Tbrow["Shipping"];
                            _Row[25] = _Tbrow["MinimumAgeRecommend"];
                            _Row[26] = _Tbrow["AgeUnitOfMeasure"];
                            _Row[27] = _Tbrow["UPC"];
                            _Row[28] = _Tbrow["ParentUPC"];
                            _Row[29] = _Tbrow["ParentProductName"];
                            _Row[30] = _Tbrow["ISParent"];
                            _Row[31] = _Tbrow["ParentProductDescription"];
                            _Row[32] = _Tbrow["VariantID"];
                            _Row[33] = _Tbrow["ProductID"];
                            _Row[34] = _Tbrow["TemplateId"];
                            exceldt.Rows.Add(_Row);
                            i++;
                        }
                        #region DeleteProduct
                        if (ProcType.Contains("AmazonWebServiceDeleteProducts"))
                        {
                            StoredProcedureName = "MarkHub_ManageListedproduct_Proc";
                            Type = 3;
                        }
                        #endregion DeleteProduct

                        #region UpdateProduct
                        if (ProcType.Contains("AmazonWebServiceUpdateProducts"))
                        {
                            StoredProcedureName = "MarkHub_ManageListedproduct_Proc";
                            Type = 2;
                        }
                        #endregion UpdateProduct

                        #region NewProduct
                        if (ProcType.Contains("AmazonWebServiceNewProducts"))
                        {
                            StoredProcedureName = "MarkHub_ManageListedproduct_Proc";
                            Type = 1;
                        }
                        #endregion NewProduct
                    }
                    #region Relation
                    #endregion Relation
                    #region ProcessFeedToDatabase
                    if (StoredProcedureName == "MarkHub_ManageListedproduct_Proc")
                        ProcessFeedToDatabase(StoredProcedureName, Type, Response, exceldt, FeedID);
                    else

                        ProcessFeedToDatabase(StoredProcedureName, Type, Response, _TableSku, FeedID);
                    #endregion ProcessFeedToDatabase
                }
            }
            catch (Exception Exp)
            {
                _Table.Rows.Clear();
                _Mail.SendMail("DbSync Function.Issue Occured in Generating datatables in order to sync to database for feed having ID is " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }
        public void ProcessFeedToDatabase(string StoredProcedure, int type, List<AmazonLister.Message> response, DataTable table, string FeedID)
        {
            try
            {
                #region ReadResponseOfFeed
                int noOfProductProcessed = 0;
                DataTable tableError = new DataTable();
                tableError.Columns.Add("SKU", typeof(string));
                tableError.Columns.Add("Error", typeof(string));
                tableError.Columns.Add("VariantID", typeof(Int32));
                tableError.Columns.Add("ProductID", typeof(Int32));
                List<string> errorSku = new List<string>();
                foreach (AmazonLister.Message Message in response)
                {
                    if (noOfProductProcessed == 0)
                        noOfProductProcessed = Message.ProcessingReport.ProcessingSummary.MessagesSuccessful;
                    foreach (Result Error in Message.ProcessingReport.Result)
                    {
                        if (Error.AdditionalInfo != null)
                        {
                            try
                            {
                                DataRow row = tableError.NewRow();
                                row[0] = Error.AdditionalInfo.SKU;
                                row[1] = Error.ResultDescription.Trim().Length > 8000 ? Error.ResultDescription.Trim().Substring(0, 7990) + "..." : Error.ResultDescription.Trim();
                                DataTable filterTable = (from _Record in table.AsEnumerable()
                                                         where _Record.Field<string>("SKU") == Error.AdditionalInfo.SKU
                                                         select _Record).CopyToDataTable();
                                row[2] = Convert.ToInt32(filterTable.Rows[0]["VariantID"]);
                                row[3] = Convert.ToInt32(filterTable.Rows[0]["ProductID"]);
                                tableError.Rows.Add(row);
                                if (!errorSku.Contains(Error.AdditionalInfo.SKU))
                                    errorSku.Add(Error.AdditionalInfo.SKU);
                                table.AcceptChanges();
                            }
                            catch { }
                        }
                    }
                }

                #region codeToDeleteRow
                foreach (string sku in errorSku)
                {
                    var results = (from _Record in table.AsEnumerable()
                                   where _Record.Field<string>("SKU") == sku
                                   select _Record).ToList();
                    results.ForEach(r => table.Rows.Remove(r));
                }
                #endregion codeToDeleteRow
                #endregion ReadResponseOfFeed

                #region InsertErrorInDatabase
                if (tableError.Rows.Count > 0)
                {
                    int noOfParts = 0;
                    int TotalNoOfRecords = tableError.Rows.Count;
                    if (TotalNoOfRecords % 2000 == 0)
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000);
                    else
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000) + 1;
                    for (int i = 0; i < noOfParts; i++)
                    {
                        _DB.GetDatasetByPassDatatable("MarkHub_ListingError", tableError.AsEnumerable().Skip(i * 2000).Take(2000).CopyToDataTable(), "@Table", CommandType.StoredProcedure, "@FeedID," + FeedID);
                    }
                }
                #endregion InsertErrorInDatabase

                #region SyncProductsToDatabase
                if (noOfProductProcessed > 0 && table.Rows.Count > 0)
                {
                    int noOfParts = 0;
                    int TotalNoOfRecords = table.Rows.Count;
                    if (TotalNoOfRecords % 2000 == 0)
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000);
                    else
                        noOfParts = Convert.ToInt32(TotalNoOfRecords / 2000) + 1;
                    for (int i = 0; i < noOfParts; i++)
                    {
                        _DB.GetDatasetByPassDatatable(StoredProcedure, table.AsEnumerable().Skip(i * 2000).Take(2000).CopyToDataTable(), "@Products", CommandType.StoredProcedure, "@Type," + type);
                    }
                }
                #endregion SyncProductsToDatabase
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured ProcessFeedToDatabase Function for feed having ID is " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Amazon Web service APP.", false, false, 1);
            }
        }

        private void SubmitPrice(DataTable _Table, OperationType _Type, string StoreName, bool _IsSize, string ProcName, AmazonLister.cls.Sellers Seller)
        {
            try
            {

                ds = new DataSet();
                ds.Tables.Add(_Table);
                int NoOfFeeds = 0;
                int TotalNoOfRecords = ds.Tables[0].Rows.Count;
                if (TotalNoOfRecords % MaxRecordInFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {
                    #region CheckRequestPool
                    while (CheckRequestPool(Seller.SellerID) >= RequestPool)
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(100000);
                    }
                    #endregion CheckRequestPool
                    DataSet DsFeedPrds = new DataSet();
                    DsFeedPrds.Tables.Add(ds.Tables[0].AsEnumerable().Skip(i * MaxRecordInFile).Take(MaxRecordInFile).CopyToDataTable());
                    CreateMessage CreateMessage = new CreateMessage(DsFeedPrds);
                    List<AmazonLister.Message> Message = (new CreateMessage(DsFeedPrds)).GetMessage(ListMessageType.SubmitPrice, _Type, StoreName, _IsSize);
                    if (Message.Count > 0)
                    {
                        FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService(Seller).UploadPrice(Message));
                        SaveFeed(FeedSubmissionInfo, DsFeedPrds, ProcName, StoreName, _IsSize, Seller.SellerID);
                    }
                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in SubmitPrice Function. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            ds.Tables.Clear();
            ds.AcceptChanges();
        }
        private void SubmitInventory(DataTable _Table, OperationType _Type, string StoreName, bool _IsSize, string ProcName, AmazonLister.cls.Sellers Seller)
        {
            try
            {

                ds = new DataSet();
                ds.Tables.Add(_Table);
                int NoOfFeeds = 0;
                int TotalNoOfRecords = ds.Tables[0].Rows.Count;
                if (TotalNoOfRecords % MaxRecordInFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {
                    #region CheckRequestPool
                    while (CheckRequestPool(Seller.SellerID) >= RequestPool)
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(100000);
                    }
                    #endregion CheckRequestPool
                    DataSet DsFeedPrds = new DataSet();
                    DsFeedPrds.Tables.Add(ds.Tables[0].AsEnumerable().Skip(i * MaxRecordInFile).Take(MaxRecordInFile).CopyToDataTable());
                    CreateMessage CreateMessage = new CreateMessage(DsFeedPrds);
                    List<AmazonLister.Message> Message = (new CreateMessage(DsFeedPrds)).GetMessage(ListMessageType.SubmitQuantuty, _Type, StoreName, _IsSize);
                    if (Message.Count > 0)
                    {
                        FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService(Seller).UploadInventory(Message));
                        SaveFeed(FeedSubmissionInfo, DsFeedPrds, ProcName, StoreName, _IsSize, Seller.SellerID);
                    }
                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in SubmitInventory Function. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            ds.Tables.Clear();
            ds.AcceptChanges();
        }
        private void SubmitImages(DataTable _Table, OperationType _Type, string StoreName, bool _IsSize, string ProcName, AmazonLister.cls.Sellers Seller)
        {
            try
            {

                ds = new DataSet();
                ds.Tables.Add(_Table);
                int NoOfFeeds = 0;
                int TotalNoOfRecords = ds.Tables[0].Rows.Count;
                if (TotalNoOfRecords % MaxRecordInFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {
                    #region CheckRequestPool
                    while (CheckRequestPool(Seller.SellerID) >= RequestPool)
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(100000);
                    }
                    #endregion CheckRequestPool
                    DataSet DsFeedPrds = new DataSet();
                    DsFeedPrds.Tables.Add(ds.Tables[0].AsEnumerable().Skip(i * MaxRecordInFile).Take(MaxRecordInFile).CopyToDataTable());
                    CreateMessage CreateMessage = new CreateMessage(DsFeedPrds);
                    List<AmazonLister.Message> Message = (new CreateMessage(DsFeedPrds)).GetMessage(ListMessageType.SubmitImages, _Type, StoreName, _IsSize);
                    if (Message.Count > 0)
                    {
                        FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService(Seller).UploadImages(Message));
                        SaveFeed(FeedSubmissionInfo, DsFeedPrds, ProcName, StoreName, _IsSize, Seller.SellerID);
                    }
                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in SubmitImages Function. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            ds.Tables.Clear();
            ds.AcceptChanges();
        }
        private void SubmitShipping(DataTable _Table, OperationType _Type, string StoreName, bool _IsSize, string ProcName, AmazonLister.cls.Sellers Seller)
        {
            try
            {

                ds = new DataSet();
                ds.Tables.Add(_Table);
                int NoOfFeeds = 0;
                int TotalNoOfRecords = ds.Tables[0].Rows.Count;
                if (TotalNoOfRecords % MaxRecordInFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordInFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {
                    #region CheckRequestPool
                    while (CheckRequestPool(Seller.SellerID) >= RequestPool)
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(100000);
                    }
                    #endregion CheckRequestPool
                    DataSet DsFeedPrds = new DataSet();
                    DsFeedPrds.Tables.Add(ds.Tables[0].AsEnumerable().Skip(i * MaxRecordInFile).Take(MaxRecordInFile).CopyToDataTable());
                    CreateMessage CreateMessage = new CreateMessage(DsFeedPrds);
                    List<AmazonLister.Message> Message = (new CreateMessage(DsFeedPrds)).GetMessage(ListMessageType.SubmitShipping, _Type, StoreName, _IsSize);
                    if (Message.Count > 0)
                    {
                        FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService(Seller).UploadShipping(Message));
                        SaveFeed(FeedSubmissionInfo, DsFeedPrds, ProcName, StoreName, _IsSize, Seller.SellerID);
                    }
                }
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Submitshipping Function. Exception: " + Exp.Message + " at " + DateTime.Now.ToString(), "Urgent issue in Amazon Web service APP.", false, false, 1);
            }
            ds.Tables.Clear();
            ds.AcceptChanges();
        }

        /// <summary>
        /// ////////////////////////////////////////////
        /// </summary>
        //        private void SubmitVariationSKU()
        //        {
        //            try
        //            {
        //                ds = new DataSet();
        //                ds = Helper.GetDS(@"Select top 10 AMZPV.AzmVariantId,
        //                                                  AMZPV.AmzProductId,
        //                                                  AMZP.Manufacturer Manufacturer,
        //                                                  AmzP.Brand,
        //                                                  'horse-halters' as ItemType,
        //                                                  AMZPV.Name,
        //                                                  ISNULL(NULLIF(AMZPV.SKU,''),AMZPV.AmzSKU) as SKU,
        //                                                  AMZPV.Price,
        //                                                  AMZPV.SalePrice,
        //                                                  ISNULL(AMZP.Description,AMZPV.Description) Description,
        //                                                  ISNULL(AMZP.Keywords,AMZPV.Keywords) Keyword 
        //                                                  from AMZProductVariant AMZPV Join  AMZProduct AMZP   On AMZPV.AmzProductId =AMZP.AmzProductId 
        //                                                  Left Join (Select RefProductId from AmzKitGroup Where IsActive=1 and (IsColor=1 or IsSize=1) Group By RefProductId) Variantion
        //                                                  On Variantion.RefProductId=AMZP.AmzProductId
        //                                                  Where AMZPV.IsActive=1 and AMZPV.IsListed=1 and ISNULL(Variantion.RefProductId,0)!=0 ");
        //                dgv.DataSource = ds.Tables["row"];
        //                ds.Tables[2].TableName = "UploadSKU";
        //                ds.AcceptChanges();

        //                CreateMessage CreateMessage = new CreateMessage(ds);
        //                List<AmazonLister.Message> Message = (new CreateMessage(ds)).GetMessage(ListMessageType.SubmitSKU, OperationType.Update, "", true);
        //                FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService().UploadProductSKU(Message));



        //                //Store All Data to SQL Lite When Data Get Sucessed we will update it to Live site
        //                string lQuery1 = string.Format("Insert into AmzFeedSubmission(FeedSubmissionID,SubmissionType,SubmissionDate, SubmissionStatus) Values ({0},{1},{2},{3})",
        //                                 Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId),
        //                                 Helper.SingleQouts(FeedSubmissionInfo.FeedType),
        //                                 Helper.SingleQouts(DateTime.Now.ToString()),
        //                                 Helper.SingleQouts(FeedSubmissionInfo.FeedProcessingStatus));

        //                string variant = string.Join(",", ((from lt in ds.Tables[2].AsEnumerable()
        //                                                    select new { variantId = lt.Field<string>("AzmVariantId").ToString() }).ToArray()).Select(q => q.variantId));

        //                string lQuery2 = String.Format(@" Insert into AmzFeedSubmissionDetails(FeedSubmissionID,AzmVariantId,AmzProductId,Name,SKU,Price,SalePrice,INV) 
        //                                                      Select {0},
        //                                                             AMZPV.AzmVariantId,
        //                                                             AMZPV.AmzProductId,
        //                                                             AMZPV.Name,
        //                                                             ISNULL(NULLIF(AMZPV.SKU,''),AMZPV.AmzSKU) as SKU,
        //                                                             AMZPV.Price,
        //                                                             AMZPV.SalePrice,
        //                                                             1
        //                                                             from AMZProductVariant AMZPV Join  AMZProduct AMZP 
        //                                                             On AMZPV.AmzProductId =AMZP.AmzProductId and AMZPV.IsActive=1 Where AMZPV.AzmVariantId in ({1})", Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId), (variant));


        //                lQuery2 = string.Format("Insert into SQLQueries(FeedSubmissionID,Query1,Query2) Values ({0},{1},{2})",
        //                                Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId),
        //                                Helper.SingleQouts(lQuery1),
        //                                Helper.SingleQouts(lQuery2));



        //                SQL.ExcuteCmd(lQuery1);
        //                SQL.ExcuteCmd(lQuery2);
        //            }
        //            catch (Exception ex)
        //            {
        //                throw new Exception(ex.Message);
        //            }

        //        }
        //        private void SubmitParentVariationSKU()
        //        {
        //            try
        //            {
        //                ds = new DataSet();
        //                ds = Helper.GetDS(@"Select top 10 AMZPV.AzmVariantId,
        //                                                  AMZPV.AmzProductId,
        //                                                  AMZP.Manufacturer Manufacturer,
        //                                                  AmzP.Brand,
        //                                                  'horse-halters' as ItemType,
        //                                                  AMZPV.Name,
        //                                                  ISNULL(NULLIF(AMZPV.SKU,''),AMZPV.AmzSKU) as SKU,
        //                                                  AMZPV.Price,
        //                                                  AMZPV.SalePrice,
        //                                                  ISNULL(AMZP.Description,AMZPV.Description) Description,
        //                                                  ISNULL(AMZP.Keywords,AMZPV.Keywords) Keyword 
        //                                                  from AMZProductVariant AMZPV Join  AMZProduct AMZP   On AMZPV.AmzProductId =AMZP.AmzProductId 
        //                                                  Left Join (Select RefProductId from AmzKitGroup Where IsActive=1 and (IsColor=1 or IsSize=1) Group By RefProductId) Variantion
        //                                                  On Variantion.RefProductId=AMZP.AmzProductId
        //                                                  Where AMZPV.IsActive=1 and AMZPV.IsListed=1 and ISNULL(Variantion.RefProductId,0)!=0 ");
        //                dgv.DataSource = ds.Tables["row"];
        //                ds.Tables[2].TableName = "UploadSKU";
        //                ds.AcceptChanges();

        //                CreateMessage CreateMessage = new CreateMessage(ds);
        //                List<AmazonLister.Message> Message = (new CreateMessage(ds)).GetMessage(ListMessageType.SubmitSKU, OperationType.Update, "", true);
        //                FeedSubmissionInfo FeedSubmissionInfo = (new AmazonWebService().UploadProductSKU(Message));



        //                //Store All Data to SQL Lite When Data Get Sucessed we will update it to Live site
        //                string lQuery1 = string.Format("Insert into AmzFeedSubmission(FeedSubmissionID,SubmissionType,SubmissionDate, SubmissionStatus) Values ({0},{1},{2},{3})",
        //                                 Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId),
        //                                 Helper.SingleQouts(FeedSubmissionInfo.FeedType),
        //                                 Helper.SingleQouts(DateTime.Now.ToString()),
        //                                 Helper.SingleQouts(FeedSubmissionInfo.FeedProcessingStatus));

        //                string variant = string.Join(",", ((from lt in ds.Tables[2].AsEnumerable()
        //                                                    select new { variantId = lt.Field<string>("AzmVariantId").ToString() }).ToArray()).Select(q => q.variantId));

        //                string lQuery2 = String.Format(@" Insert into AmzFeedSubmissionDetails(FeedSubmissionID,AzmVariantId,AmzProductId,Name,SKU,Price,SalePrice,INV) 
        //                                                      Select {0},
        //                                                             AMZPV.AzmVariantId,
        //                                                             AMZPV.AmzProductId,
        //                                                             AMZPV.Name,
        //                                                             ISNULL(NULLIF(AMZPV.SKU,''),AMZPV.AmzSKU) as SKU,
        //                                                             AMZPV.Price,
        //                                                             AMZPV.SalePrice,
        //                                                             1
        //                                                             from AMZProductVariant AMZPV Join  AMZProduct AMZP 
        //                                                             On AMZPV.AmzProductId =AMZP.AmzProductId and AMZPV.IsActive=1 Where AMZPV.AzmVariantId in ({1})", Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId), (variant));


        //                lQuery2 = string.Format("Insert into SQLQueries(FeedSubmissionID,Query1,Query2) Values ({0},{1},{2})",
        //                                Helper.SingleQouts(FeedSubmissionInfo.FeedSubmissionId),
        //                                Helper.SingleQouts(lQuery1),
        //                                Helper.SingleQouts(lQuery2));



        //                SQL.ExcuteCmd(lQuery1);
        //                SQL.ExcuteCmd(lQuery2);
        //            }
        //            catch (Exception ex)
        //            {
        //                throw new Exception(ex.Message);
        //            }

        //        }
        private void btnStartUploading_Click(object sender, EventArgs e)
        {

        }
        private void AmazonListOrderApiCall()
        {

            string txtResults = string.Empty;
            try
            {
                //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(req());
                //request.KeepAlive = false;
                //request.AllowAutoRedirect = true;
                //request.Method = "Post";
                //request.ContentType = "text/xml";
                //WebResponse response = null;
                //response = request.GetResponse();
                //var reader = new StreamReader(response.GetResponseStream());
                //var str = reader.ReadToEnd();
            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    HttpWebResponse err = ex.Response as HttpWebResponse;
                    if (err != null)
                    {
                        string htmlResponse = new StreamReader(err.GetResponseStream()).ReadToEnd();
                        txtResults = string.Format("{0} {1}", err.StatusDescription, htmlResponse);
                    }
                }
                else
                {
                    txtResults = ex.ToString();
                }
            }
            catch (Exception ex)
            {
                txtResults = ex.ToString();
            }
            //Response.Write(txtResults);
            MessageBox.Show(txtResults);
        }
        private void btnListSKU_Click(object sender, EventArgs e)
        {

        }

        //public void test()
        //{
        //    try
        //    {

        //        this.AmazonListOrderApiCall();

        //        Service._ZUserName = "maansingh@medfosys.com";
        //        Service._ZService.Url = "http://twohorsetack.aspdotnetstorefront.shoppingmegamart.com/IPX.asmx";
        //        Service._ZPassword = "Matrid1$$";
        //        if (Login() == true)
        //        {
        //            if (LocalProcessing() == true)
        //            {
        //                SQL = new SQLLiteHelper();
        //                DataTable ltbl = SQL.GetDatable("Select * from AMZFeedSubmission Where Error = 0 order By SubmissionDate DESC LIMIT 1 ");
        //                if (ltbl.Rows.Count != 0)
        //                {
        //                    switch (ltbl.Rows[0]["SubmissionType"].ToString().ToUpper())
        //                    {
        //                        case "_POST_PRODUCT_DATA_":
        //                            SubmitPrice(ltbl.Rows[0]["FeedSubmissionID"].ToString());
        //                            break;
        //                        case "_POST_PRODUCT_PRICING_DATA_":
        //                            SubmitInventory(ltbl.Rows[0]["RootFeedId"].ToString());
        //                            break;
        //                        case "_POST_INVENTORY_AVAILABILITY_DATA_":
        //                            SubmitImages(ltbl.Rows[0]["RootFeedId"].ToString());
        //                            break;
        //                        case "_POST_PRODUCT_IMAGE_DATA_":
        //                            this.SubmitSKU();
        //                            break;
        //                        default:
        //                            break;
        //                    }
        //                }
        //                else
        //                {
        //                    this.SubmitSKU();

        //                }
        //            }
        //        }


        //    }


        //    catch (Exception ex)
        //    {
        //        Helper.LockError(ex.Message);
        //    }
        //}
    }
    public class AMAZONTemplate
    {

        public string AmazontemplateName { get; set; }
        public bool Processed { get { return false; } set { value = false; } }
    }
    public class Procedures
    {
        public bool SizeParameter { get; set; }
        public string ProcedureName { get; set; }
        public AmazonLister.OperationType _Type { get; set; }
    }
    public class AmzFeedSubmission
    {
        public int FeedID { get; set; }
        public string FeedSubmissionID { get; set; }
    }
    public class MathEvaluator : Microsoft.JScript.INeedEngine
    {
        private VsaEngine vsaEngine;

        public virtual String Evaluate(string expr)
        {
            var engine = (Microsoft.JScript.INeedEngine)this;
            var result = Microsoft.JScript.Eval.JScriptEvaluate(expr, engine.GetEngine());

            return Microsoft.JScript.Convert.ToString(result, true);
        }

        VsaEngine Microsoft.JScript.INeedEngine.GetEngine()
        {
            vsaEngine = vsaEngine ?? VsaEngine.CreateEngineWithType(this.GetType().TypeHandle);
            return vsaEngine;
        }

        void Microsoft.JScript.INeedEngine.SetEngine(VsaEngine engine)
        {
            vsaEngine = engine;
        }
    }
    public class Store
    {
        public int StoreID { get; set; }
        public string Name { get; set; }
    }
    public class Category
    {
        public int CategoryID { get; set; }
        public string Name { get; set; }
    }
}

