﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Configuration;


namespace AmazonWinApp
{
  

    public  class Service
    {
        public static string _ZUserName { get; set; }
        public static string _ZPassword { get; set; }
        public static string _ZURL { get; set; }
        public static string _ZConfigId { get; set; }
        public static IPX.AspDotNetStorefrontImportWebService _ZService = new IPX.AspDotNetStorefrontImportWebService();    
        public static  int validateuser(string email, string passsword)
        {
            try
            {
                CustomerOB validatecustomer = new CustomerOB();
                XmlDocument xmlResult = new XmlDocument();
               
                string fetch = "  <AspDotNetStorefrontImport Version=\"9.3.1.0\" > " +
                               "  <GetCustomer EMail=\"" + email + "\"/>" +
                               "  </AspDotNetStorefrontImport>";

                string Result = _ZService.DoItUsernamePwd(email, passsword, fetch);

                xmlResult.LoadXml(Result);

                if (xmlResult != null)
                {
                    XmlNodeList ImportResult = xmlResult.SelectNodes("AspDotNetStorefrontImportResult");

                    XmlNodeList GetEntity;
                    XmlNodeList Entity;
                    foreach (XmlNode GP in ImportResult)//GP frand parent node
                    {
                        GetEntity = GP.SelectNodes("Get");

                        foreach (XmlNode PN in GetEntity)//pn as parent node
                        {
                            Entity = PN.SelectNodes("Customer");

                            foreach (XmlNode CN in Entity)
                            {

                                validatecustomer.Email = CN.SelectSingleNode("EMail").InnerText;
                                validatecustomer.Password = CN.SelectSingleNode("Password").InnerText;
                                validatecustomer.SaltKey = Convert.ToInt32(CN.SelectSingleNode("SaltKey").InnerText.ToString());
                                validatecustomer.FirstName = CN.SelectSingleNode("FirstName").InnerText;
                                validatecustomer.IsAdmin = Convert.ToInt32(CN.SelectSingleNode("IsAdmin").InnerText);
                                validatecustomer.Deleted = Convert.ToInt32(CN.SelectSingleNode("Deleted").InnerText);
                            }

                        }

                    }

                    string encryptedpws = Convert.ToBase64String(Encoding.UTF8.GetBytes(AspDotNetStorefrontEncrypt.Encrypt.ComputeSaltedHash(validatecustomer.SaltKey, passsword)));
                    // string pwd = Convert.ToBase64String(Encoding.UTF8.GetBytes(validatecustomer.Password));
                    if (validatecustomer.Email == email && encryptedpws == validatecustomer.Password && validatecustomer.IsAdmin == 3 && validatecustomer.Deleted == 0)
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }


    public class CustomerOB
    {
        public int CustomerID { get; set; }
        public string CustomerGUID { get; set; }
        public int CustomerLevelID { get; set; }
        public DateTime RegisterDate { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int SaltKey { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Notes { get; set; }
        public int SkinID { get; set; }
        public string Phone { get; set; }
        public string FAX { get; set; }
        public int AffiliateID { get; set; }
        public string Referrer { get; set; }
        public string CouponCode { get; set; }
        public int OkToEmail { get; set; }
        public int IsAdmin { get; set; }
        public int BillingEqualsShipping { get; set; }
        public string LastIPAddress { get; set; }
        public string OrderNotes { get; set; }
        public DateTime SubscriptionExpiresOn { get; set; }
        public string RTShipRequest { get; set; }
        public string RTShipResponse { get; set; }
        public string OrderOptions { get; set; }
        public string LocaleSetting { get; set; }
        public string MicroPayBalance { get; set; }
        public int RecurringShippingMethodID { get; set; }
        public string RecurringShippingMethod { get; set; }
        public int BillingAddressID { get; set; }
        public int ShippingAddressID { get; set; }
        public string GiftRegistryGUID { get; set; }
        public int GiftRegistryIsAnonymous { get; set; }
        public int GiftRegistryAllowSearchB { get; set; }
        public string GiftRegistryNickName { get; set; }
        public int GiftRegistryHideShippingAddresses { get; set; }
        public int CODCompanyCheckAllowed { get; set; }
        public int CODNet30Allowed { get; set; }
        public string ExtensionData { get; set; }
        public string FinalizationData { get; set; }
        public int Deleted { get; set; }
        public DateTime CreatedOn { get; set; }
        public int Over13Checked { get; set; }
        public string CurrencySetting { get; set; }
        public int VATSetting { get; set; }
        public string VATRegistrationID { get; set; }
        public int StoreCCInDB { get; set; }
        public int IsRegistered { get; set; }
        public DateTime LockedUntil { get; set; }
        public int AdminCanViewCC { get; set; }
        public DateTime PwdChanged { get; set; }
        public int BadLoginCount { get; set; }
        public DateTime LastBadLogin { get; set; }
        public int Active { get; set; }
        public int PwdChangeRequired { get; set; }
        public string RequestedPaymentMethod { get; set; }
        public string BuySafe { get; set; }
        public int StoreID { get; set; }
        public Int64 CIM_ProfileId { get; set; }
        public string ShippingTitle { get; set; }
        public string orderreceivednotes { get; set; }

        // customer objects
    }
}
