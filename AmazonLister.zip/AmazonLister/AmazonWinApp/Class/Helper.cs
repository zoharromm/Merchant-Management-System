﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using System.IO;
using System.Data.SQLite;
using System.Net.Mail;


namespace AmazonWinApp
{
    class Helper
    {
        //Error Number from 101-110
        public static string ZGetSubmitFeedName
        {
            get
            {
               return  System.AppDomain.CurrentDomain.BaseDirectory + @"\Files\SubmitFeed.xml";
            }

        }
        public static string ZGetReportFeed
        {
            get
            {
                return System.AppDomain.CurrentDomain.BaseDirectory + @"\Files\";
            }

        }
        public static void LockError(string ErrorMessage)
        {
            try
            {
     
                    string SenderUserName = "developer3errorlocking@gmail.com";
                    string SenderName = "Developer 3";
                    string SenderPassword = "inform123";

                    SmtpClient client = new SmtpClient("smtp.gmail.com");
                    System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage(new MailAddress(SenderUserName, SenderName), new MailAddress("developer3errorlocking@gmail.com"));
                    msg.Subject = "Amazone App Errors";
                    msg.Body = ErrorMessage;
                    System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential(SenderUserName, SenderPassword);
                    client.UseDefaultCredentials = false;
                    client.Credentials = SMTPUserInfo;
                    client.Port = 587;
                    client.EnableSsl = true;
                    client.Send(msg);
                
            }
            catch
            {
            }
        }
        public static DataSet GetDS(string Query)
        {
            try
            {
                DataSet ds = new DataSet();
                StringBuilder QueryToStoreFront = new StringBuilder();
                QueryToStoreFront.Append("<AspDotNetStorefrontImport Version=\"9.3\" > ");
                QueryToStoreFront.Append("<Query Name=\"GetProductDetails\">");
                QueryToStoreFront.Append("<SQL>");
                QueryToStoreFront.Append("<![CDATA[");
                QueryToStoreFront.Append(Query);

                QueryToStoreFront.Append("]]>");
                QueryToStoreFront.Append("</SQL>");
                QueryToStoreFront.Append("</Query>");
                QueryToStoreFront.Append("</AspDotNetStorefrontImport>");
              
                string Result = Service._ZService.DoItUsernamePwd(Service._ZUserName, Service._ZPassword, QueryToStoreFront.ToString());

                XmlDocument xmlresult = new XmlDocument();
                xmlresult.LoadXml(Result);
                using (StringReader stringReader = new StringReader(Result))
                {
                    ds = new DataSet();
                    ds.ReadXml(stringReader);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw new Exception(@" Error " + Environment.NewLine +
                                     " Error Code : 102 " + Environment.NewLine +
                                     " Error At   : GetSubmitPrice " + Environment.NewLine +
                                     " Error " + ex.Message);
            }

        }
        public static bool ExcuteSQL(string Query)
        {
            try
            {
                bool lReturnValue = false;
                StringBuilder QueryToStoreFront = new StringBuilder();
                QueryToStoreFront.Append("<AspDotNetStorefrontImport Version=\"9.3\" > ");
                QueryToStoreFront.Append("<Query Name=\"ExcuteSQL\">");
                QueryToStoreFront.Append("<SQL>");
                QueryToStoreFront.Append("<![CDATA[");
                QueryToStoreFront.Append(Query);
                QueryToStoreFront.Append("]]>");
                QueryToStoreFront.Append("</SQL>");
                QueryToStoreFront.Append("</Query>");
                QueryToStoreFront.Append("</AspDotNetStorefrontImport>");
                string Result = Service._ZService.DoItUsernamePwd(Service._ZUserName, Service._ZPassword, QueryToStoreFront.ToString());
                if (Result.Contains("Error Message=\"Exception") == false)
                {
                    lReturnValue = true;
                }
                return lReturnValue;
            }
            catch (Exception ex)
            {
                throw new Exception(@" Error " + Environment.NewLine +
                                     " Error Code : 102 " + Environment.NewLine +
                                     " Error At   : GetSubmitPrice " + Environment.NewLine +
                                     " Error " + ex.Message);
            }

        }
        public static string SingleQouts(string str)
        {
            return "'" + str.Replace("'", "''") + "'";
        }



        
    }
}
