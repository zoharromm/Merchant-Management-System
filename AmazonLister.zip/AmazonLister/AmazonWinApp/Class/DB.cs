﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace AmazonWinApp
{
    //Error Code from 21-30
    public class SQLLiteHelper : IDisposable
    {
        SQLiteCommand SQLiteCommand;
        SQLiteConnection Conn;
        public SQLLiteHelper()
        {
            Conn = new SQLiteConnection();
            Conn.ConnectionString = string.Format("Data Source={0};Version=3;", System.AppDomain.CurrentDomain.BaseDirectory + @"DB\AmazonWinApp.DB");
            SQLiteCommand = new SQLiteCommand();
            SQLiteCommand.CommandText = string.Empty;
            SQLiteCommand.CommandType = System.Data.CommandType.Text;
           
        }
        public void LoadDBConn()
        {
            try
            {
                Conn.Open();
                SQLiteCommand.Connection = Conn;
            }
            catch (Exception ex)
            {
                throw new Exception("Connecton cann't be open : " + ex.Message);
            }
        }

        public DataTable GetDatable(string lQuery)
        {
            try
            {
                if (Conn.State == System.Data.ConnectionState.Closed)
                {
                    LoadDBConn();
                }
                DataTable ltbl = new DataTable();
                SQLiteDataAdapter lda = new SQLiteDataAdapter(lQuery, Conn);
                lda.Fill(ltbl);
                lda.Dispose();
                return ltbl;
            }
            catch (Exception ex)
            {
                throw new Exception("Error Code : 21 " + Environment.NewLine +
                                     ex.Message);
            }

        }


        public Int32 ExcuteCmd(string Query)
        {
            Int32 status = 0;
            try
            {
               
                if (Conn.State == System.Data.ConnectionState.Closed)
                {
                    LoadDBConn();
                }
                this.ResetCmd();
                SQLiteCommand.CommandText = Query;
                status = SQLiteCommand.ExecuteNonQuery();
                return status;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void ResetCmd()
        {
            SQLiteCommand.CommandText = string.Empty;
            SQLiteCommand.CommandType = System.Data.CommandType.Text;
            SQLiteCommand.Parameters.Clear();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
