﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Mail;
using HtmlAgilityPack;
using WatiN.Core;
using System.Data.Sql;
using System.Data.SqlClient;


namespace CrawlerWithSizes
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        #region sqlvariable
        SqlConnection Connection = new SqlConnection(System.Configuration.ConfigurationSettings.
                                               AppSettings["connectionstring"]);
        #endregion  sqlvariable

        /********Background **************/
        StreamWriter _Writererror =null;
        BackgroundWorker _Work = new BackgroundWorker();
        BackgroundWorker _Work1 = new BackgroundWorker();
        /***********End********************************/
        
        /****************List Variable ******************/
        List<BusinessLayer.Product> Worker1Products = new List<BusinessLayer.Product>();
        List<BusinessLayer.Product> Worker2Products = new List<BusinessLayer.Product>();
        List<string> _ProductUrl = new List<string>();
        List<string> CategoryUrl = new List<string>();
        List<string> SubCategoryUrl = new List<string>();
        List<string> _dateofbirth = new List<string>();
        /***************End**************************/

        /**********bool variable****************/
        bool Erorr_Liveoutworker1 = false;
        bool Erorr_Liveoutworker2 = false;
        bool _IsProduct = false;
        bool _IsLiveoutthere = false;
        bool _IsCategory = true;
        bool _Issubcat = false;
        bool _Stop = false;
        /****************End*****************/

        /********Int type****************/
        int _Chillyindex = 0;
        int _Pages = 0;
        int _TotalRecords = 0;
        int gridindex = 0;
        int time = 0;
       /***************End**************/

        /***********String variable **************/
        string _ScrapeUrl = "";
        string Bullets = "";
        string Url1 = "";
        string Url2 = "";
        /******************End********************/
        #region IeVariable

        IE _Worker1 = null;
        IE _Worker2 = null;
        
        #endregion IeVariable

        #region BackGroundWorkerVariable

        WebClient _Client2 = new WebClient();
        WebClient _Client1 = new WebClient();
        HtmlAgilityPack.HtmlDocument _Work1doc = new HtmlAgilityPack.HtmlDocument();
        HtmlAgilityPack.HtmlDocument _Work1doc2 = new HtmlAgilityPack.HtmlDocument();
        
        #endregion BackGroundWorkerVariable


        public Form1()
        {


            InitializeComponent();
            
            /****************Event declaration************/
            _Work.WorkerReportsProgress = true;
            _Work.WorkerSupportsCancellation = true;
            _Work.ProgressChanged += new ProgressChangedEventHandler(Work_ProgressChanged);
            _Work.RunWorkerCompleted += new RunWorkerCompletedEventHandler(work_RunWorkerAsync);
            _Work.DoWork += new DoWorkEventHandler(work_dowork);
            _Work1.WorkerReportsProgress = true;
            _Work1.WorkerSupportsCancellation = true;
            _Work1.ProgressChanged += new ProgressChangedEventHandler(Work1_ProgressChanged);
            _Work1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(work_RunWorkerAsync1);
            _Work1.DoWork += new DoWorkEventHandler(work_dowork1);
            /********************End************************/


        }

        #region backgroundworker1_eventdefination
        public void Work_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            _Bar1.Value = e.ProgressPercentage;
            _percent.Visible = true;
            _percent.Text = e.ProgressPercentage + "%  Completed";
        }
        public void work_dowork(object sender, DoWorkEventArgs e)
        {
            #region LoadHtmlContent
            bool _Iserror = false;
            try
            {
                if (!_IsProduct)
                {
                    _Work1doc.LoadHtml(_Client1.DownloadString(Url1));
                }
                else
                {
                    Erorr_Liveoutworker1 = true;
                    int CounterError = 0;
                    do
                    {
                        try
                        {
                            _Worker1.GoToNoWait(Url1);
                             Erorr_Liveoutworker1 = false;
                        }
                        catch
                        {
                            CounterError++;
                        }
                    } while (Erorr_Liveoutworker1 && CounterError < 20);
                }

            }
            catch
            {
                _Iserror = true;
            }
            #endregion LoadHtmlContent

            #region liveoutthere
             
            if (_IsLiveoutthere)
             {
                 #region liveouttherecategory
                 if (_IsCategory)
                {
                    try
                    {
                        if (_Work1doc.DocumentNode.SelectNodes("//span[@class=\"color--orange plp-h1-count\"]") != null)
                        {
                            int pages = 0;
                            int Noofproducts = Convert.ToInt32(_Work1doc.DocumentNode.SelectNodes("//span[@class=\"color--orange plp-h1-count\"]")[0].InnerText.ToLower().Replace("products", "").Trim().Replace(",", ""));
                            if (Noofproducts % 30 == 0)
                            {
                                pages = Convert.ToInt32(Noofproducts / 30);
                            }
                            else
                            {
                                pages = Convert.ToInt32(Noofproducts / 30) + 1;
                            }

                            for (int i = 1; i <= pages; i++)
                            {
                                SubCategoryUrl.Add(Url1 + "?n=30&p=" + i);
                            }
                        }
                    }
                    catch
                    {
                    }
                    _Chillyindex++;
                    _Work.ReportProgress((_Chillyindex * 100 / CategoryUrl.Count()));
                }

                 #endregion liveouttherecategory

                 #region liveouttheresubcategory

                 else if (_Issubcat)
                {
                    try
                    {

                        if(_Work1doc.DocumentNode.SelectNodes("//div[@class=\"plp-tile-name\"]/a")!=null)
                        {
                            foreach (HtmlNode _Node in _Work1doc.DocumentNode.SelectNodes("//div[@class=\"plp-tile-name\"]/a"))
                            {
                                foreach (HtmlAttribute _Att in _Node.Attributes)
                                {
                                    if (_Att.Name == "href")
                                    {
                                        if (!_ProductUrl.Contains("https://www.liveoutthere.com" + _Att.Value))
                                        _ProductUrl.Add("https://www.liveoutthere.com" + _Att.Value);
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {
                    }
                    _Chillyindex++;
                    _Work.ReportProgress((_Chillyindex * 100 / SubCategoryUrl.Count()));
                }

                #endregion liveouttheresubcategory

                 #region liveoutthereProduct

                else if(_IsProduct)
                 {
                     try
                     {
                         if (!Erorr_Liveoutworker1)
                         {
                             _Worker1.WaitForComplete();
                             #region CheckPageLoaded

                             #region variable
                             int checkcounter = 0;
                             #endregion variable

                             Erorr_Liveoutworker1 = true;
                             if (_Worker1.Html == null)
                             {
                                 do
                                 {
                                     System.Threading.Thread.Sleep(10);
                                     Application.DoEvents();
                                     checkcounter++;
                                 } while (_Worker1.Html == null && checkcounter < 10);
                             }

                             checkcounter = 0;
                             _Work1doc.LoadHtml(_Worker1.Html);

                             HtmlNodeCollection _CheckPageLoaded = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"size ng-scope\"]");

                             if (_CheckPageLoaded != null)
                                 Erorr_Liveoutworker1 = false;


                             while (_CheckPageLoaded == null && checkcounter < 10)
                             {
                            
                                 _Work1doc.LoadHtml(_Worker1.Html);
                                 _CheckPageLoaded = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"size ng-scope\"]");
                                 if (_CheckPageLoaded != null)
                                     Erorr_Liveoutworker1 = false;
                                 Application.DoEvents();
                                 checkcounter++;
                             }

                             #endregion CheckPageLoaded

                             #region LocalVariable
                             string Manufacturer = "";
                             string URL = Url1;
                             string MainImage = "";
                             string parentsku = "";
                             int parentcounter = 0;
                             string _Description = "";
                             #endregion LocalVariable

                             #region Manufacturer
                             if (!Erorr_Liveoutworker1)
                             {
                                 if (_Work1doc.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/span[@class=\"pdp-h1-brand\"]") != null)
                                 {
                                     Manufacturer = _Work1doc.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/span[@class=\"pdp-h1-brand\"]")[0].InnerText;
                                 }

                             #endregion Manufacturer


                                 #region MainImage

                                 if (_Work1doc.DocumentNode.SelectNodes("//img[@id=\"pdpLargeImg\"]") != null)
                                 {
                                     foreach (HtmlAttribute _Att in _Work1doc.DocumentNode.SelectNodes("//img[@id=\"pdpLargeImg\"]")[0].Attributes)
                                     {
                                         if (_Att.Name.CompareTo("src") == 0)
                                         {
                                             MainImage = _Att.Value.Substring(0, _Att.Value.IndexOf("602f0fa2c1f0d1ba5e241f914e856ff9")) + "602f0fa2c1f0d1ba5e241f914e856ff9";
                                             break;
                                         }
                                     }
                                 }

                                 #endregion MainImage


                                 #region getsizes

                                 DivCollection Divsize = _Worker1.Divs.Filter(Find.ByClass("colour-pricing"));

                                 LinkCollection _Sizes = Divsize[0].Links;
                                 for (int i = 0; i < _Sizes.Length; i++)
                                 {
                                     if (_Sizes[i].ClassName == "size-links text-center ng-binding enabled" || _Sizes[i].ClassName == "size-links text-center ng-binding active" || _Sizes[i].ClassName == "size-links text-center ng-binding" || _Sizes[i].ClassName == "size-links text-center ng-binding disabled")
                                     {
                                         _Sizes[i].Click();
                                         System.Threading.Thread.Sleep(10);

                                         #region Getcolors

                                         LinkCollection _Colors = _Sizes;

                                         for (int j = 0; j < _Colors.Length; j++)
                                         {
                                             string SKU = "";
                                             if (_Colors[j].ClassName == "color-thumbs enabled" || _Colors[j].ClassName == "color-thumbs active")
                                             {
                                                 _Colors[j].Click();
                                                 _Work1doc.LoadHtml(_Worker1.Html);
                                                 BusinessLayer.Product Prd = new BusinessLayer.Product();
                                                 #region ReadData


                                                 #region Name

                                                 if (_Work1doc.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/strong") != null)
                                                 {
                                                     Prd.Name = _Work1doc.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/strong")[0].InnerText.Trim();
                                                     SKU = GenerateSku("LOT", Prd.Name);
                                                 }

                                                 #endregion Name

                                                 #region Description

                                                 if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"product_copy\"]") != null)
                                                 {

                                                     _Description = StripHTML(_Work1doc.DocumentNode.SelectNodes("//div[@class=\"product_copy\"]")[0].InnerHtml).Replace("The Details", "");
                                                     if (_Description.Length > 2000)
                                                     {
                                                         _Description = _Description.Substring(0, 1997) + "...";
                                                     }
                                                     Prd.Description = _Description;
                                                 }

                                                 #endregion Description

                                                 #region Bulletpoints

                                                 if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"pdp-features-wrapper\"]") != null)
                                                 {
                                                     Prd.Bulletpoints = StripHTML(_Work1doc.DocumentNode.SelectNodes("//div[@class=\"pdp-features-wrapper\"]")[0].InnerHtml);

                                                     #region Bulletpoinyspoint wise
                                                     if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li") != null)
                                                     {
                                                         try
                                                         {
                                                             if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[0].InnerText.Length > 500)
                                                             {
                                                                 Prd.Bulletpoints1 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[0].InnerText.Substring(0,497);
                                                             }
                                                             else
                                                             {
                                                                 Prd.Bulletpoints1 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[0].InnerText;
                                                             }
                                                         }
                                                         catch
                                                         {

                                                         }
                                                         try
                                                         {
                                                             if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[1].InnerText.Length > 500)
                                                             {
                                                                 Prd.Bulletpoints2 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[1].InnerText.Substring(0, 497);
                                                             }
                                                             else
                                                             {
                                                                 Prd.Bulletpoints2 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[1].InnerText;
                                                             }
                                                         }
                                                         catch
                                                         {

                                                         }

                                                         try
                                                         {
                                                             if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[2].InnerText.Length > 500)
                                                             {
                                                                 Prd.Bulletpoints3 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[2].InnerText.Substring(0, 497);
                                                             }
                                                             else
                                                             {
                                                                 Prd.Bulletpoints3 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[2].InnerText;
                                                             }
                                                         }
                                                         catch
                                                         {

                                                         }

                                                         try
                                                         {
                                                             if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[3].InnerText.Length > 500)
                                                             {
                                                                 Prd.Bulletpoints4 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[3].InnerText.Substring(0, 497);
                                                             }
                                                             else
                                                             {
                                                                 Prd.Bulletpoints4 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[3].InnerText;
                                                             }
                                                         }
                                                         catch
                                                         {

                                                         }


                                                         try
                                                         {
                                                             if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[4].InnerText.Length > 500)
                                                             {
                                                                 Prd.Bulletpoints5 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[4].InnerText.Substring(0, 497);
                                                             }
                                                             else
                                                             {
                                                                 Prd.Bulletpoints5 = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[4].InnerText;
                                                             }
                                                         }
                                                         catch
                                                         {

                                                         }
                                                     }
                                                     #endregion Bulletpoinyspoint wise
                                                 }

                                                 #endregion Bulletpoints

                                                 #region Price
                                                 bool _IspriceFound = true;
                                                 string[] PriceDivformat ={"//div[@class=\"price-box pdp-price-box row\"]/p[@class=\"util-strong special-price price pdp-price color--red util-bold\"]",
                                                                    "//div[@class=\"price-box pdp-price-box row\"]/p[@class=\"util-strong special-price price pdp-price color--red util-bold show\"]"
                                                                    ,"//div[@class=\"price-box pdp-price-box row\"]/p[@class=\"util-strong regular-price price pdp-price color--orange util-bold show\"]"};

                                                 foreach (string Format in PriceDivformat)
                                                 {

                                                     if (_Work1doc.DocumentNode.SelectNodes(Format) != null)
                                                     {
                                                         foreach (HtmlAttribute _Att in _Work1doc.DocumentNode.SelectNodes(Format)[0].Attributes)
                                                         {
                                                             if (_Att.Name.ToLower() == "style")
                                                             {
                                                                 if (_Att.Value.ToLower().Contains("none"))
                                                                     _IspriceFound = false;
                                                                 else
                                                                     _IspriceFound = true;

                                                             }
                                                         }
                                                         if (_IspriceFound)
                                                         {
                                                             Prd.Price = _Work1doc.DocumentNode.SelectNodes(Format)[0].InnerText.Replace("$", "");
                                                             break;
                                                         }
                                                     }
                                                 }
                                                 #endregion Price

                                                 #region Stock
                                                 if (_Sizes[i].ClassName.ToLower().Contains("disabled"))
                                                 {
                                                     Prd.Stock = "N";
                                                 }
                                                 else
                                                 {
                                                     Prd.Stock = "Y";
                                                 }

                                                 #endregion Stock

                                                 #region Image


                                                 _Work1doc.LoadHtml("<html><head></head><body><div></div>" + _Colors[j].InnerHtml + "</img></body></html>");

                                                 if (_Work1doc.DocumentNode.SelectNodes("//img") != null)
                                                 {
                                                     foreach (HtmlAttribute _Att in _Work1doc.DocumentNode.SelectNodes("//img")[0].Attributes)
                                                     {
                                                         if (_Att.Name.CompareTo("src") == 0)
                                                         {
                                                             Prd.Image = MainImage + _Att.Value.Substring(_Att.Value.IndexOf("9df78eab33525d08d6e5fb8d27136e95")).Replace("9df78eab33525d08d6e5fb8d27136e95", "");
                                                             break;
                                                         }


                                                     }
                                                 }

                                                 #endregion Image


                                                 #region Size

                                                 Prd.Size = _Sizes[i].InnerHtml.Replace("\n", "").Trim();

                                                 #endregion Size

                                                 #region Color

                                                 _Work1doc.LoadHtml(_Colors[j].Parent.InnerHtml);
                                                 if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"color\"]") != null)
                                                 {
                                                     Prd.Color = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"color\"]")[0].InnerText;
                                                 }

                                                 #endregion Color


                                                 #region sku
                                                
                                                 #region Isparent

                                                 if (parentcounter == 0)
                                                 {
                                                     Prd.Isparent = true;
                                                     if (Manufacturer != null && Manufacturer.Length > 0)
                                                     {
                                                         string Manfirstcharcter = GenerateSku("", Manufacturer);
                                                         if (Manfirstcharcter.Length > 0)
                                                             SKU = SKU + "-" + Manfirstcharcter;
                                                     }
                                                     if (Prd.Size != null && Prd.Size.Length > 0)
                                                     {
                                                         SKU = SKU + "-" + GenerateSku("", Prd.Size);
                                                     }
                                                     if (Prd.Color != null && Prd.Color.Length > 0)
                                                     {
                                                         SKU = SKU + "-" + GeneratecolorSku("", Prd.Color);
                                                     }
                                                     parentsku = GeneratecolorSku("LOT", Prd.Name) + "-" + GeneratecolorSku("", Manufacturer);
                                                 }

                                                 else
                                                 {
                                                     if (Manufacturer != null && Manufacturer.Length > 0)
                                                     {
                                                         string Manfirstcharcter = GenerateSku("", Manufacturer);
                                                         if (Manfirstcharcter.Length > 0)
                                                             SKU = SKU + "-" + Manfirstcharcter;
                                                     }
                                                     if (Prd.Size != null && Prd.Size.Length > 0)
                                                     {
                                                         SKU = SKU + "-" + GenerateSku("", Prd.Size);
                                                     }
                                                     if (Prd.Color != null && Prd.Color.Length > 0)
                                                     {
                                                         SKU = SKU + "-" + GeneratecolorSku("", Prd.Color);
                                                     }
                                                 }

                                                 #endregion Isparent
                                                 #endregion sku
                                                 
                                                 #endregion
                                                 
                                                 Prd.Brand = Manufacturer;
                                                 Prd.Manufacturer = Manufacturer;
                                                 Prd.Currency = "CDN";
                                                 Prd.SKU = SKU;
                                                 Prd.URL = Url1;
                                                 Prd.parentsku = parentsku;
                                                 Worker1Products.Add(Prd);
                                                 // _Sizes[i].Click();
                                                 parentcounter++;
                                             }

                                         }

                                         #endregion Getcolors

                                     }
                                 }

                                 #endregion getsizes


                                 //ie.Close();
                                 //string sss = ie.Html;
                             }
                             else
                             {
                                 _Writererror.WriteLine(Url1);
                             }

                         }
                     }
                     catch (Exception exp)
                     {
                         _Writererror.WriteLine(Url1 + "        " + exp.Message);
                     }

                     _Chillyindex++;
                     _Work.ReportProgress((_Chillyindex * 100 / _ProductUrl.Count()));
                 }

                 #endregion liveoutthereProduct
             }
            #endregion liveoutthere

        }
        public void work_RunWorkerAsync(object sender, RunWorkerCompletedEventArgs e)
        {
           
          
        }

        #endregion backgroundworker1_eventdefination
        /*****************End*********************************/

        #region backgroundworker2_eventdefination
        public void work_dowork1(object sender, DoWorkEventArgs e)
        {
            #region LoadHtmlContent
            bool _Iserror = false;
            try
            {
                if (!_IsProduct)
                {
                    _Work1doc2.LoadHtml(_Client2.DownloadString(Url2));
                }
                else
                {
                    Erorr_Liveoutworker2= true;
                    int CounterError = 0;
                    do
                    {
                        try
                        {
                            System.Threading.Thread.Sleep(10);
                            Application.DoEvents();
                            _Worker2.GoToNoWait(Url2);
                            Erorr_Liveoutworker2 = false;
                        }
                        catch
                        {
                            CounterError++;
                        }
                    } while (Erorr_Liveoutworker2 && CounterError < 20);
                }

            }
            catch
            {
                _Iserror = true;
            }
            #endregion LoadHtmlContent

            #region liveoutthere

            if (_IsLiveoutthere)
            {
                #region liveouttherecategory
                if (_IsCategory)
                {
                    try
                    {
                        if (_Work1doc2.DocumentNode.SelectNodes("//span[@class=\"color--orange plp-h1-count\"]") != null)
                        {
                            int pages = 0;
                            int Noofproducts = Convert.ToInt32(_Work1doc2.DocumentNode.SelectNodes("//span[@class=\"color--orange plp-h1-count\"]")[0].InnerText.ToLower().Replace("products", "").Trim().Replace(",", ""));
                            if (Noofproducts % 30 == 0)
                            {
                                pages = Convert.ToInt32(Noofproducts / 30);
                            }
                            else
                            {
                                pages = Convert.ToInt32(Noofproducts / 30) + 1;
                            }

                            for (int i = 1; i <= pages; i++)
                            {
                                SubCategoryUrl.Add(Url2 + "?n=30&p=" + i);
                            }
                        }
                    }
                    catch
                    {
                    }
                    _Chillyindex++;
                    _Work1.ReportProgress((_Chillyindex * 100 / CategoryUrl.Count()));
                }

                #endregion liveouttherecategory

                #region liveouttheresubcategory

                else if (_Issubcat)
                {
                    try
                    {

                        if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"plp-tile-name\"]/a") != null)
                        {
                            foreach (HtmlNode _Node in _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"plp-tile-name\"]/a"))
                            {
                                foreach (HtmlAttribute _Att in _Node.Attributes)
                                {
                                    if (_Att.Name == "href")
                                    {
                                        if (!_ProductUrl.Contains("https://www.liveoutthere.com" + _Att.Value))
                                        _ProductUrl.Add("https://www.liveoutthere.com" + _Att.Value);
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {
                    }
                    _Chillyindex++;
                    _Work1.ReportProgress((_Chillyindex * 100 / SubCategoryUrl.Count()));
                }

                #endregion liveouttheresubcategory

                #region liveoutthereProduct

                else if (_IsProduct)
                {



                    try
                    {

                        if (!Erorr_Liveoutworker2)
                        {
                            #region variable

                            int checkcounter = 0;

                            #endregion variable
                            _Worker2.WaitForComplete();

                            #region CheckPageLoaded

                            Erorr_Liveoutworker2 = true;

                            if (_Worker2.Html == null)
                            {
                                do
                                {
                                    Application.DoEvents();
                                    checkcounter++;
                                } while (_Worker2.Html == null && checkcounter < 10);
                            }
                            checkcounter = 0;
                            _Work1doc2.LoadHtml(_Worker2.Html);


                            HtmlNodeCollection _CheckPageLoaded = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"size ng-scope\"]");
                            if (_CheckPageLoaded != null)
                                Erorr_Liveoutworker2 = false;


                            while (_CheckPageLoaded == null && checkcounter < 10)
                            {


                                _Work1doc2.LoadHtml(_Worker2.Html);
                                _CheckPageLoaded = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"size ng-scope\"]");
                                if (_CheckPageLoaded != null)
                                    Erorr_Liveoutworker2 = false;
                                Application.DoEvents();
                                checkcounter++;
                            }

                            #endregion CheckPageLoaded

                            #region LocalVariable

                            string Manufacturer = "";
                            string URL = Url2;
                            string MainImage = "";
                            string parentsku = "";
                            int parentcounter = 0;
                            string _Description = "";

                            #endregion LocalVariable

                            #region Manufacturer
                            if (!Erorr_Liveoutworker2)
                            {
                                if (_Work1doc2.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/span[@class=\"pdp-h1-brand\"]") != null)
                                {
                                    Manufacturer = _Work1doc2.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/span[@class=\"pdp-h1-brand\"]")[0].InnerText;
                                }

                            #endregion Manufacturer


                                #region MainImage

                                if (_Work1doc2.DocumentNode.SelectNodes("//img[@id=\"pdpLargeImg\"]") != null)
                                {
                                    foreach (HtmlAttribute _Att in _Work1doc2.DocumentNode.SelectNodes("//img[@id=\"pdpLargeImg\"]")[0].Attributes)
                                    {
                                        if (_Att.Name.CompareTo("src") == 0)
                                        {
                                            MainImage = _Att.Value.Substring(0, _Att.Value.IndexOf("602f0fa2c1f0d1ba5e241f914e856ff9")) + "602f0fa2c1f0d1ba5e241f914e856ff9";
                                            break;
                                        }
                                    }
                                }

                                #endregion MainImage


                                #region getsizes


                                DivCollection Divsize = _Worker2.Divs.Filter(Find.ByClass("colour-pricing"));

                                LinkCollection _Sizes = Divsize[0].Links;
                                for (int i = 0; i < _Sizes.Length; i++)
                                {
                                    if (_Sizes[i].ClassName == "size-links text-center ng-binding enabled" || _Sizes[i].ClassName == "size-links text-center ng-binding active" || _Sizes[i].ClassName == "size-links text-center ng-binding" || _Sizes[i].ClassName == "size-links text-center ng-binding disabled")
                                    {
                                        _Sizes[i].Click();
                                        System.Threading.Thread.Sleep(10);
                                        #region Getcolors


                                        LinkCollection _Colors = _Sizes;

                                        for (int j = 0; j < _Colors.Length; j++)
                                        {
                                            string SKU = "";
                                            if (_Colors[j].ClassName == "color-thumbs enabled" || _Colors[j].ClassName == "color-thumbs active")
                                            {
                                                _Colors[j].Click();
                                                _Work1doc2.LoadHtml(_Worker2.Html);
                                                BusinessLayer.Product Prd = new BusinessLayer.Product();
                                                #region ReadData


                                                #region Name

                                                if (_Work1doc2.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/strong") != null)
                                                {
                                                    Prd.Name = _Work1doc2.DocumentNode.SelectNodes("//h1[@class=\"pdp-h1\"]/span/strong")[0].InnerText.Trim();
                                                    SKU = GenerateSku("LOT", Prd.Name);
                                                }

                                                #endregion Name

                                                #region Description

                                                if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"product_copy\"]") != null)
                                                {

                                                    _Description = StripHTML(_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"product_copy\"]")[0].InnerHtml).Replace("The Details", "");
                                                    if (_Description.Length > 2000)
                                                    {
                                                        _Description = _Description.Substring(0, 1997) + "...";
                                                    }
                                                    Prd.Description = _Description;
                                                }

                                                #endregion Description

                                                #region Bulletpoints

                                                if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"pdp-features-wrapper\"]") != null)
                                                {
                                                    Prd.Bulletpoints = StripHTML(_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"pdp-features-wrapper\"]")[0].InnerHtml);

                                                    #region Bulletpoinyspoint wise
                                                    if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li") != null)
                                                    {
                                                        try
                                                        {
                                                            if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[0].InnerText.Length > 500)
                                                            {
                                                                Prd.Bulletpoints1 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[0].InnerText.Substring(0, 497);
                                                            }
                                                            else
                                                            {
                                                                Prd.Bulletpoints1 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[0].InnerText;
                                                            }
                                                        }
                                                        catch
                                                        {

                                                        }
                                                        try
                                                        {
                                                            if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[1].InnerText.Length > 500)
                                                            {
                                                                Prd.Bulletpoints2 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[1].InnerText.Substring(0, 497);
                                                            }
                                                            else
                                                            {
                                                                Prd.Bulletpoints2 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[1].InnerText;
                                                            }
                                                        }
                                                        catch
                                                        {

                                                        }

                                                        try
                                                        {
                                                            if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[2].InnerText.Length > 500)
                                                            {
                                                                Prd.Bulletpoints3 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[2].InnerText.Substring(0, 497);
                                                            }
                                                            else
                                                            {
                                                                Prd.Bulletpoints3 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[2].InnerText;
                                                            }
                                                        }
                                                        catch
                                                        {

                                                        }

                                                        try
                                                        {
                                                            if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[3].InnerText.Length > 500)
                                                            {
                                                                Prd.Bulletpoints4 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[3].InnerText.Substring(0, 497);
                                                            }
                                                            else
                                                            {
                                                                Prd.Bulletpoints4 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[3].InnerText;
                                                            }
                                                        }
                                                        catch
                                                        {

                                                        }


                                                        try
                                                        {
                                                            if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[4].InnerText.Length > 500)
                                                            {
                                                                Prd.Bulletpoints5 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[4].InnerText.Substring(0, 497);
                                                            }
                                                            else
                                                            {
                                                                Prd.Bulletpoints5 = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"feature-item\"]/ul/li")[4].InnerText;
                                                            }
                                                        }
                                                        catch
                                                        {

                                                        }
                                                    }
                                                    #endregion Bulletpoinyspoint wise
                                                }

                                                #endregion Bulletpoints

                                                #region Price
                                                bool _IspriceFound = true;
                                                string[] PriceDivformat ={"//div[@class=\"price-box pdp-price-box row\"]/p[@class=\"util-strong special-price price pdp-price color--red util-bold\"]",
                                                                    "//div[@class=\"price-box pdp-price-box row\"]/p[@class=\"util-strong special-price price pdp-price color--red util-bold show\"]"
                                                                    ,"//div[@class=\"price-box pdp-price-box row\"]/p[@class=\"util-strong regular-price price pdp-price color--orange util-bold show\"]"};

                                                foreach (string Format in PriceDivformat)
                                                {

                                                    if (_Work1doc2.DocumentNode.SelectNodes(Format) != null)
                                                    {
                                                        foreach (HtmlAttribute _Att in _Work1doc2.DocumentNode.SelectNodes(Format)[0].Attributes)
                                                        {
                                                            if (_Att.Name.ToLower() == "style")
                                                            {
                                                                if (_Att.Value.ToLower().Contains("none"))
                                                                    _IspriceFound = false;
                                                                else
                                                                    _IspriceFound = true;

                                                            }
                                                        }
                                                        if (_IspriceFound)
                                                        {
                                                            Prd.Price = _Work1doc2.DocumentNode.SelectNodes(Format)[0].InnerText.Replace("$", "");
                                                            break;
                                                        }
                                                    }
                                                }
                                                #endregion Price

                                                #region Stock
                                                if (_Sizes[i].ClassName.ToLower().Contains("disabled"))
                                                {
                                                    Prd.Stock = "N";
                                                }
                                                else
                                                {
                                                    Prd.Stock = "Y";
                                                }

                                                #endregion Stock

                                                #region Image


                                                _Work1doc2.LoadHtml("<html><head></head><body><div></div>" + _Colors[j].InnerHtml + "</img></body></html>");

                                                if (_Work1doc2.DocumentNode.SelectNodes("//img") != null)
                                                {
                                                    foreach (HtmlAttribute _Att in _Work1doc2.DocumentNode.SelectNodes("//img")[0].Attributes)
                                                    {
                                                        if (_Att.Name.CompareTo("src") == 0)
                                                        {
                                                            Prd.Image = MainImage + _Att.Value.Substring(_Att.Value.IndexOf("9df78eab33525d08d6e5fb8d27136e95")).Replace("9df78eab33525d08d6e5fb8d27136e95", "");
                                                            break;
                                                        }

                                                    }
                                                }

                                                #endregion Image


                                                #region Size

                                                Prd.Size = _Sizes[i].InnerHtml.Replace("\n", "").Trim();

                                                #endregion Size

                                                #region Color
                                                
                                                _Work1doc2.LoadHtml(_Colors[j].Parent.InnerHtml);
                                                if (_Work1doc2.DocumentNode.SelectNodes("//div[@class=\"color\"]") != null)
                                                {
                                                    Prd.Color = _Work1doc2.DocumentNode.SelectNodes("//div[@class=\"color\"]")[0].InnerText;
                                                }

                                                #endregion Color

                                                #region sku
                                                
                                                #region Isparent

                                                if (parentcounter == 0)
                                                {
                                                    Prd.Isparent = true;
                                                    if (Manufacturer != null && Manufacturer.Length > 0)
                                                    {
                                                        string Manfirstcharcter = GenerateSku("", Manufacturer);
                                                        if (Manfirstcharcter.Length > 0)
                                                            SKU = SKU + "-" + Manfirstcharcter;
                                                    }
                                                    if (Prd.Size != null && Prd.Size.Length > 0)
                                                    {
                                                        SKU = SKU + "-" + GenerateSku("", Prd.Size);
                                                    }
                                                    if (Prd.Color != null && Prd.Color.Length > 0)
                                                    {
                                                        SKU = SKU + "-" + GeneratecolorSku("", Prd.Color);
                                                    }
                                                    parentsku = GeneratecolorSku("LOT", Prd.Name) + "-" + GeneratecolorSku("", Manufacturer); ;
                                                }
                                                else
                                                {
                                                    if (Manufacturer != null && Manufacturer.Length > 0)
                                                    {
                                                        string Manfirstcharcter = GenerateSku("", Manufacturer);
                                                        if (Manfirstcharcter.Length > 0)
                                                            SKU = SKU + "-" + Manfirstcharcter;
                                                    }
                                                    if (Prd.Size != null && Prd.Size.Length > 0)
                                                    {
                                                        SKU = SKU + "-" + GenerateSku("", Prd.Size);
                                                    }
                                                    if (Prd.Color != null && Prd.Color.Length > 0)
                                                    {
                                                        SKU = SKU + "-" + GeneratecolorSku("", Prd.Color);
                                                    }

                                                }

                                                #endregion Isparent

                                                #endregion sku

                                                #endregion
                                                
                                                Prd.Brand = Manufacturer;
                                                Prd.Manufacturer = Manufacturer;
                                                Prd.Currency = "CDN";
                                                Prd.SKU = SKU;
                                                Prd.URL = Url2;
                                                Prd.parentsku = parentsku;
                                                Worker2Products.Add(Prd);
                                                // _Sizes[i].Click();
                                                parentcounter++;
                                            }

                                        }

                                        #endregion Getcolors

                                    }
                                }

                                #endregion getsizes


                                //ie.Close();
                                //string sss = ie.Html;
                            }
                            else
                            {
                                _Writererror.WriteLine(Url2);
                            }

                        }
                    }
                    catch (Exception exp)
                    {
                        _Writererror.WriteLine(Url2 + "            " + exp.Message);
                    }


                    _Chillyindex++;
                    _Work1.ReportProgress((_Chillyindex * 100 / _ProductUrl.Count()));
                }

                #endregion liveoutthereProduct
            }
            #endregion liveoutthere
        }
        public void work_RunWorkerAsync1(object sender, RunWorkerCompletedEventArgs e)
        {
            

        }
        public void Work1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            _Bar1.Value = e.ProgressPercentage;
            _percent.Visible = true;
            _percent.Text = e.ProgressPercentage + "% Completed";
        }
        #endregion backgroundworker2_eventdefination
        /*****************End*********************************/
        private void Form1_Load(object sender, EventArgs e)
        {
            /****************Code to select all check boxes*************/
            for (int i = 0; i < chkstorelist.Items.Count; i++)
            {
                chkstorelist.SetItemChecked(i, true);
            }

            /***************Grid view************************************/
             totalrecord.Visible = false;
            _lblerror.Visible = false;
            _percent.Visible = false;
            createcsvfile.Enabled = false;
            Pause.Enabled = false;

            #region datagridcolumn
            dataGridView1.Columns.Add("RowID", "RowID");
            dataGridView1.Columns.Add("SKU", "SKU");
            dataGridView1.Columns.Add("Product Name", "Product Name");
            dataGridView1.Columns.Add("Product Description", "Product Description");
            dataGridView1.Columns.Add("Bullet Points", "Bullet Points");
            dataGridView1.Columns.Add("Manufacturer", "Manufacturer");
            dataGridView1.Columns.Add("Brand Name", "Brand Name");
            dataGridView1.Columns.Add("Price", "Price");
            dataGridView1.Columns.Add("Currency", "Currency");
            dataGridView1.Columns.Add("In Stock", "In Stock");
            dataGridView1.Columns.Add("Image URL", "Image URL");
            dataGridView1.Columns.Add("URL", "URL");
            dataGridView1.Columns.Add("Size", "Size");
            dataGridView1.Columns.Add("Color", "Color");
            dataGridView1.Columns.Add("Isdefault", "Isdefault");
            dataGridView1.Columns.Add("ParentSku", "ParentSku");
            dataGridView1.Columns.Add("BullPoint1", "BullPoint1");
            dataGridView1.Columns.Add("BullPoint2", "BullPoint2");
            dataGridView1.Columns.Add("BullPoint3", "BullPoint3");
            dataGridView1.Columns.Add("BullPoint4", "BullPoint4");
            dataGridView1.Columns.Add("BullPoint5", "BullPoint5");
            #endregion datagridcolumn

            /****************BackGround worker *************************/
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            time++;
        }
        private void Go_Click(object sender, EventArgs e)
        {

            #region iebrowser intialization
            
            _Worker1 = new IE();
            _Worker2 = new IE();
            _Worker1.ShowWindow(WatiN.Core.Native.Windows.NativeMethods.WindowShowStyle.Hide);
            _Worker2.ShowWindow(WatiN.Core.Native.Windows.NativeMethods.WindowShowStyle.Hide);

            #endregion iebrowser intialization
            
            #region Variable_setting

            _Writererror = new StreamWriter(Application.StartupPath + "/"+DateTime.Now.ToString().Replace("-","").Replace(":","").Replace("/","")+"Error.txt");
            Worker1Products.Clear();
            Worker2Products.Clear();
            createcsvfile.Enabled = false;
           _IsProduct = false;
           _Chillyindex = 0;
           _IsCategory = true;
           _Stop = false;
            CategoryUrl.Clear();
            SubCategoryUrl.Clear();
           _ProductUrl.Clear();
           _percent.Visible = false;
           Go.Enabled = false;
           Pause.Enabled = true;
          _Bar1.Value = 0;
           dataGridView1.Rows.Clear();
          _lblerror.Visible = false;
          _Pages = 0;
          _TotalRecords = 0;
          gridindex = 0;
          time = 0;
          
          #endregion Variable_setting
          
          #region liveoutthere
          
            if (chkstorelist.GetItemChecked(0))
            {
                #region SettingGridIndex
                gridindex = dataGridView1.Rows.Count;
                if (gridindex == 1)
                {
                    if (dataGridView1.Rows[0].Cells[1].Value == null || dataGridView1.Rows[0].Cells[1].Value == DBNull.Value || String.IsNullOrEmpty(dataGridView1.Rows[0].Cells[1].Value.ToString()))
                    {
                        gridindex = 0;
                    }
                }
                #endregion SettingGridIndex

                #region LiveOutscoreVariable_setting
          
                _Chillyindex = 0;
                 CategoryUrl.Clear();
                 SubCategoryUrl.Clear();
                _ProductUrl.Clear();
                _Bar1.Value = 0;
                _percent.Visible = false;
                _Pages = 0;
                _TotalRecords = 0;
                _Stop = false;
                 time = 0;
                _IsCategory = true;
                _Issubcat = false;
                _IsLiveoutthere = true;
                _ScrapeUrl = "https://www.liveoutthere.com";
                _Work1doc.LoadHtml(_Client1.DownloadString(_ScrapeUrl));

                #endregion LiveOutscoreVariable_setting

                #region LiveOutscorecategory
                if (_Work1doc.DocumentNode.SelectNodes("//a[@class=\"navbar-submenu-container-item-shop-all\"]") != null)
                {
                    foreach (HtmlNode _node in _Work1doc.DocumentNode.SelectNodes("//a[@class=\"navbar-submenu-container-item-shop-all\"]"))
                    {
                        foreach (HtmlAttribute _Att in _node.Attributes)
                        {
                            if (_Att.Name.ToLower() == "href")
                                CategoryUrl.Add("https://www.liveoutthere.com/" + _Att.Value);
                        }
                    }
                }
                CategoryUrl.Remove(CategoryUrl[CategoryUrl.Count - 1]);

                #endregion LiveOutscorecategory

                #region LiveOutscoreVariable_setting

                _lblerror.Visible = true;
                _lblerror.Text = "We are going to read Category Url for " + chkstorelist.Items[0].ToString() + " Website";

                #endregion LiveOutscoreVariable_setting

                #region LiveOutscoresubcategory

                totalrecord.Visible = true;

                foreach (string url in CategoryUrl)
                {

                    while (_Work.IsBusy && _Work1.IsBusy)
                    {
                        Application.DoEvents();

                    }

                    while (_Stop)
                    {
                        Application.DoEvents();
                    }



                    if (!_Work.IsBusy)
                    {
                        Url1 = url;
                        _Work.RunWorkerAsync();
                    }

                    else
                    {
                        Url2 = url;
                        _Work1.RunWorkerAsync();

                    }
                    totalrecord.Text = "Total No of category Records " + CategoryUrl.Count() + " and Processed  " + _Chillyindex;

                }


                while (_Work.IsBusy || _Work1.IsBusy)
                {
                    Application.DoEvents();

                }

                #endregion LiveOutscoresubcategory

                #region LiveOutscoreVariable_setting
                tim(3);
                _Bar1.Value = 0;
                _percent.Visible = false;
                _lblerror.Visible = true;
                _lblerror.Text = "We are going to read Product Url for " + chkstorelist.Items[0].ToString() + " Website";
                _Chillyindex = 0;
                _IsCategory = false;
                _Issubcat = true;
                #endregion LiveOutscoreVariable_setting

                #region LiveOutscoreproducturl

               // _ProductUrl.Add("ssss");
                //_ProductUrl.Add("ssssaaaa");
                //_ProductUrl.Add("https://www.liveoutthere.com/jansport-superbreak.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/arcteryx-kitsilano-backpack.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/arcteryx-pender-backpack.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/altra-womens-one-squared.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/jansport-superbreak.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/moving-comfort-womens-fiona.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/jansport-superbreak.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/saxx-mens-pro-elite-boxer.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/marmot-womens-lobos-short.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/2xu-womens-compression-performance-run-sock.html");
                //_ProductUrl.Add("https://www.liveoutthere.com/jansport-superbreak.html");
                foreach (string url in SubCategoryUrl)
                { 

                    while (_Work.IsBusy && _Work1.IsBusy)
                    {
                        Application.DoEvents();

                    }

                    while (_Stop)
                    {
                        Application.DoEvents();
                    }

                    if (!_Work.IsBusy)
                    {
                        Url1 = url;
                        _Work.RunWorkerAsync();
                    }

                    else
                    {
                        Url2 = url;
                        _Work1.RunWorkerAsync();

                    }

                    totalrecord.Text = "Total No of Records " + SubCategoryUrl.Count() + " and Processed  " + _Chillyindex;
                }

                while (_Work.IsBusy || _Work1.IsBusy)
                {
                    Application.DoEvents();

                }


                #endregion LiveOutscoreproducturl

               #region LiveOutscoreproductinformation

              #region LiveOutscoreVariable_setting

                     tim(3);
                    _Bar1.Value = 0;
                    _percent.Visible = false;
                    _lblerror.Visible = true;
                    _lblerror.Text = "We are going to read Product Information for " + chkstorelist.Items[0].ToString() + " Website";
                    _Issubcat = false;
                    _IsProduct = true;
                    _Chillyindex = 0;
                    #endregion LiveOutscoreVariable_setting

                    /*****testing *****************/
                    //_ProductUrl.Clear();
                   // _ProductUrl.Add("https://www.liveoutthere.com/arcteryx-kitsilano-backpack.html");
                   // _ProductUrl.Add("https://www.liveoutthere.com/brooks-womens-glycerin-12.html");
                    //_ProductUrl.Add("https://www.liveoutthere.com/arcteryx-womens-cerium-lt-hoody.html");
                    //_ProductUrl.Add("https://www.liveoutthere.com/arcteryx-womens-elda-coat.html");
                    //_ProductUrl.Add("https://www.liveoutthere.com/patagonia-womens-ultralight-down-jacket.html");
                  /****************End***************/
                    int sss = 0;
                    foreach (string url in _ProductUrl)
                    {
                        while (_Work.IsBusy && _Work1.IsBusy)
                        {
                            Application.DoEvents();
                        }

                        while (_Stop)
                        {
                            Application.DoEvents();
                        }

                        if (!_Work.IsBusy)
                        {
                             Url1 = url;
                            _Work.RunWorkerAsync();
                        }

                        else
                        {
                            Url2 = url;
                            _Work1.RunWorkerAsync();

                        }

                        sss++;

                      totalrecord.Text = "Total No of Product Records " + _ProductUrl.Count() + " and Processed " + _Chillyindex;
                        
                    }
                 
                  while (_Work.IsBusy || _Work1.IsBusy)
                     {
                        Application.DoEvents();
                     }
                  
                
                  totalrecord.Text = "Total No of Product Records " + _ProductUrl.Count() + " and Processed " + _Chillyindex;
                  Disableallstores();

                
                #region InsertdataIngrid

                  foreach (BusinessLayer.Product prd in Worker1Products)
                  {
                      int index = gridindex;
                      gridindex++;
                      dataGridView1.Rows.Add();
                      dataGridView1.Rows[index].Cells[0].Value = index;
                      dataGridView1.Rows[index].Cells[1].Value = prd.SKU;
                      dataGridView1.Rows[index].Cells[2].Value = prd.Name;
                      dataGridView1.Rows[index].Cells[3].Value = prd.Description;
                      dataGridView1.Rows[index].Cells[4].Value = prd.Bulletpoints;
                      dataGridView1.Rows[index].Cells[5].Value = prd.Manufacturer;
                      dataGridView1.Rows[index].Cells[6].Value = prd.Brand;
                      dataGridView1.Rows[index].Cells[7].Value = prd.Price;
                      dataGridView1.Rows[index].Cells[8].Value = prd.Currency;
                      dataGridView1.Rows[index].Cells[9].Value = prd.Stock;
                      dataGridView1.Rows[index].Cells[10].Value = prd.Image;
                      dataGridView1.Rows[index].Cells[11].Value = prd.URL;
                      dataGridView1.Rows[index].Cells[12].Value = prd.Size;
                      dataGridView1.Rows[index].Cells[13].Value = prd.Color;
                      dataGridView1.Rows[index].Cells[14].Value = prd.Isparent;
                      dataGridView1.Rows[index].Cells[15].Value = prd.parentsku;
                      dataGridView1.Rows[index].Cells[16].Value = prd.Bulletpoints1;
                      dataGridView1.Rows[index].Cells[17].Value = prd.Bulletpoints2;
                      dataGridView1.Rows[index].Cells[18].Value = prd.Bulletpoints3;
                      dataGridView1.Rows[index].Cells[19].Value = prd.Bulletpoints4;
                      dataGridView1.Rows[index].Cells[20].Value = prd.Bulletpoints5;

                  }


                  foreach (BusinessLayer.Product prd in Worker2Products)
                  {
                      int index = gridindex;
                      gridindex++;
                      dataGridView1.Rows.Add();
                      dataGridView1.Rows[index].Cells[0].Value = index;
                      dataGridView1.Rows[index].Cells[1].Value = prd.SKU;
                      dataGridView1.Rows[index].Cells[2].Value = prd.Name;
                      dataGridView1.Rows[index].Cells[3].Value = prd.Description;
                      dataGridView1.Rows[index].Cells[4].Value = prd.Bulletpoints;
                      dataGridView1.Rows[index].Cells[5].Value = prd.Manufacturer;
                      dataGridView1.Rows[index].Cells[6].Value = prd.Brand;
                      dataGridView1.Rows[index].Cells[7].Value = prd.Price;
                      dataGridView1.Rows[index].Cells[8].Value = prd.Currency;
                      dataGridView1.Rows[index].Cells[9].Value = prd.Stock;
                      dataGridView1.Rows[index].Cells[10].Value = prd.Image;
                      dataGridView1.Rows[index].Cells[11].Value = prd.URL;
                      dataGridView1.Rows[index].Cells[12].Value = prd.Size;
                      dataGridView1.Rows[index].Cells[13].Value = prd.Color;
                      dataGridView1.Rows[index].Cells[14].Value = prd.Isparent;
                      dataGridView1.Rows[index].Cells[15].Value = prd.parentsku;

                      dataGridView1.Rows[index].Cells[16].Value = prd.Bulletpoints1;
                      dataGridView1.Rows[index].Cells[17].Value = prd.Bulletpoints2;
                      dataGridView1.Rows[index].Cells[18].Value = prd.Bulletpoints3;
                      dataGridView1.Rows[index].Cells[19].Value = prd.Bulletpoints4;
                      dataGridView1.Rows[index].Cells[20].Value = prd.Bulletpoints5;

                  }
                #endregion


                    #endregion LiveOutscoreproductinformation
            }

            #endregion liveoutthere

            #region error

            _Writererror.Close();
            #endregion error

            #region closeIEinstance
            try
            {
                _Worker1.Close();
                _Worker2.Close();
            }
            catch
            {
            }
            #endregion closeIEinstance

            /***************End*************************/


            MessageBox.Show("Process Completed." +DateTime.Now.ToString());

            Pause.Enabled = false;
            Go.Enabled = true;
            createcsvfile.Enabled = true;
        
        }
        private void Pause_Click(object sender, EventArgs e)
        {
            if (Pause.Text.ToUpper() == "PAUSE")//for pause and resume process
            {
                _Stop = true;
                Pause.Text = "RESUME";
            }
            else
            {
                _Stop = false;
                Pause.Text = "Pause";
            }
        }

        private void createcsvfile_Click(object sender, EventArgs e)
        {
            try
            {
                string Filename = "data" + DateTime.Now.ToString().Replace(" ", "").Replace("/", "").Replace(":", "");
                DataTable exceldt = new DataTable();
                exceldt.Columns.Add("Rowid", typeof(int));
                exceldt.Columns.Add("SKU", typeof(string));
                exceldt.Columns.Add("Product Name", typeof(string));
                exceldt.Columns.Add("Product Description", typeof(string));
                exceldt.Columns.Add("Bullet Points", typeof(string));
                exceldt.Columns.Add("Manufacturer", typeof(string));
                exceldt.Columns.Add("Brand Name", typeof(string));
                exceldt.Columns.Add("Price", typeof(decimal));
                exceldt.Columns.Add("Currency", typeof(string));
                exceldt.Columns.Add("In Stock", typeof(string));
                exceldt.Columns.Add("Image URL", typeof(string));
                exceldt.Columns.Add("URL", typeof(string));
                exceldt.Columns.Add("Size", typeof(string));
                exceldt.Columns.Add("Color", typeof(string));
                exceldt.Columns.Add("Isdefault", typeof(bool));
                exceldt.Columns.Add("ParentSku", typeof(string));
                exceldt.Columns.Add("Bulletpoints1", typeof(string));
                exceldt.Columns.Add("Bulletpoints2", typeof(string));
                exceldt.Columns.Add("Bulletpoints3", typeof(string));
                exceldt.Columns.Add("Bulletpoints4", typeof(string));
                exceldt.Columns.Add("Bulletpoints5", typeof(string));


                for (int m = 0; m < dataGridView1.Rows.Count; m++)
                {
                    exceldt.Rows.Add();

                    try
                    {
                        for (int n = 0; n < dataGridView1.Columns.Count; n++)
                        {
                            if (dataGridView1.Rows[m].Cells[n].Value == null || dataGridView1.Rows[m].Cells[n].Value == DBNull.Value || String.IsNullOrEmpty(dataGridView1.Rows[m].Cells[n].Value.ToString()))
                                continue;

                            exceldt.Rows[m][n] = dataGridView1.Rows[m].Cells[n].Value.ToString();


                        }
                    }
                    catch
                    {

                    }
                }


                #region sqlcode
                DataSet _Ds = new DataSet();
                DataTable _Product = new DataTable();
                using (SqlCommand Cmd = new SqlCommand())
                {
                    try
                    {
                        if (Connection.State == ConnectionState.Closed)
                            Connection.Open();
                        Cmd.CommandType = CommandType.StoredProcedure;
                        Cmd.CommandTimeout = 0;
                        Cmd.Connection = Connection;
                        Cmd.CommandText = "MarkHub_ScrapeProductMerging";
                        Cmd.Parameters.AddWithValue("@StoreName", "live Out There");
                        Cmd.Parameters.AddWithValue("@Products", exceldt);
                        SqlDataAdapter _ADP = new SqlDataAdapter(Cmd);
                        _ADP.Fill(_Ds);
                    }
                    catch
                    {

                    }
                }
                _Product = _Ds.Tables[0];

                #endregion sqlcode


                if (_Product.Rows.Count > 0)
                {

                    try
                    {
                       
                        using (CsvFileWriter writer = new CsvFileWriter(Application.StartupPath + "/" + Filename + ".txt"))
                        {
                            CsvFileWriter.CsvRow row = new CsvFileWriter.CsvRow();//HEADER FOR CSV FILE

                            foreach (DataColumn _Dc in _Product.Columns)
                            {
                                row.Add(_Dc.ColumnName);
                            }
                            writer.WriteRow(row);//INSERT TO CSV FILE HEADER


                            for (int m = 0; m < _Product.Rows.Count; m++)
                            {
                                 CsvFileWriter.CsvRow row1 = new CsvFileWriter.CsvRow();

                                for (int n = 0; n < _Product.Columns.Count; n++)
                                {
                                    if (_Product.Rows[m][n]!=null)
                                    row1.Add(String.Format("{0}", _Product.Rows[m][n].ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "")));
                                    else
                                        row1.Add(String.Format("{0}", ""));
                                }
                                writer.WriteRow(row1);
                            }
                        }
                        System.Diagnostics.Process.Start(Application.StartupPath + "/" + Filename + ".txt");//OPEN THE CSV FILE ,,CSV FILE NAMED AS DATA.CSV
                    }
                    catch (Exception) { MessageBox.Show("file is already open\nclose the file"); }
                    return;

                }

                else
                {
                    _lblerror.Visible = true;
                    _lblerror.Text = "OOPS there is some iossue occured. Please contact developer as soon as possible";
                }
            }
            catch
            {
                _lblerror.Visible = true;
                _lblerror.Text = "OOPS there is some iossue occured. Please contact developer as soon as possible";
            }
        }
        public class CsvFileWriter : StreamWriter //Writing  data to CSV
        {
            public CsvFileWriter(Stream stream)
                : base(stream)
            {
            }

            public CsvFileWriter(string filename)
                : base(filename)
            {
            }
            public class CsvRow : List<string> //Making each CSV rows
            {
                public string LineText { get; set; }
            }

            public void WriteRow(CsvRow row)
            {
                StringBuilder builder = new StringBuilder();
                bool firstColumn = true;
                foreach (string value in row)
                {
                    builder.Append(value.Replace("\n", "") + "\t");
                }
                row.LineText = builder.ToString();
                WriteLine(row.LineText);
            }
           
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
             try
            {
                _Worker1.Close();
                _Worker2.Close();
            }
            catch
            {
            }
            Application.Exit();
            Application.ExitThread();
            Environment.Exit(0);
        }
        private void totalrecord_Click(object sender, EventArgs e)
        {

        }

        private void _percent_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        #region customfunction
        public string GenerateSku(string starttext, string productname)
        {
            string result = "";
            foreach (var c in productname)
            {
                int ascii = (int)c;
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' ')
                {

                    result += c;
                }
            }
            string[] name = result.Split(' ');
            string firstcharcter = "";
            foreach (string _name in name)
            {
                firstcharcter = _name.Trim();
                if (firstcharcter.Length > 0)
                    starttext = starttext + firstcharcter.Substring(0, 1).ToUpper();
            }
            return starttext;
        }

        public string GeneratecolorSku(string starttext, string productname)
        {
            string result = "";
            foreach (var c in productname)
            {
                int ascii = (int)c;
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' ')
                {

                    result += c;
                }
            }
            string[] name = result.Split(' ');
            string firstcharcter = "";
            foreach (string _name in name)
            {
                firstcharcter = _name.Trim();
                if (firstcharcter.Length > 0)
                {
                    if(firstcharcter.Length>1)
                        starttext = starttext + firstcharcter.Substring(0, 2).ToUpper();
                        else
                    starttext = starttext + firstcharcter.Substring(0, 1).ToUpper();
                }
            }
            return starttext;
        }
        public void SendMail(string body, string subject, bool Isattachment, bool Exception)
        {
            try
            {
                System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
                MailAddress Fromaddress = new MailAddress("consultancy874@gmail.com", "Vishal Consultancy");

                message.From = Fromaddress;
                message.Subject = subject;
                message.To.Add(new MailAddress("consultancy874@gmail.com"));
                message.Body = body;
                message.IsBodyHtml = true;
                System.Net.Mail.SmtpClient mclient = new System.Net.Mail.SmtpClient();
                mclient.Host = "smtp.gmail.com";
                mclient.Port = 587;
                mclient.EnableSsl = true;
                if (!Exception)
                {
                    try
                    {
                        string name = Convert.ToString(System.Configuration.ConfigurationSettings.
                                               AppSettings["Contacts"]);
                        string[] mails = name.Split(',');
                        foreach (string mail in mails)
                        {
                            if (mail.Length > 0)
                            {
                                message.CC.Add(mail);
                            }
                        }
                    }
                    catch
                    {
                    }
                    if (Isattachment)
                    {
                    }

                }
                mclient.Credentials = new System.Net.NetworkCredential("consultancy874@gmail.com", "(123456@#Aa)");
                mclient.Send(message);
            }
            catch
            {
            }
        }
        public string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        private string StripHTML(string source)
        {
            try
            {
                string result;

                // Remove HTML Development formatting
                // Replace line breaks with space
                // because browsers inserts space
                result = source.Replace("\r", " ");
                // Replace line breaks with space
                // because browsers inserts space
                result = result.Replace("\n", " ");
                // Remove step-formatting
                result = result.Replace("\t", string.Empty);
                // Remove repeating spaces because browsers ignore them
                result = System.Text.RegularExpressions.Regex.Replace(result,
                                                                      @"( )+", " ");
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*script([^>])*>", "<script>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove the header (prepare first by clearing attributes)
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*head([^>])*>", "<head>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<( )*(/)( )*head( )*>)", "</head>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(<head>).*(</head>)", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // remove all scripts (prepare first by clearing attributes)
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*script([^>])*>", "<script>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<( )*(/)( )*script( )*>)", "</script>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                //result = System.Text.RegularExpressions.Regex.Replace(result,
                //         @"(<script>)([^(<script>\.</script>)])*(</script>)",
                //         string.Empty,
                //         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<script>).*(</script>)", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // remove all styles (prepare first by clearing attributes)
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*style([^>])*>", "<style>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<( )*(/)( )*style( )*>)", "</style>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(<style>).*(</style>)", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // insert tabs in spaces of <td> tags
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*td([^>])*>", "\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // insert line breaks in places of <BR> and <LI> tags
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*br( )*>", "\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*li( )*>", "\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // insert line paragraphs (double line breaks) in place
                // if <P>, <DIV> and <TR> tags
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*div([^>])*>", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*tr([^>])*>", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*p([^>])*>", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // Remove remaining tags like <a>, links, images,
                // comments etc - anything that's enclosed inside < >
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<[^>]*>", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // replace special characters:
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @" ", " ",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&bull;", " * ",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&lsaquo;", "<",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&rsaquo;", ">",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&trade;", "(tm)",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&frasl;", "/",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&lt;", "<",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&gt;", ">",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&copy;", "(c)",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&reg;", "(r)",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove all others. More can be added, see
                // http://hotwired.lycos.com/webmonkey/reference/special_characters/
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&(.{2,6});", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // for testing
                //System.Text.RegularExpressions.Regex.Replace(result,
                //       this.txtRegex.Text,string.Empty,
                //       System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // make line breaking consistent
                result = result.Replace("\n", "\r");

                // Remove extra line breaks and tabs:
                // replace over 2 breaks with 2 and over 4 tabs with 4.
                // Prepare first to remove any whitespaces in between
                // the escaped characters and remove redundant tabs in between line breaks
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)( )+(\r)", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\t)( )+(\t)", "\t\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\t)( )+(\r)", "\t\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)( )+(\t)", "\r\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove redundant tabs
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)(\t)+(\r)", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove multiple tabs following a line break with just one tab
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)(\t)+", "\r\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Initial replacement target string for line breaks
                string breaks = "\r\r\r";
                // Initial replacement target string for tabs
                string tabs = "\t\t\t\t\t";
                for (int index = 0; index < result.Length; index++)
                {
                    result = result.Replace(breaks, "\r\r");
                    result = result.Replace(tabs, "\t\t\t\t");
                    breaks = breaks + "\r";
                    tabs = tabs + "\t";
                }

                // That's it.
                return result;
            }
            catch
            {

                return source;
            }
        }

        public void Disableallstores()
        {
            _IsLiveoutthere = false;
        }
        public void tim(int t)
        {
            time = 0;
            timer1.Start();
            try
            {
                while (time <= t)
                {

                    Application.DoEvents();
                }
            }
            catch (Exception) { }
            timer1.Stop();

        }
        #endregion customfucntion


    }

}
