﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text;
using System.Collections.Generic;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace Schduler
{
    public class TaskManager
    {
        public string Path { get; set; }
        public string StoreName { get; set; }
        public DateTime StartTime { get; set; }
        public int SchdulerID { get; set; }
        public int Priority { get; set; }
        public int TaskStatus { get; set; }
        public int ID { get; set; }
        public int ProcessID { get; set; }
    }
    public class Schdule
    {
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        public List<TaskManager> BindTask(int type)
        {
            List<TaskManager> _TaskList = new System.Collections.Generic.List<TaskManager>();
            try
            {
                DataSet _Dtset = new DataSet();
                DB _db = new DB();
                _Dtset = _db.GetDS("TaskSchduler", 0, "@Type;" + type);
                if (_Dtset.Tables.Count > 0)
                {
                    int ID = 0;
                    foreach (DataRow _Row in _Dtset.Tables[0].Rows)
                    {
                        try
                        {
                            if (System.IO.File.Exists(_Row["AppPath"].ToString()))
                            {
                                ID++;
                                TaskManager _Task = new TaskManager();
                                _Task.Path = _Row["AppPath"].ToString();
                                _Task.SchdulerID = Convert.ToInt32(_Row["SchdulerID"]);
                                try
                                {
                                    _Task.Priority = Convert.ToInt32(_Row["Priority"]);
                                }
                                catch
                                {
                                }
                                _Task.TaskStatus = Convert.ToInt32(_Row["CurrentStatus"]);
                                _Task.StoreName = _Row["StoreName"].ToString();
                                _Task.ID = ID;
                                _TaskList.Add(_Task);
                            }
                        }
                        catch (Exception exp)
                        {
                            _Mail.SendMail("Issue accurred in Binding Task FROM Database at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);

                        }
                    }
                }
            }
            catch { }
            return _TaskList;
        }
    }
    public class DB
    {
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        public static SqlConnection Connection()
        {
            SqlConnection _Con = new SqlConnection(ConfigurationManager.AppSettings["connectionstring"].ToString());
            return _Con;
        }
        public void Executequery(string Command)
        {
            try
            {
                using (var con = Connection())
                {
                    using (SqlCommand cmd = new SqlCommand(Command))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception exp)
            {
                _Mail.SendMail("Issue accurred in Execute Query at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
            }

        }
        public DataSet GetDS(string Command, int Type, string Parameters)
        {
            DataSet _ds = new DataSet();
            try
            {
                using (var con = Connection())
                {
                    using (SqlCommand cmd = new SqlCommand(Command))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        cmd.Connection = con;
                        if (Type == 1)
                            cmd.CommandType = CommandType.Text;
                        else
                            cmd.CommandType = CommandType.StoredProcedure;
                        string[] Parameter = Parameters.Split('|');
                        foreach (string Prm in Parameter)
                        {
                            string[] Obj = Prm.Split(';');
                            cmd.Parameters.Add(Obj[0], Obj[1]);
                        }
                        SqlDataAdapter _ADP = new SqlDataAdapter(cmd);
                        _ADP.Fill(_ds);
                    }
                }
            }
            catch (Exception exp)
            {
                _Mail.SendMail("Issue accurred in Getting Task from Database at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
            }
            return _ds;
        }
    }
}
