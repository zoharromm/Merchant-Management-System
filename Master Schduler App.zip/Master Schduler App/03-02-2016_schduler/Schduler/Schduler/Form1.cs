﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
namespace Schduler
{
    public partial class App : Form
    {
        DB _db = new DB();
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        List<TaskManager> _TaskList = new List<TaskManager>();
        public App()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindTask(0);
            StopAllRunningTasks();
            TaskMnagement();
            timer1.Interval = 2000;
            timer1.Enabled = true;
            timer1.Tick += new EventHandler(schdulerProcess);
        }
        public void StopAllRunningTasks()
        {
            foreach (TaskManager _StopTask in _TaskList)
            {
                try
                {
                    string[] ProcessName = _StopTask.Path.Split('\\');
                    string Task = ProcessName[ProcessName.Length - 1].ToString();

                    foreach (Process _Prc in Process.GetProcesses())
                    {
                        if (_Prc.ProcessName.ToLower() == ProcessName[ProcessName.Length - 1].ToString().ToLower().Replace(".exe", ""))
                        {
                            try
                            {
                                _Prc.Kill();
                            }
                            catch (Exception exp)
                            {
                                _Mail.SendMail("Issue accurred in stopping Scrapper App " + ProcessName[ProcessName.Length - 1].ToString().ToLower().Replace(".exe", "") + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
                            }
                        }
                    }
                }
                catch
                {
                }

            }
        }


        public List<TaskManager> GetRunningTask()
        {
            List<TaskManager> _Result = new List<TaskManager>();
            try
            {
                _Result = (from Task in _TaskList
                           where Task.TaskStatus == 1
                           select Task).ToList();
            }
            catch (Exception exp)
            {
                _Mail.SendMail("Issue accurred in getting running task from Task Manager "  + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
            }
            return _Result;
        }
        public List<TaskManager> GetQueueTask()
        {
            List<TaskManager> _Result = new List<TaskManager>();
            try
            {
                _Result = (from Task in _TaskList
                           where Task.TaskStatus == 0
                           select Task).ToList();

            }
            catch (Exception exp)
            {
                _Mail.SendMail("Issue accurred in getting Queue task from Task Manager " + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
            }
            return _Result;
        }
        public void schdulerProcess(object sender, EventArgs e)
        {
            TaskMnagement();
        }
        public void TaskMnagement()
        {
            int TimeInterval = 10;
            int TaskRun = 2;
            try
            {
                TimeInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimeIntervalAfterThisTaskStop"]);
                TaskRun = Convert.ToInt32(ConfigurationManager.AppSettings["NoOfTaskToRun"]);
            }
            catch (Exception exp)
            {
                _Mail.SendMail("Issue accurred in getting Config Values TimeInterval,No Of TaskRun" + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
            }

            #region CheckStatusOfRunningTaskAndStopTask

            List<TaskManager> _RunningTask = GetRunningTask();
            foreach (TaskManager _TaskRun in _RunningTask)
            {
                string[] SplitString = _TaskRun.Path.Split('\\');
                if (!CheckstatusOfProcess(_TaskRun.ProcessID))
                {
                    try
                    {
                        _db.Executequery("update Schduler set CurrentStatus=0 ,LastProcessedStatus=1, LastRunTime='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where SchdulerID=" + _TaskRun.SchdulerID);
                        _TaskList.Remove(_TaskRun);
                    }
                    catch (Exception exp)
                    {
                        _Mail.SendMail("Issue accurred in TaskManagement function for Process " + _TaskRun.StoreName + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
                    }
                }
                else
                {
                    if ((DateTime.Now - _TaskRun.StartTime).TotalHours > TimeInterval)
                    {
                        try
                        {
                            if (Process.GetProcessById(_TaskRun.ProcessID) != null)
                            {
                                Process.GetProcessById(_TaskRun.ProcessID).Kill();
                                _db.Executequery("update Schduler set CurrentStatus=0,LastProcessedStatus=0, LastRunTime='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where SchdulerID=" + _TaskRun.SchdulerID);
                                _TaskList.Remove(_TaskRun);
                            }
                        }
                        catch (Exception exp)
                        {
                            _Mail.SendMail("Issue accurred in TaskManagement function for Process " + _TaskRun.StoreName + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
                        }
                    }

                }
            }
            #endregion CheckStatusOfRunningTaskAndStopTask

            #region RunTask
            _RunningTask = GetRunningTask();
            if (_RunningTask.Count < TaskRun)
            {
                int TaskNeedToRunRun = TaskRun - _RunningTask.Count();
                if (GetQueueTask().Count < TaskNeedToRunRun)
                    BindTask(1);
                bool NewRunTask = false;
                if (TaskNeedToRunRun > 0)
                {
                    foreach (TaskManager _Task in _TaskList)
                    {
                        if (TaskNeedToRunRun > 0)
                        {
                            if (_Task.TaskStatus == 0)
                            {
                                NewRunTask = true;
                                try
                                {
                                    Process _Prc = Process.Start(_Task.Path);
                                    _Task.StartTime = DateTime.Now;
                                    _Task.TaskStatus = 1;
                                    _Task.ProcessID = _Prc.Id;
                                    _db.Executequery("update Schduler set CurrentStatus=1  where SchdulerID=" + _Task.SchdulerID);
                                    TaskNeedToRunRun--;
                                }
                                catch (Exception exp)
                                {
                                    _Mail.SendMail("Issue accurred in TaskManagement function in RunTask Region for Process " + _Task.StoreName + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
                                    _Task.StartTime = DateTime.Now;
                                    _Task.TaskStatus = 1;
                                    _db.Executequery("update Schduler set CurrentStatus=1,LastProcessedStatus=0 where SchdulerID=" + _Task.SchdulerID);
                                }
                            }
                        }
                        else
                            break;
                    }
                }

                #region BindInterface
                InterFaceBind();
                #endregion BindInterface
            }
            #endregion RunTask


        }

        public void InterFaceBind()
        {
            SchdulerPanel.Controls.Clear();
            int Position = 0;
            int Locationy = 10;
            foreach (TaskManager _Task in _TaskList.OrderBy(m => m.ID))
            {
                try
                {
                    RoundButton _Button = new RoundButton();
                    _Button.Size = new Size(439, 39);
                    if (_Task.TaskStatus == 1)
                    {
                        _Button.BackColor = System.Drawing.Color.LimeGreen;
                        _Button.Text = _Task.StoreName + " in Running Mode.Start At " + _Task.StartTime;
                    }
                    else
                    {
                        Position++;
                        _Button.BackColor = System.Drawing.Color.Red;
                        _Button.Text = _Task.StoreName + " In Queue. No of Position in  Queue " + Position;
                    }
                    _Button.Location = new System.Drawing.Point(10, Locationy);
                    _Button.ForeColor = System.Drawing.Color.White;
                    _Button.FlatStyle = FlatStyle.Flat;
                    _Button.FlatAppearance.BorderSize = 0;
                    SchdulerPanel.Controls.Add(_Button);
                    Locationy = Locationy + 40;
                }
                catch (Exception exp)
                {
                    _Mail.SendMail("Issue accurred in Binding Interface function " + " at Time " + DateTime.Now.ToString() + ". Exception:" + exp.Message, "Schduler App Issue.", false, false, 1);
                }
            }

        }
        public bool CheckstatusOfProcess(int ProcessID)
        {
            bool ProcessRun = false;
            try
            {
                if (Process.GetProcessById(ProcessID)!=null)
                    ProcessRun = true;
            }
            catch (Exception exp)
            {
            }
            return ProcessRun;
        }
        public void BindTask(int type)
        {
            List<TaskManager> _NewTasks = new List<TaskManager>();
            Schdule _Sch = new Schdule();
            _NewTasks = _Sch.BindTask(type);
            int counter = 0;
            foreach (TaskManager _Task in _TaskList.OrderBy(m => m.ID))
            {
                counter++;
                _Task.ID = counter;
            }
            foreach (TaskManager _Task in _NewTasks.OrderBy(m => m.ID))
            {
                counter++;
                _Task.ID = counter;
                _TaskList.Add(_Task);
            }
        }


        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
