﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack;
using System.IO;
using System.Net;

namespace Dealers02
{
    public partial class Form1 : Form
    {
        #region htmlagility
        HtmlAgilityPack.HtmlDocument _Work1doc = new HtmlAgilityPack.HtmlDocument();
        StreamWriter writer = new StreamWriter(System.Windows.Forms.Application.StartupPath + "/log.txt");
        StreamWriter writer1 = new StreamWriter(System.Windows.Forms.Application.StartupPath + "/File.txt");
        #endregion htmlagility

        #region backgroundworker
        BackgroundWorker _Work = new BackgroundWorker();
        #endregion backgroundworker

        #region webclient
        ExtendedWebClient _Client1 = new ExtendedWebClient();
        #endregion webclient

        #region StringVariable
        string url = "";
        string dealerUrl = "http://www.netscanada.org/nets-members-directory/nets_category/retailers-directory/";
        #endregion StringVariable
        #region boolvariable
        bool isDataExist = true;
        #endregion boolvariable


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            writer1.WriteLine("URL\tPhone\tAddress");
            lblstatus.Text = "Process Started";
            isDataExist = true;
            try
            {
                for (int i = 1; i <= 1000; i++)
                {
                    if (isDataExist)
                    {
                        while (_Work.IsBusy)
                        {
                            Application.DoEvents();
                        }
                        url = dealerUrl + "/page/" + i;
                        _Work.RunWorkerAsync();
                    }
                    else
                        break;
                }
                while (_Work.IsBusy)
                {
                    Application.DoEvents();
                }
                lblstatus.Text = "Process completed";
            }
            catch (Exception exp)
            {
                writer.WriteLine(exp.Message);
            }
            writer.Close();
            writer1.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            #region backrgoundworketevendeclaration
            _Client1.Encoding = Encoding.UTF8;
            _Work.WorkerReportsProgress = true;
            _Work.WorkerSupportsCancellation = true;
            _Work.ProgressChanged += new ProgressChangedEventHandler(Work_ProgressChanged);
            _Work.RunWorkerCompleted += new RunWorkerCompletedEventHandler(work_RunWorkerAsync);
            _Work.DoWork += new DoWorkEventHandler(work_dowork);
            #endregion backrgoundworketevendeclaration
        }

        public void work_dowork(object sender, DoWorkEventArgs e)
        {
            bool _Iserror = false;
            int counterReload = 0;

            do
            {
                try
                {
                    counterReload++;
                    _Work1doc.LoadHtml(_Client1.DownloadString(url));
                    _Iserror = false;
                    System.Windows.Forms.Application.DoEvents();

                }
                catch
                {
                    _Iserror = true;
                }
            } while (counterReload < 4 && _Iserror);
            if (!_Iserror)
            {
                HtmlNodeCollection coll = _Work1doc.DocumentNode.SelectNodes("//div[@class=\"listing-details\"]");
                if (coll != null)
                {
                    foreach (HtmlNode node in coll)
                    {
                        string phone = "";
                        string websiteUrl = "";
                        string Address = "";
                        var coll1 = node.DescendantNodes().Where(d => d.Attributes.Contains("class") && d.Attributes["class"].Value.Contains("wpbdp-field-display wpbdp-field"));
                        if (coll1 != null)
                        {
                            foreach (HtmlNode node1 in coll1)
                            {
                                if (node1.InnerText.Contains("Website"))
                                {
                                    websiteUrl = node1.InnerText.Replace("Website", "").Replace(":", "").Trim();
                                }
                                else if (node1.InnerText.Contains("Phone"))
                                {
                                    phone = node1.InnerText.Replace("Phone", "").Replace(":", "").Trim();
                                }
                                else
                                {
                                    Address = Address + " " + node1.InnerText.Trim();
                                }
                            }
                            writer1.WriteLine(websiteUrl + "\t" + phone + "\t" + Address);
                        }
                        else
                            writer.WriteLine("Issue accured in getting div of class wpbdp-field-display wpbdp-field wpbdp-field-value field-display field-value wpbdp-field-phone wpbdp-field-meta wpbdp-field-type-textfield wpbdp-field-association-meta from url: " + url);
                    }
                }
                else
                    isDataExist = false;
            }
            else
            {
                isDataExist = false;
                writer.WriteLine("Issue accured in getting data from url: " + url);
            }
        }
        public void work_RunWorkerAsync(object sender, RunWorkerCompletedEventArgs e)
        {
        }
        public void Work_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            base.Show();
            this.button1_Click(null, null);
        }
    }
    public class ExtendedWebClient : WebClient
    {
        protected override WebRequest GetWebRequest(Uri uri)
        {
            WebRequest w = base.GetWebRequest(uri);
            w.Timeout = 120000;
            return w;
        }
    }
}
