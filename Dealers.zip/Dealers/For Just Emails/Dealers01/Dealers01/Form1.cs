﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using HtmlAgilityPack;
using System.Net;
using System.Net.Mail;
using Dealers01;
using System.Text.RegularExpressions;
using System.Net;
using Dealers01.BusinessLogic;

using System.Runtime.InteropServices;
using System.Reflection;

using WatiN.Core;
namespace Dealers01
{
    public partial class Form1 : System.Windows.Forms.Form
    {

        #region IE
        IE _Worker1 = null;
        IE _Worker2 = null;
        #endregion IE
        #region string Variable

        bool isImage = false;
        bool isEmail = false;
        string message = "";
        string url = "";
        string dealerName = "";
        string dealerName1 = "";
        int dealerID = 0;
        int dealerID1 = 1;
        string url1 = "";
        string scrapeUrl = "http://www.autotrader.ca/dealer/dealerfinder/DealerFinder.aspx?rctry=true&rcs=";
        string cat1 = "";
        string cat2 = "";
        int Index = 1;
        Dictionary<int, string> dealerEmails = new Dictionary<int, string>();
        Dictionary<int, string> websitesurl = new Dictionary<int, string>();
        #endregion string Variable

        #region ClassTypeVariable
        List<Dealer> dealers = new List<Dealer>();
        #endregion

        #region backgroundworker

        BackgroundWorker _Work = new BackgroundWorker();
        BackgroundWorker _Work1 = new BackgroundWorker();
        #endregion backgroundworker

        #region DictionaryVariable
        Dictionary<string, string> categories = new Dictionary<string, string>();
        #endregion DictionaryVariable

        #region webclient

        ExtendedWebClient _Client2 = new ExtendedWebClient();
        ExtendedWebClient _Client1 = new ExtendedWebClient();

        ExtendedWebClient _Client3 = new ExtendedWebClient();
        ExtendedWebClient _Client4 = new ExtendedWebClient();

        #endregion webclient
        #region htmlagility
        HtmlAgilityPack.HtmlDocument _Work1doc = new HtmlAgilityPack.HtmlDocument();
        HtmlAgilityPack.HtmlDocument _Work1doc2 = new HtmlAgilityPack.HtmlDocument();
        StreamWriter writer = new StreamWriter(System.Windows.Forms.Application.StartupPath + "/log.txt");
        #endregion htmlagility

        #region boolVariable
        bool productExist = true;
        bool isDealerInfo = true;
        #endregion boolVariable
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            #region backrgoundworketevendeclaration
            _Client1.Encoding = Encoding.UTF8;
            _Client2.Encoding = Encoding.UTF8;
            _Work.WorkerReportsProgress = true;
            _Work.WorkerSupportsCancellation = true;
            _Work.ProgressChanged += new ProgressChangedEventHandler(Work_ProgressChanged);
            _Work.RunWorkerCompleted += new RunWorkerCompletedEventHandler(work_RunWorkerAsync);
            _Work.DoWork += new DoWorkEventHandler(work_dowork);
            _Work1.WorkerReportsProgress = true;
            _Work1.WorkerSupportsCancellation = true;
            _Work1.ProgressChanged += new ProgressChangedEventHandler(Work1_ProgressChanged);
            _Work1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(work_RunWorkerAsync1);
            _Work1.DoWork += new DoWorkEventHandler(work_dowork1);

            #endregion backrgoundworketevendeclaration
        }
        public void work_dowork(object sender, DoWorkEventArgs e)
        {
            bool _Iserror = false;
            int counterReload = 0;
            if (!string.IsNullOrEmpty(dealerName))
            {
                if (!isImage)
                {
                    do
                    {
                        try
                        {
                            counterReload++;
                            if (isEmail)
                            {
                                _Worker1.GoTo(url);
                                _Worker1.WaitForComplete();
                                _Work1doc.LoadHtml(_Worker1.Html);
                            }
                            else
                                _Work1doc.LoadHtml(_Client1.DownloadString(url));
                            _Iserror = false;
                            System.Windows.Forms.Application.DoEvents();

                        }
                        catch
                        {
                            _Iserror = true;
                        }
                    } while (counterReload < 25 && _Iserror);

                    if (isDealerInfo)
                    {
                        GetDealerInfo(_Work1doc, cat1);
                    }
                    else
                        GetEmail(dealerID, dealerName, _Work1doc, url);

                }
                else if (isImage)
                {
                    try
                    {
                        Index++;
                        int imagename = Index;
                        if (!System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "/Images/" + imagename + System.IO.Path.GetExtension(url)))
                            _Client1.DownloadFile(url, System.Windows.Forms.Application.StartupPath + "/Images/" + imagename + System.IO.Path.GetExtension(url));

                    }
                    catch
                    {
                    }
                }
                //else
                //{
                //    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                //    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                //    StreamReader reader = new StreamReader(response.GetResponseStream());
                //    _Work1doc.LoadHtml(reader.ReadToEnd());
                //    GetEmail(dealerID, dealerName, _Work1doc, url);
                //}
            }
            else
                dealerEmails.Add(dealerID, "");
        }
        public void work_dowork1(object sender, DoWorkEventArgs e)
        {
            if (!isImage)
            {
                bool _Iserror = false;
                int counterReload = 0;
                do
                {
                    try
                    {
                        counterReload++;
                        if (isEmail)
                        {
                            _Worker2.GoTo(url1);
                            _Worker2.WaitForComplete();
                            _Work1doc2.LoadHtml(_Worker2.Html);
                        }
                        else
                            _Work1doc2.LoadHtml(_Client2.DownloadString(url1));
                        _Iserror = false;
                        System.Windows.Forms.Application.DoEvents();

                    }
                    catch
                    {
                        _Iserror = true;
                    }
                } while (counterReload < 25 && _Iserror);
                if (isDealerInfo)
                    GetDealerInfo(_Work1doc2, cat2);
                else
                    GetEmail(dealerID1, dealerName1, _Work1doc2, url1);
            }
            else if (isImage)
            {

                try
                {
                    Index++;
                    int imagename = Index;
                    if (!System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "/Images/" + imagename + System.IO.Path.GetExtension(url1)))
                        _Client2.DownloadFile(url1, System.Windows.Forms.Application.StartupPath + "/Images/" + imagename + System.IO.Path.GetExtension(url1));


                }
                catch
                {
                }
            }
            //else
            //{
            //    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url1);
            //    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //    StreamReader reader = new StreamReader(response.GetResponseStream());
            //    _Work1doc2.LoadHtml(reader.ReadToEnd());
            //    GetEmail(dealerID1, dealerName1, _Work1doc2, url1);
            //}
        }
        public void GetEmail(int id, string Name, HtmlAgilityPack.HtmlDocument doc, string googleUrl)
        {
            string dealerEmail = "";
            try
            {
            //    HtmlNodeCollection coll = doc.DocumentNode.SelectNodes("//div[@id=\"rso\"]");
            //    if (coll == null)
            //        coll = doc.DocumentNode.SelectNodes("//div[@id=\"ires\"]");
            //    if (coll != null)
            //    {
            //        HtmlNodeCollection coll1 = doc.DocumentNode.SelectNodes(".//div[@class=\"g\"]");

            //        if (coll1 != null)
            //        {
            //            string emailText = coll1[0].InnerText.ToLower();
            //            if (emailText.ToLower().Contains(Name))
            //            {
            //                string[] array = emailText.Split(new string[] { "email" }, StringSplitOptions.RemoveEmptyEntries);
            //                foreach (string email in array)
            //                {
            //                    if (email.Contains("@"))
            //                    {
            //                        string emailContent = "";
            //                        emailContent = email.Replace("\n", "").Replace("\t", "");
            //                        Regex emailRegex = new Regex(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", RegexOptions.IgnoreCase);
            //                        MatchCollection emailMatches = emailRegex.Matches(emailContent);
            //                        foreach (Match emailMatch in emailMatches)
            //                        {
            //                            dealerEmail = emailMatch.Value;

            //                            break;
            //                        }
            //                    }
            //                    if (!string.IsNullOrEmpty(dealerEmail))
            //                        break;
            //                }
            //            }
            //            else
            //                writer.WriteLine(googleUrl + ". Email Text is not found.");

            //        }
            //        else
            //            writer.WriteLine(googleUrl + ". Not found g id div.");
            //    }
            //    else
            //        writer.WriteLine(googleUrl + ". Not found rso id div.");

                string[] array = doc.DocumentNode.InnerText.Split(new string[] { "email" }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string email in array)
                {
                    if (email.Contains("@"))
                    {
                        string emailContent = "";
                        emailContent = email.Replace("\n", "").Replace("\t", "");
                        Regex emailRegex = new Regex(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", RegexOptions.IgnoreCase);
                        MatchCollection emailMatches = emailRegex.Matches(emailContent);
                        foreach (Match emailMatch in emailMatches)
                        {
                            dealerEmail = emailMatch.Value;

                            break;
                        }
                    }
                    if (!string.IsNullOrEmpty(dealerEmail))
                        break;
                }

            }
            catch
            {
                writer.WriteLine(googleUrl + ". Errpr accure in getting email.");
            }
            dealerEmails.Add(id, dealerEmail);
        }
        private string StripHTML(string source)
        {
            try
            {
                string result;

                // Remove HTML Development formatting
                // Replace line breaks with space
                // because browsers inserts space
                result = source.Replace("\r", " ");
                // Replace line breaks with space
                // because browsers inserts space
                result = result.Replace("\n", " ");
                // Remove step-formatting
                result = result.Replace("\t", string.Empty);
                // Remove repeating spaces because browsers ignore them
                result = System.Text.RegularExpressions.Regex.Replace(result,
                                                                      @"( )+", " ");
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*script([^>])*>", "<script>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove the header (prepare first by clearing attributes)
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*head([^>])*>", "<head>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<( )*(/)( )*head( )*>)", "</head>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(<head>).*(</head>)", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // remove all scripts (prepare first by clearing attributes)
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*script([^>])*>", "<script>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<( )*(/)( )*script( )*>)", "</script>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                //result = System.Text.RegularExpressions.Regex.Replace(result,
                //         @"(<script>)([^(<script>\.</script>)])*(</script>)",
                //         string.Empty,
                //         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<script>).*(</script>)", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // remove all styles (prepare first by clearing attributes)
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*style([^>])*>", "<style>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"(<( )*(/)( )*style( )*>)", "</style>",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(<style>).*(</style>)", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // insert tabs in spaces of <td> tags
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*td([^>])*>", "\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // insert line breaks in places of <BR> and <LI> tags
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*br( )*>", "\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*li( )*>", "\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // insert line paragraphs (double line breaks) in place
                // if <P>, <DIV> and <TR> tags
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*div([^>])*>", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*tr([^>])*>", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<( )*p([^>])*>", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // Remove remaining tags like <a>, links, images,
                // comments etc - anything that's enclosed inside < >
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"<[^>]*>", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // replace special characters:
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @" ", " ",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&bull;", " * ",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&lsaquo;", "<",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&rsaquo;", ">",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&trade;", "(tm)",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&frasl;", "/",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&lt;", "<",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&gt;", ">",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&copy;", "(c)",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&reg;", "(r)",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove all others. More can be added, see
                // http://hotwired.lycos.com/webmonkey/reference/special_characters/
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         @"&(.{2,6});", string.Empty,
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // for testing
                //System.Text.RegularExpressions.Regex.Replace(result,
                //       this.txtRegex.Text,string.Empty,
                //       System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // make line breaking consistent
                result = result.Replace("\n", "\r");

                // Remove extra line breaks and tabs:
                // replace over 2 breaks with 2 and over 4 tabs with 4.
                // Prepare first to remove any whitespaces in between
                // the escaped characters and remove redundant tabs in between line breaks
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)( )+(\r)", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\t)( )+(\t)", "\t\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\t)( )+(\r)", "\t\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)( )+(\t)", "\r\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove redundant tabs
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)(\t)+(\r)", "\r\r",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Remove multiple tabs following a line break with just one tab
                result = System.Text.RegularExpressions.Regex.Replace(result,
                         "(\r)(\t)+", "\r\t",
                         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                // Initial replacement target string for line breaks
                string breaks = "\r\r\r";
                // Initial replacement target string for tabs
                string tabs = "\t\t\t\t\t";
                for (int index = 0; index < result.Length; index++)
                {
                    result = result.Replace(breaks, "\r\r");
                    result = result.Replace(tabs, "\t\t\t\t");
                    breaks = breaks + "\r";
                    tabs = tabs + "\t";
                }

                // That's it.
                return result;
            }
            catch
            {

                return source;
            }
        }
        public void GetDealerInfo(HtmlAgilityPack.HtmlDocument doc, string category)
        {
            HtmlNodeCollection collection = doc.DocumentNode.SelectNodes("//div[@class=\"dfBox\"]");
            if (collection != null)
            {
                foreach (HtmlNode node in collection)
                {
                    Dealer dealer = new Dealer();
                    HtmlNodeCollection collectionTitle = node.SelectNodes(".//div[@class=\"dfCompanyName\"]");
                    if (collectionTitle != null)
                        dealer.Name = collectionTitle[0].InnerText.Trim();
                    HtmlNodeCollection collectionAddress = node.SelectNodes(".//div[@class=\"dfCompanyAddress\"]");
                    if (collectionAddress != null)
                    {
                        dealer.Address = StripHTML(collectionAddress[0].InnerHtml.Replace("<br>", " ")).Trim();
                        string[] address = collectionAddress[0].InnerHtml.Split(new string[] { "<br>" }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < address.Length; i++)
                        {
                            if (i == 1)
                            {
                                if (address[i].Contains("("))
                                {
                                    dealer.City = StripHTML(address[i].Substring(0, address[i].IndexOf('('))).Trim();
                                    dealer.Province = StripHTML(address[i].Substring(address[i].IndexOf('(')).Replace("(", "").Replace(")", "")).Trim();
                                }
                                else
                                    dealer.City = StripHTML(address[i]);
                            }
                            else if (i == 2)
                                dealer.PostalCode = address[i].Trim();
                            else if (i == 3)
                                dealer.PhoneNumber = address[i].Replace("Phone", "").Replace(":", "").Trim();
                        }
                    }

                    HtmlNodeCollection collectionImage = node.SelectNodes(".//div[@class=\"dfCompanyImage\"]");
                    if (collectionImage != null)
                    {
                        try
                        {
                            dealer.Logo = collectionImage[0].SelectNodes(".//img")[0].Attributes["src"].Value.Trim();
                        }
                        catch { }
                    }
                    HtmlNodeCollection collectionLink = node.SelectNodes(".//div[@class=\"dfLinks\"]");
                    if (collectionLink != null)
                    {
                        try
                        {
                            HtmlNodeCollection collectionHref = collectionLink[0].SelectNodes("..//a");
                            if (collectionHref != null)
                            {
                                foreach (HtmlNode node1 in collectionHref)
                                {
                                    if (node1.InnerText.ToLower().Contains("website"))
                                        dealer.WebsiteUrl = node1.Attributes["href"].Value;
                                }
                            }
                        }
                        catch
                        { }
                    }
                    dealer.Category = category;
                    if (!string.IsNullOrEmpty(category))
                    {

                        List<Dealer> listDealer = dealers.GetRange(0, dealers.Count());
                        List<Dealer> dealerList = (from dlr in listDealer
                                                   where dlr.Name == dealer.Name
                                                   select dlr).ToList();
                        if (dealerList.Count() == 0)
                            dealers.Add(dealer);
                        else
                        {
                            foreach (Dealer dealer1 in dealerList)
                            {
                                dealer1.Category = dealer1.Category + category + ",";
                            }
                        }
                    }
                    else
                        dealers.Add(dealer);
                }
            }
            else
                productExist = false;
        }
        public void work_RunWorkerAsync(object sender, RunWorkerCompletedEventArgs e)
        {


        }
        public void work_RunWorkerAsync1(object sender, RunWorkerCompletedEventArgs e)
        {


        }
        public void Work_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }
        public void Work1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }


        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                lblerror.Text = "Exception Occured while releasing object " + ex.ToString();
            }
            finally
            {
                GC.Collect();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader reader = new StreamReader(System.Windows.Forms.Application.StartupPath + "/book1.txt");
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                try
                {
                    websitesurl.Add(Convert.ToInt32(line.Split(new string[] { "\t" }, StringSplitOptions.None)[0]), line.Split(new string[] { "\t" }, StringSplitOptions.None)[1]);
                }
                catch
                {
                }
            }
            Index = 0;
            cat2 = "";
            cat1 = "";
            isImage = false;
            lblerror.Text = "Processing...";
            #region DeleteFiles
            try
            {
                //    foreach (string file in Directory.GetFiles(System.Windows.Forms.Application.StartupPath + "/Images"))
                //    {
                //        File.Delete(file);
                //    }
                //}
                //catch { }

                //#endregion DeleteFiles
                //#region GetBasicInfoOfDealers
                //try
                //{
                //    for (int i = 0; i < 10000; i++)
                //    {
                //        while (_Work.IsBusy && _Work1.IsBusy)
                //        {
                //            System.Windows.Forms.Application.DoEvents();
                //        }

                //        if (!_Work.IsBusy)
                //        {
                //            url = scrapeUrl + (i + 1) * 35;
                //            _Work.RunWorkerAsync();
                //        }
                //        else
                //        {
                //            url1 = scrapeUrl + (i + 1) * 35;
                //            _Work1.RunWorkerAsync();
                //        }

                //        if (!productExist)
                //            break;

                //    }
                //    while (_Work.IsBusy || _Work1.IsBusy)
                //    {
                //        System.Windows.Forms.Application.DoEvents();
                //    }
                //#endregion GetBasicInfoOfDealers

                //    #region Categories
                //    _Work1doc.LoadHtml(_Client1.DownloadString(scrapeUrl));
                //    if (_Work1doc.DocumentNode.SelectNodes("//div[@class=\"refine-search\"]") != null)
                //    {
                //        try
                //        {
                //            foreach (HtmlNode node in _Work1doc.DocumentNode.SelectNodes("//div[@class=\"refine-search\"]")[0].SelectNodes(".//a"))
                //            {
                //                try
                //                {
                //                    categories.Add(StripHTML(node.InnerText.Contains("(") ? node.InnerText.Substring(0, node.InnerText.IndexOf("(")) : node.InnerText), "http://www.autotrader.ca/" + node.Attributes["href"].Value);
                //                }
                //                catch
                //                {
                //                }
                //            }
                //        }
                //        catch
                //        {
                //            writer.WriteLine("Categories not found");
                //        }
                //    }
                //    else if (_Work1doc.DocumentNode.SelectNodes("//div[@id=\"ctl00_ctl00_MainContent_MainContent_DealerRefinementControl1_refinementCat2_divRefinementItems\"]") != null)
                //    {
                //        try
                //        {
                //            foreach (HtmlNode node in _Work1doc.DocumentNode.SelectNodes("//div[@id=\"ctl00_ctl00_MainContent_MainContent_DealerRefinementControl1_refinementCat2_divRefinementItems\"]")[0].SelectNodes(".//a"))
                //            {
                //                categories.Add(StripHTML(node.InnerText.Contains("(") ? node.InnerText.Substring(0, node.InnerText.IndexOf("(")) : node.InnerText), "http://www.autotrader.ca/" + node.Attributes["href"].Value);
                //            }
                //        }
                //        catch
                //        {
                //            writer.WriteLine("Categories not found");
                //        }
                //    }
                //    else
                //        writer.WriteLine("Categories not found");

                //    lblerror.Text = "Reading Dealers from category page....";
                //    foreach (var cat in categories)
                //    {
                //        productExist = true;
                //        for (int i = 0; i < 10000; i++)
                //        {
                //            while (_Work.IsBusy && _Work1.IsBusy)
                //            {
                //                System.Windows.Forms.Application.DoEvents();
                //            }

                //            if (!_Work.IsBusy)
                //            {
                //                url = (cat.Value.Contains("?") ? cat.Value + "&rcs=" : cat.Value + "?rcs=") + (i + 1) * 35;
                //                cat1 = cat.Key;
                //                _Work.RunWorkerAsync();
                //            }
                //            else
                //            {
                //                url1 = (cat.Value.Contains("?") ? cat.Value + "&rcs=" : cat.Value + "?rcs=") + (i + 1) * 35;
                //                cat2 = cat.Key;
                //                _Work1.RunWorkerAsync();
                //            }

                //            if (!productExist)
                //                break;
                //        }


                //    }

                //    while (_Work.IsBusy || _Work1.IsBusy)
                //    {
                //        System.Windows.Forms.Application.DoEvents();
                //    }
                //    #endregion Categories

                //    #region DownloadImages
                //    cat1 = "";
                //    cat2 = "";
                //    isImage = true;
                //    lblerror.Text = "Downloading Images....";
                //    foreach (Dealer deal in dealers)
                //    {
                //        if (!string.IsNullOrEmpty(deal.Logo))
                //        {
                //            while (_Work.IsBusy && _Work1.IsBusy)
                //            {
                //                System.Windows.Forms.Application.DoEvents();
                //            }

                //            if (!_Work.IsBusy)
                //            {
                //                url = deal.Logo;
                //                _Work.RunWorkerAsync();
                //            }
                //            else
                //            {
                //                url1 = deal.Logo;
                //                _Work1.RunWorkerAsync();
                //            }

                //        }

                //    }
                //    while (_Work.IsBusy || _Work1.IsBusy)
                {
                    System.Windows.Forms.Application.DoEvents();
                }
            #endregion DownloadImages
                isImage = false;
                isEmail = true;
                isDealerInfo = false;
                #region GetEmail
                lblerror.Text = "Reading Emails....";
                _Worker1 = new IE();
                _Worker2 = new IE();
                foreach (var deal in websitesurl)
                {

                    while (_Work.IsBusy || _Work1.IsBusy)
                    {
                        System.Windows.Forms.Application.DoEvents();
                    }

                    if (!_Work.IsBusy)
                    {

                        dealerID = deal.Key;
                        //url = deal.Value.Replace("http://", "").Replace("https://", "");
                        //url = url.Contains("/") ? url.Substring(0, url.IndexOf("/")) : url;
                        // url = url.Contains("?") ? url.Substring(0, url.IndexOf("?")) : url;

                        //url = "https://www.google.ca/search?q=" + url + " email";
                        url = deal.Value;
                        dealerName = url;
                        _Work.RunWorkerAsync();
                    }
                    else
                    {

                        dealerID1 = deal.Key;
                        //url1 = deal.Value.Replace("http://", "").Replace("https://", "");
                        //url1 = url1.Contains("/") ? url1.Substring(0, url1.IndexOf("/")) : url1;
                        //url1 = url1.Contains("?") ? url1.Substring(0, url1.IndexOf("?")) : url1;
                        //dealerName1 = url1;
                        //url1 = "https://www.google.ca/#q=" + url1 + " email";
                        url1 = deal.Value;
                        dealerName1 = url1;
                        _Work1.RunWorkerAsync();
                    }


                }
                while (_Work.IsBusy || _Work1.IsBusy)
                {
                    System.Windows.Forms.Application.DoEvents();
                }
                _Worker1.Close();
                _Worker2.Close();

                StreamWriter writeremail = new StreamWriter(System.Windows.Forms.Application.StartupPath + "/email.txt");
                foreach (var email in dealerEmails)
                {
                    writeremail.WriteLine(email.Key + "\t" + email.Value);
                }
                writeremail.Close();
                #endregion GetEmail

                #region GenerateOfExcel

                lblerror.Text = "Genrating Excel...";

                #endregion GenerateOfExcel
            }
            catch (Exception exp) { lblerror.Text = exp.Message; }

        }



        private void Form1_Shown(object sender, EventArgs e)
        {
            base.Show();
            this.button1_Click(null, null);
        }
    }
    public class ExtendedWebClient : WebClient
    {
        protected override WebRequest GetWebRequest(Uri uri)
        {
            WebRequest w = base.GetWebRequest(uri);
            w.Timeout = 120000;
            return w;
        }
    }
}
