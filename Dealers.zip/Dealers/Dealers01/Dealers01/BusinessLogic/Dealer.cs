﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dealers01.BusinessLogic
{
    public class Dealer
    {
        public static int index = 0;
        public Dealer()
        {
            index++;
            this.Sno = index;
          
        }
        public int Sno { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public string PostalCode { get; set; }
        public string PhoneNumber { get; set; }
        public string WebsiteUrl { get; set; }
        public string Category { get; set; }
        public string Email { get; set; }
        public string Logo { get; set; }
       
    }
}
