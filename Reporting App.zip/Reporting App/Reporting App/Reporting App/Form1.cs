﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;
using System.IO;
using OfficeOpenXml;
using Ionic.Zip;
namespace Reporting_App
{
    public partial class Form1 : Form
    {
        bool TaskStatus = false;
        int MaxRecord = 0;
        int MaxRecordFeedFile = 0;
        string ReportFilePath = "";
        string FeedFilePath = "";
        BusinessLayer.DB _DB = new BusinessLayer.DB();
        BusinessLayer.Mail _Mail = new BusinessLayer.Mail();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            Timer t = new Timer();
            t.Interval = 18000;
            t.Enabled = true;
            timer1_Tick(null, null);
            t.Tick += new EventHandler(timer1_Tick);


        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!TaskStatus)
            {
                TaskStatus = true;
                System.Threading.Thread triggerThread = new System.Threading.Thread(Trigger);
                triggerThread.Start();
            }

        }
        public static string ReplaceFirstLastDoubleQuote(string content)
        {
            string s = content;
            try
            {
                char c = '"';
                int indexBegin = s[0] == c ? 1 : 0;
                int indexEnd = s[s.Length - 1] == c ? 1 : 0;
                s = s.Substring(indexBegin, s.Length - (indexEnd + indexBegin));
                return s;
            }
            catch
            {
                return content;
            }
        }
        public void Trigger()
        {
            #region configVariable
            MaxRecord = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxRecord"]);
            MaxRecordFeedFile = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxRecordFeedFile"]);
            ReportFilePath = System.Configuration.ConfigurationManager.AppSettings["ReportFilesPath"];
            FeedFilePath = System.Configuration.ConfigurationManager.AppSettings["FeedFilePath"];
            #endregion configVariable
            #region Reports
            try
            {
                DataSet pendingReports = new DataSet();
                pendingReports = _DB.GetDataset("select [Report ID],isnull(Reports.Email,'') as Email,isnull(Reports.Filterstring,'') as Filterstring,ReportType.TypeName from Reports join ReportType on Reports.[Report Type ID]=ReportType.[Report Type ID] where [Report Status]!='Completed' order by [Report ID]", CommandType.Text, "");
                ProcessReports(pendingReports);
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Reporting App under Trigger Function " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Reporting APP.", false, false, 4);

            }
            #endregion Reports
            #region Feed
            try
            {
                DataSet pendingFeed = new DataSet();
                pendingFeed = _DB.GetDataset("select [Feed ID],isnull(Feed.BatchID,'') as BatchID,isnull(FeedType.[Feed Type],'') as [Feed Type] from Feed join FeedType on Feed.[Feed Type ID]=FeedType.[Feed Type ID] where [Feed Status]!='Completed'  and ((ErrorAccuredDateTime is null) or (isnull(ErrorAccuredDateTime,'')!='' and ErrorAccuredDateTime<DATEADD(day,-1,getdate()))) order by [Feed ID]", CommandType.Text, "");
                ProcessFeeds(pendingFeed);
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Reporting App under Trigger Function " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Reporting APP.", false, false, 4);

            }
            #endregion Reports

            TaskStatus = false;
        }
        public void ProcessReports(DataSet pendingReports)
        {
            if (pendingReports.Tables.Count > 0)
            {
                foreach (DataRow row in pendingReports.Tables[0].Rows)
                {
                    ProcessReport(Convert.ToInt32(row["Report ID"]), row["Filterstring"].ToString(), row["TypeName"].ToString(), row["Email"].ToString(), "Inventory");
                    System.Threading.Thread.Sleep(1000);
                }
            }
        }
        public void ProcessReport(int ReportID, string FilterString, string TypeName, string Email, string EntityType)
        {
            DataSet Products = new DataSet();
            Products.Tables.Clear();
            DataSet dummy;
            DataTable table = new DataTable();
            try
            {
                int Pages = 0;
                int TotalRecords = 0;
                dummy = new DataSet();
                if (EntityType == "Inventory")
                    dummy = _DB.GetDataset("GenerateEntityReport", CommandType.StoredProcedure, "@FilterString," + FilterString.Replace(",", "#$^&").Replace(":", "#$^&&") + ":@TypeName," + TypeName + ":@EntityType," + EntityType + ":@Pagesize," + MaxRecord + ":@page,1");
                table = dummy.Tables[0];
                if (dummy.Tables.Count > 1)
                    TotalRecords = Convert.ToInt32(dummy.Tables[1].Rows[0][0]);
                if (TotalRecords % MaxRecord == 0)
                    Pages = Convert.ToInt32(TotalRecords / MaxRecord);
                else
                    Pages = Convert.ToInt32(TotalRecords / MaxRecord) + 1;

                for (int page = 2; page <= Pages; page++)
                {

                    dummy = new DataSet();
                    if (EntityType == "Inventory")
                        dummy = _DB.GetDataset("GenerateEntityReport", CommandType.StoredProcedure, "@FilterString," + FilterString.Replace(",", "").Replace(":", "") + ":@TypeName," + TypeName + ":@EntityType," + EntityType + ":@Pagesize," + MaxRecord + ":@page," + page);
                    dummy.Tables[0].AsEnumerable().ToList().ForEach(row => table.ImportRow(row));
                    int rows = table.Rows.Count;
                    System.Threading.Thread.Sleep(1000);
                }
                Products.Tables.Add(table.Copy());
                GenerateFile(Products, ReportID, Email, TypeName);
            }
            catch (Exception Exp)
            {
                _Mail.SendMail("Issue Occured in Reporting App under ProcessReport Function " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Reporting APP.", false, false, 4);
            }


        }
        public void GenerateFile(DataSet Product, int ReportID, string Email, string TypeName)
        {
            if (Product.Tables.Count > 0)
            {
                if (Product.Tables[0].Rows.Count > 0)
                {
                    try
                    {
                        #region ExcelFileGenerate
                        int records = 20000;
                        int NoOfFeeds = 0;
                        int TotalNoOfRecords = Product.Tables[0].Rows.Count;
                        if (TotalNoOfRecords % records == 0)
                            NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / records);
                        else
                            NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / records) + 1;

                        int Counter = 0;
                        for (int i = 0; i < NoOfFeeds; i++)
                        {
                            FileInfo newFile = new FileInfo(ReportFilePath + ReportID + "_" + i + ".xlsx");
                            using (ExcelPackage pck = new ExcelPackage(newFile))
                            {
                                //Create the worksheet
                                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Demo");
                                ws.Cells["A1"].LoadFromDataTable(Product.Tables[0].AsEnumerable().Skip(i * records).Take(records).CopyToDataTable(), true);
                                pck.Save();
                            }
                            Counter++;
                        }
                        #endregion ExcelFileGenerate

                        #region ZippedFile
                        using (ZipFile zip = new ZipFile())
                        {
                            for (int i = 0; i < Counter; i++)
                            {
                                try
                                {
                                    zip.AddFile(ReportFilePath + ReportID + "_" + i + ".xlsx", "ReportFiles");
                                }
                                catch
                                {
                                }
                            }
                            zip.Save(ReportFilePath + ReportID + ".zip");
                            for (int i = 0; i < Counter; i++)
                            {
                                try
                                {
                                    System.IO.File.Delete(ReportFilePath + ReportID + "_" + i + ".xlsx");
                                }
                                catch
                                {
                                }
                            }
                        }
                        #endregion ZippedFile

                        _DB.ExecuteCommand("update Reports set [Report Status]='Completed',Response='Success',[processed date]='" + DateTime.Now + "' where [Report ID]=" + ReportID);

                        //#region TxtGenerateFile
                        //StreamWriter _Writer = new StreamWriter(ReportFilePath + "/" + ReportID + "_unicode.txt");
                        //StringBuilder sb = new StringBuilder();
                        //int Counter = 0;
                        //foreach (var col in Product.Tables[0].Columns)
                        //{
                        //    if (Counter + 1 == Product.Tables[0].Columns.Count)
                        //        sb.Append(col.ToString());
                        //    else
                        //        sb.Append(col.ToString() + "\t");
                        //    Counter++;
                        //}
                        //_Writer.WriteLine(sb);
                        //sb = new StringBuilder();
                        //foreach (DataRow row in Product.Tables[0].Rows)
                        //{

                        //    for (int col = 0; col < Product.Tables[0].Columns.Count; col++)
                        //    {
                        //        if (col + 1 == Product.Tables[0].Columns.Count)
                        //            sb.Append(row[col].ToString());
                        //        else
                        //            sb.Append(row[col].ToString() + "\t");
                        //    }
                        //    _Writer.WriteLine(sb);
                        //    sb = new StringBuilder();
                        //}
                        //_Writer.Close();
                        //_DB.ExecuteCommand("update Reports set [Report Status]='Completed',Response='Success',[processed date]='" + DateTime.Now + "' where [Report ID]=" + ReportID);
                        //#endregion GenerateFile
                    }
                    catch (Exception Exp)
                    {
                        _Mail.SendMail("Issue Occured in Reporting App under GenerateFile Function " + Exp.Message + "  at " + DateTime.Now.ToString(), "Urgent issue in Reporting APP.", false, false, 4);

                    }
                }
                else
                {
                    _DB.ExecuteCommand("update Reports set [Report Status]='Completed',Response='No Inventory',[processed date]='" + DateTime.Now + "' where [Report ID]=" + ReportID);
                }

            }
            else
            {
                _Mail.SendMail("Issue Occured in Reporting App under GenerateFile Function  for Report ID  " + ReportID + "  at " + DateTime.Now.ToString(), "Urgent issue in Reporting APP.", false, false, 4);
            }
        }
        public void ProcessFeeds(DataSet pendingFeed)
        {
            if (pendingFeed.Tables.Count > 0)
            {
                foreach (DataRow row in pendingFeed.Tables[0].Rows)
                {
                    ProcessFeed(Convert.ToInt32(row["Feed ID"]), row["BatchID"].ToString(), row["Feed Type"].ToString());
                    System.Threading.Thread.Sleep(1000);
                }
            }
        }
        public static DataTable GetDataTableFromExcel(string path, bool hasHeader = true)
        {
            using (var pck = new OfficeOpenXml.ExcelPackage())
            {
                using (var stream = File.OpenRead(path))
                {
                    pck.Load(stream);
                }
                var ws = pck.Workbook.Worksheets.First();
                DataTable tbl = new DataTable();
                foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
                {
                    tbl.Columns.Add(hasHeader ? firstRowCell.Text : string.Format("Column {0}", firstRowCell.Start.Column));
                }
                var startRow = hasHeader ? 2 : 1;
                for (int rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
                {
                    var wsRow = ws.Cells[rowNum, 1, rowNum, ws.Dimension.End.Column];
                    DataRow row = tbl.Rows.Add();
                    foreach (var cell in wsRow)
                    {
                        row[cell.Start.Column - 1] = ReplaceFirstLastDoubleQuote(cell.Text);
                    }
                }
                return tbl;
            }
        }
        public void ProcessFeed(int FeedID, string BatchID, string FeedType)
        {
            if (File.Exists(FeedFilePath + "/" + BatchID + ".xlsx"))
            {
                try
                {
                    DataTable _Table = new DataTable();
                    #region Read ExcelfILE
                    _Table = GetDataTableFromExcel(FeedFilePath + "/" + BatchID + ".xlsx", true);
                    #endregion ExcelfILE
                    //#region readTxtFile

                    //string[] csvRows = System.IO.File.ReadAllLines(FeedFilePath + "/" + BatchID + ".xlsx");
                    //string[] fields = null;
                    //for (int i = 0; i < csvRows.Count(); i++)
                    //{

                    //    fields = csvRows[i].Split(new string[] { "\t" }, StringSplitOptions.None);
                    //    string[] Fields1 = new string[fields.Length];
                    //    for (int k = 0; k < fields.Length; k++)
                    //    {
                    //        Fields1[k] = ReplaceFirstLastDoubleQuote(fields[k]);
                    //    }

                    //    if (i == 0)
                    //    {
                    //        for (int j = 0; j < Fields1.Count(); j++)
                    //        {
                    //            _Table.Columns.Add(Fields1[j]);
                    //        }
                    //    }
                    //    else
                    //    {
                    //        DataRow row = _Table.NewRow();
                    //        row.ItemArray = Fields1;
                    //        _Table.Rows.Add(row);
                    //    }

                    //}
                    //#endregion readTxtFile
                    #region SyncDataToDb

                    if (_Table.Rows.Count > 0)
                    {
                        if (SyncToDb(_Table, FeedID, FeedType))
                        {
                            _DB.ExecuteCommand("update Feed set [Feed Status]='Completed',Response='File Processed Successfully',[processed date]='" + DateTime.Now + "' where [Feed ID]=" + FeedID);
                        }
                        else
                        {
                            _Mail.SendMail("ProcessFeed Function.Issue Occured in sync data to database for feed having id is " + FeedID + "  at " + DateTime.Now.ToString(), ". Urgent issue in Reporting APP.", false, false, 4);
                            _DB.ExecuteCommand("update Feed set ErrorAccuredDateTime='" + DateTime.Now + "',Response='Issue accured in processing feed' where [Feed ID]=" + FeedID);

                        }
                    }
                    else
                    {
                        _DB.ExecuteCommand("update Feed set [Feed Status]='Completed',Response='There is No any Record In file',[processed date]='" + DateTime.Now + "' where [Feed ID]=" + FeedID);
                    }
                    #endregion SyncDataToDb
                }
                catch (Exception Exp)
                {
                    _Mail.SendMail("ProcessFeed Function.Issue Occured in Read Feed File having id " + FeedID + ". Exception: " + Exp.Message + "  at " + DateTime.Now.ToString(), ". Urgent issue in Reporting APP.", false, false, 4);
                }
            }
            else
            {
                _DB.ExecuteCommand("update Feed set [Feed Status]='Completed',Response='File not Exist',[processed date]='" + DateTime.Now + "' where [Feed ID]=" + FeedID);

            }

        }
        public bool SyncToDb(DataTable Table, int FeedID, string FeedType)
        {
            bool Result = true;
            try
            {
                int NoOfFeeds = 0;
                int TotalNoOfRecords = Table.Rows.Count;
                if (TotalNoOfRecords % MaxRecordFeedFile == 0)
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordFeedFile);
                else
                    NoOfFeeds = Convert.ToInt32(TotalNoOfRecords / MaxRecordFeedFile) + 1;
                for (int i = 0; i < NoOfFeeds; i++)
                {

                    if (!_DB.PassDatatable("MarkHub_BulkSyncEntity", Table.AsEnumerable().Skip(i * MaxRecordFeedFile).Take(MaxRecordFeedFile).CopyToDataTable(), "@Entity", CommandType.StoredProcedure, "@FeedType," + FeedType + ":@FeedID," + FeedID))
                    {
                        Result = false;
                        break;
                    }
                    System.Threading.Thread.Sleep(1000);
                }

            }
            catch
            {
                Result = false;
            }
            return Result;
        }

    }

}
